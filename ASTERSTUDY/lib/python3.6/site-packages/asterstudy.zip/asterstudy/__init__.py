# daizijian 2019/10
# 该App会加载成为Salome自带Python的library
# 每个文件下都需要有__init__.py文件


