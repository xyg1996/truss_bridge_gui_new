
"""Helper widgets for the calculation assistant wizard."""


from abc import abstractmethod
from collections import OrderedDict
import re

from PyQt5 import Qt as Q
from PyQt5 import QtCore

from ..common import (MeshGroupType, connect, external_file, external_files, get_file_name,
                      get_medfile_groups, is_reference, load_icon, translate)
from ..gui.widgets import Dialog, ElidedButton

# note: the following pragma is added to prevent pylint complaining
#       about functions that follow Qt naming conventions;
#       it should go after all global functions
# pragma pylint: disable=invalid-name


class AssistantError(Exception):
    """Base Assistant error."""
    message = ''


class InvalidInputError(AssistantError):
    """Invalid input error."""

    def __init__(self, bad):
        super().__init__()
        title = bad or translate("Assistant", "untitled")
        self.message = translate("Assistant",
                                 "Parameter '{}' is not properly defined.").format(title)


class NoChoiceError(AssistantError):
    """No choice error."""

    def __init__(self, *choices):
        super().__init__()
        err = ''.join(["  '{}'\n".format(i) for i in choices])
        self.message = translate("Assistant", "No choice is made between:") + ':\n\n{}'.format(err)


class ControlMixing:
    """Control base mixing class."""

    def wizard(self):
        """
        Get parent wizard dialog.

        Returns:
            widgets.Wizard: Parent wizard dialog.
        """
        obj = self
        while obj is not None and not isinstance(obj, Wizard):
            obj = obj.parent() # pragma pylint: disable=no-member
        return obj


class Wizard(Q.QWizard):
    """Wizard dialog."""

    meshChanged = Q.pyqtSignal(str)
    """
    Signal: emitted when a value is changed in the mesh selection widget.

    Arguments:
        uid (str): Mesh selection widget's uid (parameter name).
    """

    def __init__(self, parent=None):
        """
        Create wizard.

        Arguments:
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
        """
        super().__init__(parent)
        self.registered_widgets = OrderedDict()
        self.setWindowTitle(translate("Assistant", "Calculation Assistant"))

    def register(self, uid, widget):
        """
        Register control widget for a parameter.

        Arguments:
            uid (str): Parameter name.
            widget (widgets.Control): Control widget.

        Raises:
            KeyError: If parameter is duplicated.
        """
        if uid in self.registered_widgets:
            raise KeyError('duplicated parameter: {}'.format(uid))
        self.registered_widgets[uid] = widget
        if hasattr(widget, 'meshChanged'):
            connect(widget.meshChanged, self._meshChanged)
        if hasattr(widget, 'updateMesh'):
            connect(self.meshChanged, widget.updateMesh)
        if hasattr(widget, 'resized'):
            connect(widget.resized, self._resize)

    @property
    def widgets(self):
        """list[QWidget]: Attribute that holds all control widgets."""
        return self.registered_widgets.values()

    def widget(self, uid, typ=None):
        """
        Get registered widget.

        Arguments:
            uid (str): Parameter name.
            typ (Optional[class]): Widget class. Defaults to *None*
                (any appropriate widget).

        Note:
            If both **uid** and **typ** are *None*, first registered widget
            is returned.
            Specifying both **uid** and **type** is useless since only **uid**
            is meaningful in this case.

        Returns:
            QWidget: Widget (*None* if appropriate widget is not found).
        """
        for name, wid in self.registered_widgets.items():
            if uid in (name, None) and (typ is None or isinstance(wid, typ)):
                return wid
        return None

    def uid(self, widget):
        """
        Get control widget's uid (parameter name).

        Arguments:
            widget (QWidget): Control widget.

        Returns:
            str: Widget's uid; *None* for unknown widget.
        """
        for name, wid in self.registered_widgets.items():
            if wid == widget:
                return name
        return None

    def value(self):
        """
        Get wizard context.

        Returns:
            dict: Dictionary mapping each parameter to its value.
        """
        value = dict()
        pages = [self.page(uid) for uid in self.pageIds() if self.hasVisitedPage(uid)]
        for page in pages:
            value.update(page.value())
        return value

    @Q.pyqtSlot()
    def _meshChanged(self):
        """
        Called when value is changed in any mesh selection widget.
        Emits `meshChanged()` signal.
        """
        name = self.uid(self.sender())
        if name:
            self.meshChanged.emit(name)

    @Q.pyqtSlot()
    def _resize(self):
        """Called when some child widget needs resizing of the dialog."""
        self.setMinimumSize(self.sizeHint())


class WizardPage(Q.QWizardPage):
    """Wizard dialog's page."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create page.

        Supported keyword arguments:

        - **sub_title** (str): Page's sub-title (normally a description).

        Arguments:
            title (str): Page's main title.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(parent)

        self.widgets = []

        self.setTitle(title)
        if 'sub_title' in kwargs:
            self.setSubTitle(kwargs.get('sub_title'))

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)

    def addWidget(self, widget):
        """
        Insert child widget to page.

        Arguments:
            widget (QWidget): Child widget.
        """
        self.widgets.append(widget)
        self.layout().addWidget(widget)

    def validatePage(self):
        """
        Validate page. Reimplemented from *QWizardPage*.

        Returns:
            bool: *True* if data input in the page is valid; *False* otherwise.
        """
        for widget in self.widgets:
            try:
                widget.checkValidity()
            except AssistantError as exc:
                Q.QMessageBox.critical(self, translate("Assistant", "Error"), exc.message)
                return False
        return True

    def value(self):
        """
        Get page context.

        Returns:
            dict: Dictionary mapping each parameter to its value.
        """
        value = dict()
        for widget in self.widgets:
            if isinstance(widget, (Group, Choices)):
                value.update(widget.value())
            else:
                uid = self.wizard().uid(widget)
                value[uid] = widget.value()
        return value


class Group(Q.QWidget, ControlMixing):
    """Group box widget."""

    def __init__(self, title=None, parent=None):
        """
        Create group.

        Arguments:
            title (Optional[str]): Group's title. Defaults to *None*.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(parent)

        if title:
            self.group = Q.QGroupBox(self)
            self.group.setTitle(title)
        else:
            self.group = Q.QWidget(self)

        self.widgets = []

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(5, 5, 5, 5)
        self.layout().addWidget(self.group)
        self.group.setLayout(Q.QVBoxLayout())
        self.group.layout().setContentsMargins(5, 5, 5, 5)
        self.group.layout().setSpacing(5)

    def addWidget(self, widget):
        """
        Insert child widget to group.

        Arguments:
            widget (QWidget): Child widget.
        """
        self.widgets.append(widget)
        self.group.layout().addWidget(widget)

    def isEmpty(self):
        """
        Check if group contains any widgets.

        Returns:
            bool: *True* if group is empty; *False* otherwise.
        """
        return not self.widgets

    def value(self):
        """
        Get group context.

        Returns:
            dict: Dictionary mapping each parameter to its value.
        """
        value = dict()
        for widget in self.widgets:
            if isinstance(widget, (Group, Choices)):
                value.update(widget.value())
            else:
                uid = self.wizard().uid(widget)
                value[uid] = widget.value()
        return value

    def checkValidity(self):
        """
        Check if group contains valid input.

        Raises:
            AssistantError: If input is invalid.
        """
        for widget in self.widgets:
            widget.checkValidity()


class Control(Q.QWidget, ControlMixing):
    """Generic input widget."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create widget.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Arbitrary keyword arguments (managed in successors).
        """
        super().__init__(parent)
        self.title = title
        self.mandatory = kwargs.get('mandatory', True)
        self.attributes = {}
        self.attributes.update(kwargs)

    @abstractmethod
    def value(self):
        """
        Get widget's value.

        Abstract method: default implementation raises exception.
        It has to be reimplemented in successors.

        Returns:
            str: Widget's value.
        """
        raise NotImplementedError("Method should be implemented in successors")

    def checkValidity(self):
        """
        Check if control contains valid input.

        Raises:
            AssistantError: If input is invalid.
        """
        if self.isEmpty():
            if self.mandatory:
                raise InvalidInputError(self.title)
        elif not self.validate():
            raise InvalidInputError(self.title)

    def isEmpty(self): # pragma pylint: disable=no-self-use
        """
        Check if widget contains empty input.

        Default implementation returns *False*. This behavior can be
        changed in successors.

        Returns:
            bool: *True* if widget is empty; *False* otherwise.
        """
        return False

    def validate(self): # pragma pylint: disable=no-self-use
        """
        Check input validity.

        Default implementation returns *True*; This behavior can be
        changed in successors.
        """
        return True

    def attribute(self, name, default=None):
        """
        Get attribute value.

        Attributes are specifed as extra keyword arguments to the constructor.

        Arguments:
            name (str): Attribute's name.
            default (Optional[any])): Default value. Defaults to *None*.
        """
        return self.attributes.get(name, default)

    def event(self, event):
        """Reimplemented from *QWidget*."""
        if event.type() == Q.QEvent.ToolTipChange:
            if not getattr(self, '__in_tooltip_change__', False):
                setattr(self, '__in_tooltip_change__', True)
                self.setToolTip(self.toolTip().format(**self.attributes))
                delattr(self, '__in_tooltip_change__')
        return super().event(event)


class Text(Control):
    """Readonly text area."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create widget.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.textarea = Q.QTextEdit(self)
        self.textarea.setObjectName('textarea')
        self.textarea.setReadOnly(True)

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(self.label)
        self.layout().addWidget(self.textarea)

        self.label.setText(self.title)
        self.textarea.setText(self.attributes['text'])

    def value(self):
        """Reimplemented from widgets.Control."""
        return ""


class LineEdit(Control):
    """Simple line editor."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **typ** (str): Parameter type: one of 'int', 'float', 'string'.
          Default: 'string'.
        - **val_min** (int, float): Minimum value (for 'int' and 'float'
          types). Default: 0.
        - **val_max** (int, float): Maximum value (for 'int' and 'float'
          types). Default: *None*.
        - **default** (int, float, str): Default value. Default: *None*.
        - **regex** (str): Regular expression for validation; only for
          'string' type. Default: *None*.
        - **len_min** (int): Minimum length of value; only for 'string'
          type. Default: 0.
        - **len_max** (int): Minimum length of value; only for 'string'
          type. Default: *None* (unlimited).
        - **length** (int): Length of value; only for 'string' type.
          Default: *None* (unlimited).

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.control = Q.QLineEdit(self)
        self.control.setObjectName('control')

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(self.label)
        self.layout().addWidget(self.control)

        self.label.setText(self.title)
        self.control.setValidator(create_validator(self.attributes))
        self.control.setText(default_value(self.attributes))

    def value(self):
        """Reimplemented from widgets.Control."""
        return str2value(self.control.text(), self.attributes)

    def isEmpty(self):
        """Reimplemented from widgets.Control."""
        return not self.control.text().strip()

    def validate(self):
        """Reimplemented from widgets.Control."""
        is_valid = True
        validator = self.control.validator()
        if validator is not None:
            state = validator.validate(self.control.text(), 0)
            is_valid = state[0] == Q.QValidator.Acceptable
        return is_valid


class ComboBox(Control):
    """Selector."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **typ** (str): Parameter type: one of 'int', 'float', 'string'.
          Default: 'string'.
        - **into** (list): Allowed values. Default: empty list.
        - **default** (int, float, str): Default value. If not specified, first
          item from **into** keyword is used as default value.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.control = Q.QComboBox(self)
        self.control.setObjectName('control')

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(self.label)
        self.layout().addWidget(self.control)

        self.label.setText(self.title)
        for item in self.attribute('into', []):
            self.control.addItem(str(item))
        value = default_value(self.attributes)
        index = self.control.findText(value)
        if index >= 0:
            self.control.setCurrentIndex(index)
        elif value is not None:
            self.control.addItem(str(value))

    def value(self):
        """Reimplemented from widgets.Control."""
        return str2value(self.control.currentText(), self.attributes)

    def isEmpty(self):
        """Reimplemented from widgets.Control."""
        return not self.control.currentText().strip()

    def validate(self):
        """Reimplemented from widgets.Control."""
        return self.control.currentIndex() != -1


class CheckBox(Control):
    """Switcher."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **default** (bool): Default value. Default: *False*.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)
        self.control = Q.QCheckBox(title, self)
        self.control.setObjectName('control')

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(self.control)

        state = Q.Qt.Checked if self.attribute('default', False) else Q.Qt.Unchecked
        self.control.setCheckState(state)

    def value(self):
        """Reimplemented from widgets.Control."""
        return self.control.checkState() == Q.Qt.Checked


class FileSelector(Control):
    """File selector."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **mode** (str): File mode: 'in' or 'out'. Default: 'in'.
        - **unit** (int): Default file unit value. Default: -1.
        - **filters** (str): List of file filters. Default: *None*.
        - **default** (bool): Default value. Default: *None*.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.control = self._createControl()
        self.control.setSizePolicy(Q.QSizePolicy.Expanding, Q.QSizePolicy.Fixed)
        self.control.setObjectName('control')

        self.button = Q.QPushButton(self)
        self.button.setObjectName('btn')
        self.button.setText(translate("Assistant", "Browse..."))

        self.setLayout(Q.QGridLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(self.label, 0, 0, 1, 2)
        self.layout().addWidget(self.control, 1, 0)
        self.layout().addWidget(self.button, 1, 1)

        self.label.setText(self.title)
        self.setValue(default_value(self.attributes))

        connect(self.button.clicked, self._browse)

    def value(self):
        """Reimplemented from widgets.Control."""
        return {self.attribute('unit', -1): str2value(self.fileName(), {})}

    def setValue(self, value):
        """
        Set value to control.

        Arguments:
            value (str): Control value.
        """
        self.control.setText(value or '')

    def isEmpty(self):
        """Reimplemented from widgets.Control."""
        return not self.control.text().strip()

    def fileName(self):
        """
        Get control value as string.

        Returns:
            str: File name as entered by the user.
        """
        return self.control.text()

    @Q.pyqtSlot()
    def _browse(self):
        """Called when *Browse* button is pressed."""
        mode = 1 if self.attribute('mode', 'in') == 'in' else 0
        title = translate("Assistant", "Choose File")
        filters = self._filters()
        default_filter = filters[0] if filters else None
        extensions = re.findall(r"\*\.([A-Za-z0-9_]+)", default_filter)
        extension = extensions[0] if extensions else None
        file_name = self.fileName()
        if is_reference(file_name):
            file_name = ''
        file_name = get_file_name(mode, self, title, file_name, filters,
                                  suffix=extension, dflt_filter=default_filter)
        if file_name:
            self.setValue(file_name)

    def _createControl(self):
        """Create input control widget."""
        return Q.QLineEdit(self)

    def _filters(self):
        """Get file filters."""
        filters = []
        if 'filters' in self.attributes:
            filters = self.attribute('filters', '').split(';;')
        filters.append(translate("Assistant", "All files") + " (*)")
        return filters


class MeshSelector(FileSelector):
    """Mesh selector."""

    meshChanged = Q.pyqtSignal()
    """Signal: emitted when a value is changed in the mesh selection widget."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create widget.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        for uid in external_files('MED'):
            file_name = external_file(uid)
            if not file_name:
                continue
            self.control.addItem(file_name, uid)

        connect(self.control.currentTextChanged, self.meshChanged)

    def fileName(self):
        """Reimplemented from widgets.FileSelector."""
        return self.control.currentData()

    def setValue(self, value):
        """Reimplemented from widgets.FileSelector."""
        if not value:
            return
        for i in range(self.control.count()):
            if self.control.itemData(i) is None and self.control.itemText(i) == value:
                self.control.setCurrentIndex(i)
                return
        self.control.insertItem(0, value, value)
        self.control.setCurrentIndex(0)

    def isEmpty(self):
        """Reimplemented from widgets.FileSelector."""
        return not self.control.currentText().strip()

    def _createControl(self):
        """Reimplemented from widgets.FileSelector."""
        return Q.QComboBox(self)

    def _filters(self):
        """Reimplemented from widgets.FileSelector."""
        filters = []
        filters.append(translate("Assistant", "Med files") + ' (*.med *.rmed *.mmed)')
        filters.append(translate("Assistant", "All files") + " (*)")
        return filters


class GroupSelector(ComboBox):
    """Base mesh group selector class."""

    GROUP_TYPE = None

    def updateMesh(self, mesh):
        """
        Called when mesh is changed by the user.

        Arguments:
            uid (str): Mesh selection widget's uid (parameter name).
        """
        if self.attribute('mesh') in (mesh, None):
            groups = []
            ctrl = self.wizard().widget(mesh)
            if ctrl is not None:
                file_name = ctrl.fileName()
                groups = get_medfile_groups(file_name, None, self.GROUP_TYPE)
                self.control.clear()
                self.control.addItems(groups)
                self.control.setCurrentIndex(-1)


class GroupElSelector(GroupSelector):
    """Selector of single group of mesh elements."""

    GROUP_TYPE = MeshGroupType.GElement


class GroupNoSelector(GroupSelector):
    """Selector of single group of mesh nodes."""

    GROUP_TYPE = MeshGroupType.GNode


class GroupSelectionDialog(Dialog):
    """Groups selection dialog."""

    def __init__(self, parent=None):
        """
        Create dialog.

        Arguments:
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
        """
        super().__init__(parent=parent, modal=True)
        self.list = Q.QListWidget(self.frame())
        self.list.setSelectionMode(Q.QListWidget.ExtendedSelection)
        self.list.setContextMenuPolicy(Q.Qt.CustomContextMenu)
        connect(self.list.customContextMenuRequested, self._popupMenuRequest)
        self.frame().layout().addWidget(self.list)

    def setAllGroups(self, groups):
        """
        Set list of available groups.

        Arguments:
            groups (list[str]): Groups to be listed.
        """
        self.list.clear()
        for group in groups:
            item = Q.QListWidgetItem()
            item.setText(group)
            item.setCheckState(Q.Qt.Unchecked)
            self.list.addItem(item)

    def setGroups(self, groups):
        """
        Set list of selected groups.

        Arguments:
            groups (list[str]): Groups to be selected.
        """
        for group in groups:
            items = self.list.findItems(group, Q.Qt.MatchExactly)
            if items:
                items[0].setCheckState(Q.Qt.Checked)

    def groups(self):
        """
        Get list of selected groups.

        Returns:
            list[str]: Selected groups.
        """
        groups = []
        for i in range(self.list.count()):
            if self.list.item(i).checkState() == Q.Qt.Checked:
                groups.append(self.list.item(i).text())
        return groups

    def _popupMenuRequest(self, pos):
        """Process context menu request."""
        items = self.list.selectedItems()
        has_checked = False
        has_unchecked = False
        for item in items:
            has_checked = has_checked or item.checkState() == Q.Qt.Checked
            has_unchecked = has_unchecked or item.checkState() == Q.Qt.Unchecked
        if has_checked or has_unchecked:
            menu = Q.QMenu()
            if has_unchecked:
                action = menu.addAction(translate("Assistant", "Select"))
                connect(action.triggered, self._select)
            if has_checked:
                action = menu.addAction(translate("Assistant", "Unselect"))
                connect(action.triggered, self._unselect)
            menu.exec_(self.mapToGlobal(pos))

    @Q.pyqtSlot(bool)
    def _select(self):
        """Check selected items."""
        items = self.list.selectedItems()
        for item in items:
            item.setCheckState(Q.Qt.Checked)

    @Q.pyqtSlot(bool)
    def _unselect(self):
        """Uncheck selected items."""
        items = self.list.selectedItems()
        for item in items:
            item.setCheckState(Q.Qt.Unchecked)


class GroupsButton(ElidedButton):
    """'Edit' button to open groups selection dialog."""

    def __init__(self, parent=None):
        """Create button."""
        super().__init__('', parent)
        self._mesh = None
        self._typ = 'groups_ma'
        self._value = []
        self._updateText()

    @property
    def mesh(self):
        """Attribute that holds mesh name."""
        return self._mesh

    @mesh.setter
    def mesh(self, mesh):
        self._mesh = mesh

    @property
    def typ(self):
        """Attribute that holds group type."""
        return self._typ

    @typ.setter
    def typ(self, typ):
        self._typ = typ

    @property
    def value(self):
        """Attribute that holds selected groups."""
        return self._value

    @value.setter
    def value(self, value):
        self._value = value
        self._updateText()

    def _updateText(self):
        """Update button's title."""
        text = ','.join(self.value) if self.value else translate("Assistant", "Edit...")
        self.setText(text)
        self.setToolTip(text if self.value else '')


class TableWidget(Control):
    """Table editor."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **rule** (str): Custom validation rule for each table row. Default: *None*.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.columns = OrderedDict()

        button_add = Q.QPushButton(self)
        button_add.setIcon(load_icon('as_pic_add_row.png'))
        button_add.setObjectName('button_add')
        button_add.setMaximumWidth(30)

        button_remove = Q.QPushButton(self)
        button_remove.setIcon(load_icon('as_pic_remove_row.png'))
        button_remove.setObjectName('button_remove')
        button_remove.setMaximumWidth(30)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.table = Q.QTableWidget(self)
        self.table.setObjectName('control')
        self.table.verticalHeader().hide()
        self.table.setSelectionMode(Q.QAbstractItemView.SingleSelection)

        self.table.setColumnCount(3)   ##设置列数
        self.headers = ['groups_NO','DX','DY','DZ',]
        self.table.setHorizontalHeaderLabels(self.headers)

        #self.setLayout(Q.QGridLayout())
        #self.layout().setContentsMargins(0, 0, 0, 0)
        #self.layout().setSpacing(5)
        #self.layout().addWidget(button_add, 0, 0)
        #self.layout().addWidget(button_remove, 0, 1)
        #self.layout().addWidget(self.label, 0, 2)
        #self.layout().addWidget(self.table, 1, 0, 1, 3)
        #self.layout().setColumnStretch(2, 1)

        self.button_add.move(20,20)
        self.button_add.remove(70,20)
        self.table.move(20,70)

        self.label.setText(self.title)

        connect(button_add.clicked, self._addRow)
        connect(button_remove.clicked, self._removeSelectedRow)

    def addColumn(self, name, title, **kwargs):
        """
        Insert new column to table.

        Supported keyword arguments:

        - **typ** (str): Parameter type: one of 'int', 'float', 'string',
          'group_ma', 'group_no', 'groups_ma', 'groups_no'. Default: 'string'.
        - **val_min** (int, float): Minimum value (for 'int' and 'float'
          types). Default: *None*.
        - **val_max** (int, float): Maximum value (for 'int' and 'float'
          types). Default: *None*.
        - **default** (int, float, str): Default value. *None*.
        - **regex** (str): Regular expression for validation; only for
          'string' type. Default: *None*.
        - **len_min** (int): Minimum length of value; only for 'string'
          type. Default: *None*
        - **len_max** (int): Minimum length of value; only for 'string'
          type. Default: *None* (unlimited).
        - **length** (int): Length of value; only for 'string' type.
          Default: *None* (unlimited).

        Attributes:
            name (str): Column name (must be unique within table).
            title (str): Column title.
            **kwargs: Keyword arguments.

        Raises:
            KeyError: If **name** is not specified or duplicated.
        """
        if not name:
            raise KeyError('unnamed column')
        if name in self.columns:
            raise KeyError('duplicated column: {}'.format(name))
        self.columns[name] = kwargs

        column = self.table.columnCount()
        self.table.insertColumn(column)

        header_item = Q.QTableWidgetItem(title)
        self.table.setHorizontalHeaderItem(column, header_item)
        stretch = Q.QHeaderView.Stretch
        self.table.horizontalHeader().setSectionResizeMode(column, stretch)

        delegate = create_delegate(self.columns[name], self)
        if delegate is not None:
            self.table.setItemDelegateForColumn(column, delegate)

    def value(self):
        """Reimplemented from widgets.Control."""
        values = []
        for row in range(self.table.rowCount()):
            columns = self.columns.keys()
            dic = OrderedDict()
            for index, column in enumerate(columns):
                attributes = self.columns[column]
                value = str2value(self._itemValue(row, index), attributes)
                if value is not None:
                    dic[column] = value
            values.append(dic)
        return tuple(values)

    def isEmpty(self):
        """Reimplemented from widgets.Control."""
        return not self.table.rowCount()

    def validate(self):
        """Reimplemented from widgets.Control."""
        rule = self.attribute('rule')
        for row in range(self.table.rowCount()):
            values = {}
            columns = self.columns.keys()
            for index, column in enumerate(columns):
                value = self._itemValue(row, index)
                values[column] = value or None
            if rule:
                exec('valid = {}'.format(rule.format(**values)), globals(), locals()) # pragma pylint: disable=exec-used
                if not locals().get('valid'):
                    return False
            else:
                if [i for i in values.values() if not i]:
                    return False
        return True

    @Q.pyqtSlot()
    def _addRow(self):
        """Insert new row to table."""
        row = self.table.rowCount()
        #row = row + 1
        #self.table.insertRow(row)
        #self.table.insertRow(row+1)
        self.table.setRowCount(row + 1)
        self.table.setItem(row,0,QTableWidgetItem("input"))

        # columns = self.columns.keys()
        # for index, column in enumerate(columns):
        #     attributes = self.columns[column]
        #     if attributes.get('typ') in ('groups_ma', 'groups_no'):
        #         button = GroupsButton(self)
        #         button.mesh = attributes.get('mesh')
        #         button.typ = attributes.get('typ')
        #         button.value = default_value(attributes)
        #         connect(button.clicked, self._selectGroups)
        #         self.table.setCellWidget(row, index, button)
        #         self.table.setItem(0,0,QTableWidgetItem("input"))

        #     else:
        #         item = Q.QTableWidgetItem()
        #         item.setText(default_value(attributes))
        #         self.table.setItem(row, index, item)

    @Q.pyqtSlot()
    def _removeSelectedRow(self):
        """Remove selected row(s)."""
        selected = self.table.selectedItems()
        rows = sorted(set([i.row() for i in selected] + [self.table.currentRow()]), reverse=True)
        for row in rows:
            self.table.removeRow(row)

    @Q.pyqtSlot()
    def _selectGroups(self):
        """Open dialog to choose mesh groups."""
        button = self.sender()
        mesh = button. mesh
        typ = button.typ
        groups = button.value
        ctrl = self.wizard().widget(mesh, typ=MeshSelector)
        if ctrl is None:
            return
        file_name = ctrl.fileName()
        grtype = MeshGroupType.GElement if typ in ('groups_ma',) else MeshGroupType.GNode
        all_groups = get_medfile_groups(file_name, None, grtype)
        dlg = GroupSelectionDialog(self)
        dlg.setAllGroups(all_groups)
        dlg.setGroups(groups)
        if dlg.exec_():
            groups = dlg.groups()
            button.value = groups

    def _itemValue(self, row, column):
        """Get item value."""
        if self.table.cellWidget(row, column) is not None:
            return getattr(self.table.cellWidget(row, column), 'value')
        return self.table.item(row, column).text().strip()

    def updateMesh(self, mesh):
        """Called when mesh is changed by the user."""
        has_groups = False
        for attributes in self.columns.values():
            has_groups = has_groups or \
                (attributes.get('typ') in ('group_ma', 'group_no', 'groups_ma', 'groups_no') \
                     and attributes.get('mesh') in (mesh, None))
        if has_groups:
            self.table.setRowCount(0)

class ListWidget(Control):
    """List editor."""
    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:
        - **rule** (str): Custom validation rule for each list item. Default: *None*.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)
        button_add = Q.QPushButton(self)
        button_add.setIcon(load_icon('as_pic_add_row.png'))
        button_add.setObjectName('button_add')
        button_add.setMaximumWidth(30)
        button_remove = Q.QPushButton(self)
        button_remove.setIcon(load_icon('as_pic_remove_row.png'))
        button_remove.setObjectName('button_remove')
        button_remove.setMaximumWidth(30)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.list = Q.QListWidget(self)
        self.list.setObjectName('control')
        self.list.setSelectionMode(Q.QAbstractItemView.SingleSelection)

        self.setLayout(Q.QGridLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(5)
        self.layout().addWidget(button_add, 0, 0)
        self.layout().addWidget(button_remove, 0, 1)
        self.layout().addWidget(self.label, 0, 2)
        self.layout().addWidget(self.list, 1, 0, 1, 3)

        self.label.setText(self.title)
        connect(button_add.clicked, self._addItem)
        connect(button_remove.clicked, self._removeSelectedItem)

    def value(self):
        """Reimplemented from *Control*."""
        length = self.list.count()
        value = []
        for i in range(length):
            value.append(int(self.list.item(i).text()))
        value.sort()
        val = tuple(value)
        return val

    @Q.pyqtSlot()
    def _addItem(self):
        """Insert new item to list."""
        row_max = self.list.count()
        item = Q.QListWidgetItem()
        item.setText('0')
        item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
        self.list.insertItem(row_max, item)

    @Q.pyqtSlot()
    def _removeSelectedItem(self):
        """Remove selected item."""
        item = self.list.currentItem()
        self.list.takeItem(self.list.row(item))

class MatrixWidget(Control):
    """Matrix editor."""

    def __init__(self, title, parent=None, **kwargs):
        """
        Create editor.

        Supported keyword arguments:

        - **rule** (str): Custom validation rule for each table row. Default: *None*.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.columns = OrderedDict()

        button_add = Q.QPushButton(self)
        button_add.setIcon(load_icon('as_pic_add_row.png'))
        button_add.setObjectName('button_add')
        button_add.setMaximumWidth(30)

        button_remove = Q.QPushButton(self)
        button_remove.setIcon(load_icon('as_pic_remove_row.png'))
        button_remove.setObjectName('button_remove')
        button_remove.setMaximumWidth(30)

        self.label = Q.QLabel(self)
        self.label.setObjectName('label')

        self.table = Q.QTableWidget(self)
        self.table.setObjectName('control')
        self.table.verticalHeader().hide()
        self.table.setSelectionMode(Q.QAbstractItemView.SingleSelection)

        self.table.setColumnCount(4)   ##设置列数
        self.headers = ['分组设置','DX','DY','DZ',]
        self.table.setHorizontalHeaderLabels(self.headers)
        #self.table.setMinimumWidth(500)

        #self.setLayout(Q.QGridLayout())
        #self.layout().setContentsMargins(0, 0, 0, 0)
        #self.layout().setSpacing(5)
        #self.layout().addWidget(button_add, 0, 0)
        #self.layout().addWidget(button_remove, 0, 1)
        #self.layout().addWidget(self.label, 0, 2)
        #self.layout().addWidget(self.table, 1, 0, 1, 3)
        #self.layout().setColumnStretch(2, 1)

        button_add.move(20,20)
        button_remove.move(70,20)
        self.table.move(20,70)

        self.label.setText(self.title)

        connect(button_add.clicked, self._addRow)
        connect(button_remove.clicked, self._removeSelectedRow)

    def value(self):
        """Reimplemented from *Control*."""
        values = []
        for row in range(self.table.rowCount()):
            columns = self.columns.keys()
            for index, column in enumerate(columns):
                attributes = self.columns[column]
                value = str2value(self._itemValue(row, index), attributes)
                if value is not None:
                    values.append(value)
        return tuple(values)

    def isEmpty(self):
        """Reimplemented from *Control*."""
        return not self.table.rowCount()

    def validate(self):
        """Reimplemented from *Control*."""
        rule = self.attribute('rule')
        for row in range(self.table.rowCount()):
            values = {}
            columns = self.columns.keys()
            for index, column in enumerate(columns):
                value = self._itemValue(row, index)
                values[column] = value or None
            if rule:
                exec('valid = {}'.format(rule.format(**values)), globals(), locals()) # pragma pylint: disable=exec-used
                if not locals().get('valid'):
                    return False
            else:
                if [i for i in values.values() if not i]:
                    return False
        return True

    @Q.pyqtSlot()
    def _addRow(self):
        """Insert new row to table."""
        row = self.table.rowCount()
        #row = row + 1
        #self.table.insertRow(row)
        #self.table.insertRow(row+1)
        button = GroupsButton(self)
        button.mesh = "/home/export/online1/systest/swrh/dzj/installer/gmsh-4.4.1-Linux64/bin/Mesh2nd.med"#attributes.get('mesh')
        button.typ = "groups_no"#attributes.get('typ')
        #button.value = default_value(attributes)
        button.value = ""
        connect(button.clicked, self._selectGroups)
        self.table.setRowCount(row + 1)
        self.table.setCellWidget(row,0,button)
        ckbox1=Q.QCheckBox()
        ckbox2=Q.QCheckBox()
        ckbox3=Q.QCheckBox()
        #self.table.setItem(row,1,setCellWidget(ckbox))
        #self.table.setItem(row,2,setCellWidget(ckbox))
        #self.table.setItem(row,3,setCellWidget(ckbox))
        self.table.setCellWidget(row,1,ckbox1)
        self.table.setCellWidget(row,2,ckbox2)
        self.table.setCellWidget(row,3,ckbox3)

        # columns = self.columns.keys()
        # for index, column in enumerate(columns):
        #     attributes = self.columns[column]
        #     if attributes.get('typ') in ('groups_ma', 'groups_no'):
        #         button = GroupsButton(self)
        #         button.mesh = attributes.get('mesh')
        #         button.typ = attributes.get('typ')
        #         button.value = default_value(attributes)
        #         connect(button.clicked, self._selectGroups)
        #         self.table.setCellWidget(row, index, button)
        #         self.table.setItem(0,0,QTableWidgetItem("input"))

        #     else:
        #         item = Q.QTableWidgetItem()
        #         item.setText(default_value(attributes))
        #         self.table.setItem(row, index, item)



    @Q.pyqtSlot()
    def _removeSelectedRow(self):
        """Remove selected row(s)."""
        selected = self.table.selectedItems()
        rows = sorted(set([i.row() for i in selected] + [self.table.currentRow()]), reverse=True)
        for row in rows:
            self.table.removeRow(row)

    @Q.pyqtSlot()
    def _selectGroups(self):
        """Open dialog to choose mesh groups."""
        button = self.sender()
        mesh = button.mesh
        typ = button.typ
        groups = button.value
        #ctrl = self.wizard().widget(mesh, typ=MeshSelector)
        #if ctrl is None:
        #    return
        #file_name = ctrl.fileName()
        file_name = mesh
        grtype = MeshGroupType.GElement if typ in ('groups_ma',) else MeshGroupType.GNode
        all_groups = get_medfile_groups(file_name, None, grtype)
        dlg = GroupSelectionDialog(self)
        dlg.setAllGroups(all_groups)
        dlg.setGroups(groups)
        if dlg.exec_():
            groups = dlg.groups()
            button.value = groups

    def _itemValue(self, row, column):
        """Get item value."""
        if self.table.cellWidget(row, column) is not None:
            return getattr(self.table.cellWidget(row, column), 'value')
        return self.table.item(row, column).text().strip()

    def updateMesh(self, mesh):
        """Called when mesh is changed by the user."""
        has_groups = False
        for attributes in self.columns.values():
            has_groups = has_groups or \
                (attributes.get('typ') in ('group_ma', 'group_no', 'groups_ma', 'groups_no') \
                     and attributes.get('mesh') in (mesh, None))
        if has_groups:
            self.table.setRowCount(0)


class LineEditDelegate(Q.QStyledItemDelegate):
    """Line editor delegate."""

    def __init__(self, attributes, parent):
        """
        Create delegate.

        Arguments:
            attributes (dict): Delegate attributes.
            parent (QWidget): Parent widget.
        """
        super().__init__(parent)
        self.validator = create_validator(attributes)
        self.default = default_value(attributes)

    def createEditor(self, parent, option, index): # pragma pylint: disable=unused-argument
        """Create editor. Reimplemented from *QStyledItemDelegate*."""
        editor = Q.QLineEdit(parent)
        editor.setValidator(self.validator)
        editor.setText(self.default)
        return editor


class ComboBoxDelegate(Q.QStyledItemDelegate):
    """Selector delegate."""

    def __init__(self, attributes, parent):
        """
        Create delegate.

        Arguments:
            attributes (dict): Delegate attributes.
            parent (QWidget): Parent widget.
        """
        super().__init__(parent)
        self.widget = parent
        self.attributes = {}
        self.attributes.update(attributes)

    def createEditor(self, parent, option, index): # pragma pylint: disable=unused-argument
        """Create editor. Reimplemented from *QStyledItemDelegate*."""
        editor = Q.QComboBox(parent)

        items = []
        if self.attributes.get('typ') in ('group_ma', 'group_no'):
            ctrl = self.widget.wizard().widget(self.attributes.get('mesh'), typ=MeshSelector)
            if ctrl is not None:
                file_name = ctrl.fileName()
                grtype = MeshGroupType.GElement if self.attributes.get('typ') in ('group_ma',) \
                    else MeshGroupType.GNode
                items = get_medfile_groups(file_name, None, grtype)
        elif 'into' in self.attributes:
            items = self.attributes.get('into', [])
        default = default_value(self.attributes)

        editor.addItems([str(i) for i in items])
        editor.setCurrentIndex(editor.findText(default))
        return editor


class Choices(Control):
    """Choice selector widget."""

    resized = Q.pyqtSignal()
    """Signal: emitted when a choice is changed and a depedent widget is resized."""

    def __init__(self, title=None, parent=None, **kwargs):
        """
        Create widget.

        Arguments:
            title (str): Widget's label.
            parent (Optional[QWidget]): Parent widget. Defaults to *None*.
            **kwargs: Keyword arguments.
        """
        super().__init__(title, parent, **kwargs)

        self.choices = OrderedDict()

        if title:
            self.group = Q.QGroupBox(self)
            self.group.setTitle(title)
        else:
            self.group = Q.QWidget(self)
        self.button_group = Q.QButtonGroup(self)

        self.setLayout(Q.QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().addWidget(self.group)
        self.group.setLayout(Q.QVBoxLayout())
        self.group.layout().setContentsMargins(5, 5, 5, 5)
        self.group.layout().setSpacing(5)

    def addChoice(self, value, title=None):
        """
        Add choice.

        Arguments:
            value (str): Choice value.
            title (Optional[str]): Choice title. Defaults to *None*.

        Returns:
            widgets.Group: Group widget which can be used to insert additional widgets.
        """
        radio = Q.QRadioButton(self.group)
        radio.setText(title or value)
        radio.value = value
        self.button_group.addButton(radio)
        group = Choice(parent=self.group)
        group.setVisible(False)
        self.choices[radio] = group
        self.group.layout().addWidget(radio)
        self.group.layout().addWidget(group)
        connect(radio.toggled, self._toggled)
        return group

    def setVisible(self, visible):
        """Reimplemented from widgets.Control."""
        super().setVisible(visible)
        self.setValue(self.attribute('default'))

    def value(self):
        """Reimplemented from widgets.Control."""
        value = dict()
        selected = self.button_group.checkedButton()
        uid = self.wizard().uid(self)
        if selected is not None and uid is not None:
            value[uid] = selected.value
            value.update(self.choices[selected].value())
        return value

    def setValue(self, value):
        """
        Set value to control.

        Arguments:
            value (str): Control value.
        """
        for radio in self.choices:
            if radio.value == value:
                radio.setChecked(True)

    def checkValidity(self):
        """Reimplemented from widgets.Control."""
        if self.choices:
            selected = self.button_group.checkedButton()
            if selected is None:
                raise NoChoiceError(*[rb.text() for rb in self.choices])
            self.choices[selected].checkValidity()

    def _toggled(self, checked):
        """Show / hide related parameters group when choice is selected/unselected."""
        radio = self.sender()
        group = self.choices.get(radio)
        if group is not None:
            if not checked or not group.isEmpty():
                group.setVisible(checked)
                group.setMinimumSize(group.minimumSizeHint())
                self.resized.emit()


class Choice(Group):
    """Choice widget."""


class IntValidator(Q.QIntValidator):
    """Customized validator for integer values that allows empty input."""

    def validate(self, value, pos):
        """Reimplemeted from *QIntValidator*."""
        status, value, pos = super().validate(value, pos)
        status = self.Acceptable if not value else status
        return status, value, pos


class DoubleValidator(Q.QDoubleValidator):
    """Customized validator for double values that allows empty input."""

    def validate(self, value, pos):
        """Reimplemeted from *QDoubleValidator*."""
        status, value, pos = super().validate(value, pos)
        status = self.Acceptable if not value else status
        return status, value, pos


def create_validator(attributes):
    """
    Create validator for widget.

    Arguments:
        attributes (dict): Widget attributes.

    Returns:
        QValidator: *None* if validator is not needed.
    """
    validator = None
    typ = attributes.get('typ', 'string')
    if typ in ('int', 'float'):
        validator = IntValidator() if typ in ('int',) else DoubleValidator()
        if 'val_min' in attributes:
            validator.setBottom(attributes.get('val_min'))
        if 'val_max' in attributes:
            validator.setTop(attributes.get('val_max'))
    elif typ in ('string',):
        if 'regex' in attributes:
            validator = Q.QRegExpValidator(Q.QRegExp(attributes.get('regex')))
        elif 'length' in attributes:
            length = attributes.get('length', '')
            regex = '.{%s}' % str(length)
            validator = Q.QRegExpValidator(Q.QRegExp(regex))
        elif 'len_max' or 'len_min' in attributes:
            len_min = attributes.get('len_min', '')
            len_max = attributes.get('len_max', '')
            regex = '.{%s,%s}' % (str(len_min), str(len_max))
            validator = Q.QRegExpValidator(Q.QRegExp(regex))
    return validator


def default_value(attributes):
    """
    Get default value for a widget.

    Arguments:
        attributes (dict): Widget attributes.

    Returns:
        str: Default value.
    """
    default = ''
    if 'default' in attributes:
        default = str(attributes.get('default'))
    elif attributes.get('mandatory', True):
        if 'val_min' in attributes:
            default = str(attributes.get('val_min'))
        elif attributes.get('into', []):
            default = str(attributes.get('into')[0])
        elif attributes.get('typ') in ('int', 'float'):
            default = '0'
    return default


def str2value(text, attributes):
    """
    Get value from given text representation.

    Arguments:
        text (str): Value text.
        attributes (dict): Widget attributes.

    Returns:
        any: Value.
    """
    if text:
        if isinstance(text, (list, tuple)):
            return tuple(str2value(i, attributes) for i in text)
        if attributes.get('typ') == 'int':
            return int(text)
        if attributes.get('typ') == 'float':
            return float(text)
        return text
    return None


def create_delegate(attributes, parent):
    """
    Create delegate for item.

    Arguments:
        attributes (dict): Item attributes.
        parent (QWidget): Owner of delegate.

    Returns:
        QItemDelegate: *None* if no specific delegate is needed.
    """
    if attributes.get('typ') in ('group_ma', 'group_no') or 'into' in attributes:
        return ComboBoxDelegate(attributes, parent)
    if attributes.get('typ') in ('groups_ma', 'groups_no'):
        return None # force no item delegate as a cell widget will be set here
    return LineEditDelegate(attributes, parent)
