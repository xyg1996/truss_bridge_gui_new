

"""
Created on Sun Dec 23 10:24:39 2018

@author: longmao
"""
import os
import sys
import subprocess as sp
import linecache
from pathlib import Path

class Fluidinitial(object):
    """
    def __init__(self,workDic,acc,liqratio,xmin,xmax,ymin,ymax,zmin,zmax,
                 dyne,mp_rho,mp_nu,sp_rho,sp_nu):
        
        #self.bakdir = "/home/export/online3/amd_share/SALOME-9.3.0-CO7-SRC/template/Fluid/"
        self.bakdir = 'E:\\software study\\Qt\\1. Tanksimulator\\1. test\\tankVOF\\damBreak\\'
        self.casedir = workDic
        self.accelation = acc
        self.liquidratio = liqratio
        self.xmin = float(xmin)
        self.xmax = float(xmax)
        self.ymin = float(ymin)
        self.ymax = float(ymax)
        self.zmin = float(zmin)
        self.zmax = float(zmax)
        self.dyne = dyne
        self.mprho = mp_rho
        self.mpnu = mp_nu
        self.sprho = sp_rho
        self.spnu = sp_nu
        
        self.zero_dir = self.casedir+r'\0'                             #获取文件件所在路径
        self.cons_dir = self.casedir+r'\constant' 
        self.sys_dir = self.casedir+r'\system'
        self.bd_file = self.cons_dir+r'\polyMesh\boundary'
        """
    def __init__(self,sourceDir,workDir,**kwarg):
        
        #self.bakdir = "/home/export/online3/amd_share/SALOME-9.3.0-CO7-SRC/template/Fluid/"
        self.bakdir = sourceDir / Path('Fluid')
        self.casedir = workDir / Path('Fluid')
        self.accelation = kwarg['acc']
        self.gravity = kwarg['gravity']
        self.liquidratio = kwarg['liquidratio']
        self.boundary_list = kwarg['boundname']
        self.coordinaterang = kwarg['coordrang']
        self.xmin = float(self.coordinaterang[0])
        self.xmax = float(self.coordinaterang[1])
        self.ymin = float(self.coordinaterang[2])
        self.ymax = float(self.coordinaterang[3])
        self.zmin = float(self.coordinaterang[4])
        self.zmax = float(self.coordinaterang[5])
        self.dyne = kwarg['sigma']
        self.mprho = kwarg['mp_rho']
        self.mpnu = kwarg['mp_nu']
        self.sprho = kwarg['sp_rho']
        self.spnu = kwarg['sp_nu']
        self.timestep = kwarg['writetime']
        self.runtimeac = kwarg['runtimeac']
        self.runtimesh = kwarg['runtimesh']

        #时间步长和最大库朗数
        self.delt_time = 0.0001
        self.maxCo = 0.5
        
        # self.zero_dir = self.casedir+r'\0'                             #获取文件件所在路径
        # self.cons_dir = self.casedir+r'\constant' 
        # self.sys_dir = self.casedir+r'\system'
        # self.bd_file = self.cons_dir+r'\polyMesh\boundary'   

        self.zero_dir = self.casedir / '0'                             #获取文件件所在路径
        self.cons_dir = self.casedir / 'constant' 
        self.sys_dir = self.casedir / 'system'
        self.bd_file = self.cons_dir / 'polyMesh' / Path('boundary')

        print('self.zero_dir,',self.zero_dir)
        print('self.cons_dir,',self.cons_dir)
        print('self.sys_dir,',self.sys_dir)
        print('self.bd_file,',self.bd_file)
     
    def meshinitial(self):
        
        #基于模型边界范围扩大1.2倍作为block网格
        #model_coord = list(map(float,self.coordinaterang))
        #box_coord = [x*1.2 for x in model_coord]
        accelation_list = self.accelation.split()
        accelation_floatlist = list(map(float,accelation_list))
        absaccelation = list(map(abs,accelation_floatlist))
        maxaccelation = max(absaccelation)
        
        #固定时间步长为0.001，库朗数0.5，根据流体最大运动速度计算最小网格尺寸
        # meshsize_min = maxaccelation*float(self.runtimeac)*self.delt_time/self.maxCo
        # 网格最小尺度扩大十倍
        meshsize_min = 20 * maxaccelation*float(self.runtimeac)*self.delt_time/self.maxCo

        box_xmin = 1.2*self.xmin
        box_xmax = 1.2*self.xmax
        box_ymin = 1.2*self.ymin
        box_ymax = 1.2*self.ymax
        box_zmin = 1.2*self.zmin
        box_zmax = 1.2*self.zmax

        box_xmin = float('%.3f' % box_xmin)
        box_xmax = float('%.3f' % box_xmax)
        box_ymin = float('%.3f' % box_ymin)
        box_ymax = float('%.3f' % box_ymax)
        box_zmin = float('%.3f' % box_zmin)
        box_zmax = float('%.3f' % box_zmax)
        
        delt_x = (box_xmax-box_xmin)
        delt_y = (box_ymax-box_ymin)
        delt_z = (box_zmax-box_zmin)
        
        
        mindim = min(delt_x,delt_y,delt_z)

        #blockMesh每个方向网格数量
        #meshnum_x = int(delt_x/mindim*50)
        #meshnum_y = int(delt_y/mindim*50)
        #meshnum_z = int(delt_z/mindim*50)

        meshnum_x = int(delt_x/meshsize_min)
        meshnum_y = int(delt_y/meshsize_min)
        meshnum_z = int(delt_z/meshsize_min)



        #根据最新网格尺寸和blockMesh网格尺寸确定网格细分层数
        #refinelevel = int(mindim/50/meshsize_min)
        refinelevel = int(delt_x/meshnum_x/meshsize_min)
        refinelevle_str = str(refinelevel)+' '+str(refinelevel+1)
        
        #内部点，用于修改snappHexMesDict文件
        locatpoint_x = delt_x*(2*meshnum_x+1)/(4*meshnum_x)
        locatpoint_y = delt_y*(2*meshnum_y+1)/(4*meshnum_y)
        locatpoint_z = delt_z*(2*meshnum_z+1)/(4*meshnum_z)

        locatpoint = str(locatpoint_x )+' '+str(locatpoint_y )+' '+str(locatpoint_z )

        #创建blockMeshDict文件
        #print('lineblockmesh=',self.sys_dir+r'/blockMeshDict')
        with open(self.sys_dir / 'blockMeshDict',"w") as f:
            f.write("FoamFile\n{\n    version     2.0;\n")
            f.write("    format     ascii;\n    class      dictionary;\n")
            f.write("""    location   "system";\n    object     blockMeshDict;\n}""")
            f.write("\n//**********************************************//\n")
            f.write("\nconvertToMeters 1;\n\nvertices\n(\n")
            f.write("    ("+str(box_xmin)+" "+str(box_ymin)+" "+str(box_zmin)+")\n")
            f.write("    ("+str(box_xmax)+" "+str(box_ymin)+" "+str(box_zmin)+")\n")
            f.write("    ("+str(box_xmax)+" "+str(box_ymax)+" "+str(box_zmin)+")\n")
            f.write("    ("+str(box_xmin)+" "+str(box_ymax)+" "+str(box_zmin)+")\n")
            f.write("    ("+str(box_xmin)+" "+str(box_ymin)+" "+str(box_zmax)+")\n")
            f.write("    ("+str(box_xmax)+" "+str(box_ymin)+" "+str(box_zmax)+")\n")
            f.write("    ("+str(box_xmax)+" "+str(box_ymax)+" "+str(box_zmax)+")\n")
            f.write("    ("+str(box_xmin)+" "+str(box_ymax)+" "+str(box_zmax)+")\n")
            f.write(");\n\nblocks\n(\n    hex (0 1 2 3 4 5 6 7) fluid (")
            f.write(str(meshnum_x)+" "+str(meshnum_y)+" "+str(meshnum_z)+")")
            f.write(" simpleGrading (1 1 1)\n);\n\nedges\n(\n);\n\n")
            f.write("defaultPatch\n{\n    type empty;\n    name default;\n}\n\n")
            f.write("boundary\n(\n);")
            f.close
            
        # 创建snappyHexMeshDict文件
        with open(self.bakdir / 'system/snappyHexMeshDict') as f:
            lines = f.readlines()
            f.close
        with open(self.sys_dir / 'snappyHexMeshDict',"w") as f:
            f.writelines(lines[0:30])
            for bound in self.boundary_list:
                f.write('    '+bound+'.stl\n')
                f.write("    {\n")
                f.write("        type triSurfaceMesh;\n")
                f.write("        name "+bound+";\n")
                f.write("    }\n\n")
            f.writelines(lines[54:74])
            f.write("    maxLocalCells 10000000;\n")
            f.write("    maxGlobalCells 15000000;\n")
            f.write("    minRefinementCells 5;\n")
            f.write("    maxLoadUnbalance 0.10;\n")
            f.write("    nCellsBetweenLevels 3;\n\n")
            f.writelines(lines[115:122])
            f.writelines(lines[133:136])
            for bound in self.boundary_list:
                f.write('        '+bound+'\n')
                f.write('        {\n')
                f.write('            level ('+refinelevle_str+');\n')
                f.write('            patchInfo\n')
                f.write('            {\n')
                f.write('                type wall;\n')
                f.write('            }\n')
                f.write('        }\n\n')
            f.write('    }\n\n')
            f.write('    resolveFeatureAngle 30;\n\n')
            f.write('    refinementRegions\n    {\n    }\n\n')
            f.write('    locationInMesh (0 0 0);\n\n')
            # f.write('    locationInMesh ('+locatpoint+');\n\n')
            f.write('    allowFreeStandingZoneFaces true;\n}\n\n')
            f.writelines(lines[246:281])
            f.writelines(lines[284:433])
            f.write('mergeTolerance 1e-6;\n')
            f.close

    def siminitial(self):
        
        #self.boundary_list = self.findboundary()
        #确定重力方向
        #将重力及加速度字符串转成字符串列表
        accelation_list = self.accelation.split()
        gravity_list = self.gravity.split()
        
        #将字符串列表转换成浮点数列表
        accelation_floatlist = list(map(float,accelation_list))
        gravity_floatlist = list(map(float,gravity_list))
        
        #确定g文件数值
        accfinal_1 = accelation_floatlist[0]+gravity_floatlist[0]
        accfinal_2 = accelation_floatlist[1]+gravity_floatlist[1]
        accfinal_3 = accelation_floatlist[2]+gravity_floatlist[2]
        
        g_x = float('%.3f' % accfinal_1)
        g_y = float('%.3f' % accfinal_2)
        g_z = float('%.3f' % accfinal_3)
        
        #initialize 0/U
        with open(self.bakdir / '0/U') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'U',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            fixedValue;\n""")
                f.write("""        value           uniform (0 0 0);\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
            
        #initialize 0/p_rgh
        with open(self.bakdir / '0/p_rgh') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'p_rgh',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            fixedFluxPressure;\n""")
                f.write("""        gradient        uniform 0;\n""")
                f.write("""        value           uniform 0;\n    }\n""")
            f.write('}')
            f.close        
        
        #initialize 0/k        
        with open(self.bakdir / '0/k') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'k',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            kqRWallFunction;\n""")
                f.write("""        value           uniform 0.05;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
        
        #initialize 0/epsilon
        with open(self.bakdir / '0/epsilon') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'epsilon',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            epsilonWallFunction;\n""")
                f.write("""        value           uniform 0.01;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
        
        #initialize 0/nut
        with open(self.bakdir / '0/nut') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'nut',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            nutkWallFunction;\n""")
                f.write("""        value           uniform 0;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
        
        #initialize 0/nuTilda
        with open(self.bakdir / '0/nuTilda') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'nuTilda',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            zeroGradient;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close        
                
        #initialize 0/alpha.water         
        with open(self.bakdir / '0/alpha.water') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'alpha.water',"w") as f:
            f.writelines(lines[0:22])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            zeroGradient;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
            
        #initialize 0/pointDisplacement   
        with open(self.bakdir / '0/pointDisplacement') as f:
            lines = f.readlines()
            f.close
        with open(self.zero_dir / 'pointDisplacement',"w") as f:
            f.writelines(lines[0:23])
            for bound in self.boundary_list:
                f.write('    '+bound+'\n')
                f.write("""    {\n""")
                f.write("""        type            fixedValue;\n""")
                f.write("""        value           $internalField;\n""")
                f.write("""    }\n""")
            f.write('}')
            f.close
            
        # initilize constant/g
        #加速阶段g
        gfile_ac=open(self.cons_dir / 'g_ac',mode="w+",encoding="utf-8")
        with open(self.bakdir / 'constant/g') as f:
            for line,content in enumerate(f,1):
                #print(content)
                if "value" in content:
                    i=content.find('(')
                    new_g=str(g_x)+' '+str(g_y)+' '+str(g_z)
                    gfile_ac.write(content[:i+1]+new_g+');\n')
                else:
                    gfile_ac.write(content)
            f.close
        gfile_ac.close
        #自由晃动阶段g
        gfile_sh=open(self.cons_dir / 'g_sh',mode="w+",encoding="utf-8")
        with open(self.bakdir / 'constant/g') as f:
            for line,content in enumerate(f,1):
                #print(content)
                if "value" in content:
                    i=content.find('(')
                    #new_g=str(g_x)+' '+str(g_y)+' '+str(g_z)
                    gfile_sh.write(content[:i+1]+self.gravity+');\n')
                else:
                    gfile_sh.write(content)
            f.close
        gfile_ac.close
        
        # initilize constant/transportProperties
        with open(self.bakdir / 'constant/transportProperties') as f:
            lines = f.readlines()
            f.close
        with open(self.cons_dir / 'transportProperties',"w") as f:
            f.writelines(lines[0:22])
            f.write('    nu              '+self.mpnu+';\n')
            f.write('    rho             '+self.mprho+';\n}\n')
            f.writelines(lines[25:29])
            f.write('    nu              '+self.spnu+';\n')
            f.write('    rho             '+self.sprho+';\n}\n')
            f.writelines(lines[32])
            f.write('sigma           '+self.dyne+';\n')
            f.close
        
        # initilize constant/dynamicMeshDict
        dynaMD_file = open(self.cons_dir / 'dynamicMeshDict',mode="w+")
        with open(self.bakdir / 'constant/dynamicMeshDict') as f:
            for line,content in enumerate(f,1):
                if 'diffusivity quadratic inverseDistance' in content:
                    i = content.find('(')
                    bd = ' '.join(self.boundary_list)
                    dynaMD_file.write(content[:i+1]+bd+');')
                else:
                    dynaMD_file.write(content)
            f.close
        dynaMD_file.close
                    
        
        # initilize system/controlDict
        deltaT = float(self.timestep)
        runtime_ac = float(self.runtimeac)
        runtime_sh = float(self.runtimesh)
        with open(self.bakdir / 'system/controlDict') as f:
            lines = f.readlines()
            f.close
        #加速阶段controlDict文件
        with open(self.sys_dir / 'controlDict_ac',"w") as f:
            f.writelines(lines[0:21])
            f.write('startTime       0;\n')
            f.writelines(lines[22:25])
            f.write('endTime         '+str(runtime_ac)+';\n\n')
            #f.write('deltaT          '+str(deltaT)+';\n')
            f.write('deltaT          '+str(self.delt_time)+';\n')
            f.writelines(lines[28:31])
            f.write('writeInterval   '+str(deltaT)+';\n')
            f.writelines(lines[32:])
            f.close
        #晃动阶段controlDict文件
        with open(self.sys_dir / 'controlDict_sh',"w") as f:
            f.writelines(lines[0:19])
            f.write('startFrom       latestTime;\n')
            f.writelines(lines[20:25])
            f.write('endTime         '+str(runtime_ac+runtime_sh)+';\n\n')
            f.write('deltaT          '+str(self.delt_time)+';\n')
            f.writelines(lines[28:31])
            f.write('writeInterval   '+str(deltaT)+';\n')
            f.writelines(lines[32:])
            f.close

        # initilize system/setFieldsDict
        #判断重力方向
        gdim =[0,0,0]
        gdim[0] = gravity_floatlist[0]/abs(sum(gravity_floatlist))
        gdim[1] = gravity_floatlist[1]/abs(sum(gravity_floatlist))
        gdim[2] = gravity_floatlist[2]/abs(sum(gravity_floatlist))
        
        #用于判读非重力方向的box外扩
        gdimsum = sum(gdim)
        gdim_2 = [abs((x-gdimsum)/gdimsum)*0.1 for x in gdim]
        
        #用于重力方向box范围确定
        gdim = [x*(1-float(self.liquidratio)) for x in gdim]
        
        #根据重力方向计算boxToCell的点
        if sum(gdim) <= 0 :
            #最小点
            pt1_x = self.xmin-0.1*abs(self.xmin)
            pt1_y = self.ymin-0.1*abs(self.ymin)
            pt1_z = self.zmin-0.1*abs(self.zmin)
            
            pt1_x = float('%.3f' % pt1_x)
            pt1_y = float('%.3f' % pt1_y)
            pt1_z = float('%.3f' % pt1_z)
            
            #最大点
            pt2_x = self.xmax+(self.xmax-self.xmin)*gdim[0]
            pt2_y = self.ymax+(self.ymax-self.ymin)*gdim[1]
            pt2_z = self.zmax+(self.zmax-self.zmin)*gdim[2]
            
            pt2_x = pt2_x+gdim_2[0]*abs(pt2_x)
            pt2_y = pt2_y+gdim_2[1]*abs(pt2_y)
            pt2_z = pt2_z+gdim_2[2]*abs(pt2_z)
            
            pt2_x = float('%.3f' % pt2_x)
            pt2_y = float('%.3f' % pt2_y)
            pt2_z = float('%.3f' % pt2_z)
        else:
            
            pt2_x = self.xmax+0.1*abs(self.xmin)
            pt2_y = self.ymax+0.1*abs(self.ymin)
            pt2_z = self.zmax+0.1*abs(self.zmin)
            
            pt2_x = float('%.3f' % pt2_x)
            pt2_y = float('%.3f' % pt2_y)
            pt2_z = float('%.3f' % pt2_z)
                        
            pt1_x = self.xmin+(self.xmax-self.xmin)*gdim[0]
            pt1_y = self.ymin+(self.ymax-self.ymin)*gdim[1]
            pt1_z = self.zmin+(self.zmax-self.zmin)*gdim[2]
            
            pt1_x = pt1_x-gdim_2[0]*abs(pt1_x)
            pt1_y = pt1_y-gdim_2[1]*abs(pt1_y)
            pt1_z = pt1_z-gdim_2[2]*abs(pt1_z)
            
            pt1_x = float('%.3f' % pt1_x)
            pt1_y = float('%.3f' % pt1_y)
            pt1_z = float('%.3f' % pt1_z)
        
        point1 = str(pt1_x)+' '+str(pt1_y)+' '+str(pt1_z)
        point2 = '('+str(pt2_x)+' '+str(pt2_y)+' '+str(pt2_z)
        
        new_sFDfile=open(self.sys_dir / 'setFieldsDict',mode="w+")
        with open(self.bakdir / 'system/setFieldsDict') as f:
            for line,content in enumerate(f,1):
                if "box " in content:
                    i=content.find('(')
                    new_sFD=point1+') '+point2
                    new_sFDfile.write(content[:i+1]+new_sFD+');\n')
                else:
                    new_sFDfile.write(content)
            f.close
        new_sFDfile.close
        
        # initilize system/fvSolution
        #设置压力参考点
        pRefPoint_x = 0.5*(pt1_x+pt2_x)
        pRefPoint_y = 0.5*(pt1_y+pt2_y)
        pRefPoint_z = 0.5*(pt1_z+pt2_z)
        pRefPoint_x = float('%.3f' % pRefPoint_x)
        pRefPoint_y = float('%.3f' % pRefPoint_y)
        pRefPoint_z = float('%.3f' % pRefPoint_z)
        pRefPoint = str(pRefPoint_x)+' '+str(pRefPoint_y)+' '+str(pRefPoint_z)
        
        fvSfile = open(self.sys_dir / 'fvSolution',mode="w+")
        with open(self.bakdir / 'system/fvSolution') as f:
            for line,content in enumerate(f,1):
                if "pRefPoint" in content:
                    i=content.find('t')
                    fvSfile.write(content[:i+1]+'      ('+pRefPoint+');\n')
                else:
                    fvSfile.write(content)
            f.close
        fvSfile.close
        
        #initilize precice-adapter-config.yml
        with open(self.bakdir / 'precice-adapter-config.yml') as f:
            lines = f.readlines()
            f.close
        with open(self.casedir / 'precice-adapter-config.yml','w') as f:
            f.writelines(lines[:8])
            for wall in self.boundary_list:
                f.write('  - '+wall+'\n')
            f.writelines(lines[12:16])
            for wall in self.boundary_list:
                f.write('  - '+wall+'\n')
            f.writelines(lines[20:])     
                      
    def findboundary(self):
        boundary=[]
        with open(self.bd_file) as f:     
          for line,content in enumerate(f,1):
              if "type" in content:
                  #line2=line-2
                  count = linecache.getline(self.bd_file,line-2)
                  boundary.append(count.strip())
        return boundary
    
    #def findmaxmin(self):
       # with open()
    
if __name__ == '__main__':
    
    sourcedir = 'E:\\software study\\Qt\\1. Tanksimulator\\1. test\\tankVOF'
    workdir = 'F:\\work_NSCC\\3. projects\\1. Baffle plate\\tankVOF'
    maxmin = ['-1.0','1.0','-1.0','1.0','-4.0','4.0']
    boundary = ['tankwall','bafflewall','frontwall','backwall']
    parame = dict(acc='0 0 5',gravity ='0 -9.81 0',liquidratio='0.8',
                  coordrang=maxmin,sigma='0.08',mp_rho='1200',mp_nu='0.01',
                  sp_rho='1.2',sp_nu='0.1',boundname=boundary,writestep='0.05',
                  runtimeac='4',runtimesh='5')
    casetest = Fluidinitial(sourcedir,workdir,**parame)
    """
    casetest = Fluidinitial('F:\\work_NSCC\\3. projects\\1. Baffle plate\\'+\
'tankVOF\\damBreak','-9.81 0 0','0.8','-1.11','1.1','-1.1','1.1','-3.31','3.31',
'0.06','1000','0.01','1.2','0.1')
    """
    casetest.meshinitial()
    casetest.siminitial()
    
    




