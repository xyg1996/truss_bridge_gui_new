
"""
Created on Thu Dec  5 11:08:19 2019

@author: ZHL
"""

import sys
import os
import json
#from PyQt5 import QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from .TankSimlator_Ui import Ui_Form
from .globalvalue import global_value
#from globalvalue import global_value


class MainWindow(QWidget):

    def __init__(self):
        super(MainWindow,self).__init__()
        self.ui = Ui_Form()
        self.ui.setupUI(self)
        
                
        self.ui.bt_open.clicked.connect(self.slot_btn_chooseFile)
        self.ui.bt_save.clicked.connect(self.slot_btn_saveFile)
        
        
    def slot_btn_chooseFile(self):
        # fileName_choose, filetype = QFileDialog.getOpenFileName(self,  
        #                             "选取文件",  
        #                             global_value.workDic, # 起始路径 
        #                             "JSON Files (*.json);;All Files (*)")   # 设置文件扩展名过滤,用双分号间隔

        fileName_choose = global_value.workDic+'/savedata.json'
        if fileName_choose != "":
            #self.qle_chooseFile.setText(fileName_choose)
            global_value.oldcaseDic = fileName_choose
            with open(fileName_choose) as file:
                
                casedata = json.load(file)
                #流体界面参数填充
                fluiddata = casedata['fluid']
                globaldata = fluiddata['globalValue']
                self.ui.le_Liquidratio.setText(globaldata['Liquidratio'])
                self.ui.le_Acceleration.setText(globaldata['Acceleration'])
                self.ui.le_dyne.setText(globaldata['Dyne'])
                self.ui.le_Gravit.setText(globaldata['Gravity'])
                
                phasedata = fluiddata['phaseValue']
                mainphasedata = phasedata['mainPhase']
                secphasedata = phasedata['secPhase']
                self.ui.le_mprho.setText(mainphasedata['Density'])
                self.ui.le_mpnu.setText(mainphasedata['Viscosity'])
                self.ui.le_sprho.setText(secphasedata['Density'])
                self.ui.le_spnu.setText(secphasedata['Viscosity'])
                
                #固体界面参数填充
                soliddata = casedata['solid']
                self.ui.le_poisson.setText(soliddata['Possinratio'])
                self.ui.le_cpa.setText(soliddata['Youngmodulus'])
                self.ui.le_solidrho.setText(soliddata['Solidrho'])
                
                #耦合界面参数填充
                coupledata = casedata['couple']
                self.ui.le_writetime.setText(coupledata['Writetime'])
                self.ui.le_runtimeac.setText(coupledata['Runtimeac'])
                self.ui.le_monpoint.setText(coupledata['Monpoint'])
                self.ui.le_runtimesh.setText(coupledata['Runtimesh'])
                
                file.close
                
                lb = "文件"+fileName_choose+"已打开"
                #lb.setFont(QFont("Microsoft YaHei", 10))
                # butt = QMessageBox.information(self,"提示",lb)
                
            return 
    def slot_btn_saveFile(self):
        # fileName_choose, filetype = QFileDialog.getSaveFileName(self,  
        #                             "文件保存",  
        #                             global_value.workDic, # 起始路径 
        #                             "All Files (*);;JSON Files (*.json)")  
        # fileName_choose = global_value.workDic
        fileName_choose = global_value.workDic
        if fileName_choose != "":
            
            data = {
                'fluid':{
                        'globalValue':{
                                'Liquidratio': self.ui.le_Liquidratio.text(),
                                'Acceleration': self.ui.le_Acceleration.text(),
                                'Dyne':self.ui.le_dyne.text(),
                                'Gravity':self.ui.le_Gravit.text()
                            },
                        'phaseValue':{
                                'mainPhase':{
                                        'Density': self.ui.le_mprho.text(),
                                        'Viscosity': self.ui.le_mpnu.text()
                                        },
                                'secPhase':{
                                        'Density': self.ui.le_sprho.text(),
                                        'Viscosity': self.ui.le_spnu.text()
                                        }
                                }   
                            },
                'solid':{
                        'Possinratio':self.ui.le_poisson.text(),
                        'Youngmodulus':self.ui.le_cpa.text(),
                        'Solidrho':self.ui.le_solidrho.text()
                        },
                'couple':{
                        'Writetime': self.ui.le_writetime.text(),
                        'Runtimeac': self.ui.le_runtimeac.text(),
                        'Runtimesh': self.ui.le_runtimesh.text(),
                        'Monpoint': self.ui.le_monpoint.text()
                        }
                }
            
            with open(fileName_choose,'w') as savefile:
                #finalsave = dict(list(fluidsave.items())+list(solidsave.items())+list(couplesave.items()))
                json.dump(data,savefile,indent=4)
                savefile.close
            return
            
        
            lb = "文件已保存至"+fileName_choose
            #lb.setFont(QFont("Microsoft YaHei", 10))
            butt = QMessageBox.information(self,"提示",lb)        
        
    def savetopath(self,path):
        global_value.workDic = path
        self.slot_btn_saveFile()

    def choosefrompath(self,path):
        global_value.workDic = path
        self.slot_btn_chooseFile()

    def getdic(self):
        data = {
            'fluid':{
                    'globalValue':{
                            'Liquidratio': self.ui.le_Liquidratio.text(),
                            'Acceleration': self.ui.le_Acceleration.text(),
                            'Dyne':self.ui.le_dyne.text(),
                            'Gravity':self.ui.le_Gravit.text()
                        },
                    'phaseValue':{
                            'mainPhase':{
                                    'Density': self.ui.le_mprho.text(),
                                    'Viscosity': self.ui.le_mpnu.text()
                                    },
                            'secPhase':{
                                    'Density': self.ui.le_sprho.text(),
                                    'Viscosity': self.ui.le_spnu.text()
                                    }
                            }   
                        },
            'solid':{
                    'Possinratio':self.ui.le_poisson.text(),
                    'Youngmodulus':self.ui.le_cpa.text(),
                    'Solidrho':self.ui.le_solidrho.text()
                    },
            'couple':{
                    'Writetime': self.ui.le_writetime.text(),
                    'Runtimeac': self.ui.le_runtimeac.text(),
                    'Runtimesh': self.ui.le_runtimesh.text(),
                    'Monpoint': self.ui.le_monpoint.text()
                    }
            }
        return data

class WdWindow(QWidget):

    def __init__(self):
        super(WdWindow,self).__init__()
        self.initUI()
        
    def initUI(self):
        hbox = QHBoxLayout(self)
        self.setWindowTitle("创建工作路径")
        self.btn_chooseDir = QPushButton()  
        self.btn_chooseDir.setObjectName("btn_chooseDir")  
        self.btn_chooseDir.setText("确定工作路径")
        self.btn_chooseDir.setToolTip("""You need to choose a folder""")
        self.btn_chooseDir.setFixedWidth(100)
        self.btn_chooseDir.setFont(QFont("Microsoft YaHei", 12))
        
        self.qle_chooseDir = QLineEdit()
        self.qle_chooseDir.setAlignment(Qt.AlignRight)
        self.qle_chooseDir.setFixedWidth(400)
        self.qle_chooseDir.setFont(QFont("Times New Roman", 11))
        
        layout = QFormLayout()
        layout.addRow(self.btn_chooseDir,self.qle_chooseDir)
        
        hbox.addLayout(layout)
        self.setLayout(hbox)
        
        self.btn_chooseDir.clicked.connect(self.slot_btn_chooseDir)
        
        
    def slot_btn_chooseDir(self):
        
        dir_choose = QFileDialog.getExistingDirectory(self,  
                                    "选取文件夹",  
                                    global_value.workDic) # 起始路径
    
        if dir_choose != "":
            self.qle_chooseDir.setText(dir_choose)
            #self.cwd = dir_choose
            global_value.workDic = dir_choose
            
      
                
        
if __name__ == "__main__":

    app = QApplication(sys.argv)
    font = QFont("Microsoft YaHei",14)
    app.setFont(font)
    window = MainWindow()
    wdwindow = WdWindow()
    #window.resize(1000, 800)
    window.show()
    wdwindow.show()
    sys.exit(app.exec_())
