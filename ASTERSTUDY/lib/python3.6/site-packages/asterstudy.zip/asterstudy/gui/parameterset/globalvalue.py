
"""
Created on Wed Nov 27 16:16:32 2019

@author: ZHL
"""

class global_value():
    workDic = 'E:\software study\Qt'
    oldcaseDic = ''