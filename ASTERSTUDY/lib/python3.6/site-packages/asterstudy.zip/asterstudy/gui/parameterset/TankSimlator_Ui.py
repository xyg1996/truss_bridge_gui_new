
"""
Created on Thu Dec  5 09:13:18 2019

@author: ZHL
"""

#-*- coding:utf-8 -*-

import sys
import json
import os
#from PyQt5 import QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
#from setstack1UI import stack1UI
#from globalvalue import global_value


class Ui_Form(object):

    '''
    def __init__(self):
        super(Ui_Form,self).__init__()
        self.setupUI(self)
        self.setWindowIcon(QIcon('./timg.jpg'))
    '''
     
    def setupUI(self,window):
        
        #window.setWindowTitle("Tank Simulator")
        
        self.glolayout = QVBoxLayout(window)
        
        #流体参数数值框
        self.fluidbox = QGroupBox('流体参数设置')
        self.fluidlayout = QHBoxLayout()
        self.fluid_letf = QFormLayout()
        self.fluid_right = QFormLayout()
        
        #液高比设置
        self.lb_Liquidratio = QLabel("液高比([0.0~1.0]):")
        self.lb_Liquidratio.setFixedWidth(160)
        self.lb_Liquidratio.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_Liquidratio.setFont(QFont("Microsoft YaHei",12))
        self.lb_Liquidratio.setToolTip('Set the proportion of the main phase,'+\
                                  'usually water or denser liquid')
        self.le_Liquidratio = QLineEdit()
        self.le_Liquidratio.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_Liquidratiovalid = QDoubleValidator()    #设定范围
        self.le_Liquidratiovalid.setRange(0.0,1.0)    #限定范围自身有bug
        self.le_Liquidratiovalid.setNotation(QDoubleValidator.StandardNotation)
        self.le_Liquidratiovalid.setDecimals(12)
        self.le_Liquidratio.setValidator(self.le_Liquidratiovalid)
        self.le_Liquidratio.setFixedWidth(100)
        self.le_Liquidratio.setFont(QFont("Times New Roman",11))
        
        #加速度设置
        self.lb_Acceleration = QLabel("加速度(m/s^2):")
        self.lb_Acceleration.setFixedWidth(160)
        self.lb_Acceleration.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_Acceleration.setFont(QFont("Microsoft YaHei", 12))
        self.lb_Acceleration.setToolTip('Set the acceleration in three'+\
                                        ' directions(separated by'+\
                       'space), wihtout gravitational acceleration')
        self.le_Acceleration = QLineEdit()
        self.le_Acceleration.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_Acceleration.setFixedWidth(100)
        self.le_Acceleration.setFont(QFont("Times New Roman", 11))
        
        #表面张力设置
        self.lb_dyne = QLabel("表面张力(N/m)")
        self.lb_dyne.setFixedWidth(160)
        self.lb_dyne.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_dyne.setFont(QFont("Microsoft YaHei", 12))
        self.le_dyne = QLineEdit()
        self.le_dyne.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_dyne.setFixedWidth(100)
        self.le_dyne.setFont(QFont("Times New Roman", 11))
        
        #重力设置
        self.lb_Gravit = QLabel("重力(m/s^2):")
        self.lb_Gravit.setFixedWidth(160)
        self.lb_Gravit.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_Gravit.setFont(QFont("Microsoft YaHei", 12))
        self.lb_Gravit.setToolTip('Set the gravitational acceleration')
        self.le_Gravit = QLineEdit()
        self.le_Gravit.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_Gravit.setFixedWidth(100)
        self.le_Gravit.setFont(QFont("Times New Roman", 11))
        
        # 主相参数设置
        self.lb_mainphase = QLabel("主相参数：   ")
        self.lb_mainphase.setFont(QFont("Microsoft YaHei", 12))
        
        # row4
        self.lb_mprho = QLabel("密度(kg/m^3):")
        self.lb_mprho.setFixedWidth(160)
        self.lb_mprho.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_mprho.setFont(QFont("Microsoft YaHei", 12))
        self.le_mprho = QLineEdit()
        self.le_mprho.setAlignment(Qt.AlignRight)
        self.le_mprho.setFixedWidth(100)
        self.le_mprho.setFont(QFont("Times New Roman", 11))
        
        #row5
        self.lb_mpnu = QLabel("运动粘性系数(m^2/s):")
        self.lb_mpnu.setFixedWidth(160)
        self.lb_mpnu.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_mpnu.setFont(QFont("Microsoft YaHei", 12))
        self.le_mpnu = QLineEdit()
        self.le_mpnu.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_mpnu.setFixedWidth(100)
        self.le_mpnu.setFont(QFont("Times New Roman", 11))
        
        #次相参数设置
        self.lb_secphase = QLabel("次相参数：")
        self.lb_secphase.setFont(QFont("Microsoft YaHei", 12))
        
        #row7
        self.lb_sprho = QLabel("密度(kg/m^3):")
        self.lb_sprho.setFixedWidth(160)
        self.lb_sprho.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_sprho.setFont(QFont("Microsoft YaHei", 12))
        self.le_sprho = QLineEdit()
        self.le_sprho.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_sprho.setFixedWidth(100)
        self.le_sprho.setFont(QFont("Times New Roman", 11))
        
        #row8
        self.lb_spnu = QLabel("运动粘性系数(m^2/s):")
        self.lb_spnu.setFixedWidth(160)
        self.lb_spnu.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_spnu.setFont(QFont("Microsoft YaHei", 12))
        self.le_spnu = QLineEdit()
        self.le_spnu.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_spnu.setFixedWidth(100)
        self.le_spnu.setFont(QFont("Times New Roman", 11))
        
        
        self.fluid_letf.addRow(self.lb_Liquidratio,self.le_Liquidratio)
        self.fluid_letf.addRow(self.lb_Acceleration,self.le_Acceleration)
        self.fluid_letf.addRow(self.lb_mainphase)
        self.fluid_letf.addRow(self.lb_mprho,self.le_mprho)
        self.fluid_letf.addRow(self.lb_mpnu,self.le_mpnu)
        
        self.fluid_right.addRow(self.lb_dyne,self.le_dyne)
        self.fluid_right.addRow(self.lb_Gravit,self.le_Gravit)
        self.fluid_right.addRow(self.lb_secphase)
        self.fluid_right.addRow(self.lb_sprho,self.le_sprho)
        self.fluid_right.addRow(self.lb_spnu,self.le_spnu)
        
        #流体模块布局
        #self.fluidlayout.addStretch(1)
        self.fluidlayout.addLayout(self.fluid_letf)
        self.fluidlayout.addStretch(1)
        self.fluidlayout.addLayout(self.fluid_right)
        #self.fluidlayout.setStretch(0,1)
        #self.fluidlayout.setStretch(1,1)
        self.fluidlayout.addStretch(1)
        self.fluidbox.setLayout(self.fluidlayout)
 
        #固体参数设置模块
        self.solidbox = QGroupBox('固体参数设置')
        self.solidlayout = QHBoxLayout()
        self.solid_left = QFormLayout()
        self.solid_right = QFormLayout()
        
        self.lb_poisson = QLabel("泊松比:")
        self.lb_poisson.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_poisson.setFixedWidth(160)
        self.lb_poisson.setFont(QFont("Microsoft YaHei", 12))
        self.le_poisson = QLineEdit()
        self.le_poisson.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_poisson.setFixedWidth(100)
        self.le_poisson.setFont(QFont("Times New Roman", 11))
        
        self.lb_cpa = QLabel("杨氏模量(n/m^2):")
        self.lb_cpa.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_cpa.setFixedWidth(160)
        self.lb_cpa.setFont(QFont("Microsoft YaHei", 12))
        self.le_cpa = QLineEdit()
        self.le_cpa.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_cpa.setFixedWidth(100)
        self.le_cpa.setFont(QFont("Times New Roman", 11))
        
        self.lb_solidrho = QLabel("材料密度(kg/m^3):")
        self.lb_solidrho.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_solidrho.setFixedWidth(160)
        self.lb_solidrho.setFont(QFont("Microsoft YaHei", 12))
        self.le_solidrho = QLineEdit()
        self.le_solidrho.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_solidrho.setFixedWidth(100)
        self.le_solidrho.setFont(QFont("Times New Roman", 11))
        
        self.solid_left.addRow(self.lb_poisson,self.le_poisson)
        self.solid_left.addRow(self.lb_solidrho,self.le_solidrho)
        
        self.solid_right.addRow(self.lb_cpa,self.le_cpa)
        
        self.solidlayout.addLayout(self.solid_left)
        self.solidlayout.addStretch(1)
        self.solidlayout.addLayout(self.solid_right)
        self.solidlayout.addStretch(1)
        
        self.solidbox.setLayout(self.solidlayout)
        
        #仿真参数设置模块
        self.couplebox = QGroupBox('仿真参数设置')
        self.couplelayout = QHBoxLayout()
        self.couple_left = QFormLayout()
        self.couple_right = QFormLayout()
        
        self.lb_writetime = QLabel("结果保存时间间隔(s):")
        self.lb_writetime.setFixedWidth(160)
        self.lb_writetime.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_writetime.setFont(QFont("Microsoft YaHei", 12))
        self.le_writetime = QLineEdit()
        self.le_writetime.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_writetime.setFixedWidth(100)
        self.le_writetime.setFont(QFont("Times New Roman", 11))
        
        self.lb_runtimeac = QLabel("刹车阶段仿真时长:")
        self.lb_runtimeac.setFixedWidth(160)
        self.lb_runtimeac.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_runtimeac.setFont(QFont("Microsoft YaHei", 12))
        self.le_runtimeac = QLineEdit()
        self.le_runtimeac.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_runtimeac.setFixedWidth(100)
        self.le_runtimeac.setFont(QFont("Times New Roman", 11))
        
        self.lb_runtimesh = QLabel("自由晃动仿真时长:")
        self.lb_runtimesh.setFixedWidth(160)
        self.lb_runtimesh.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_runtimesh.setFont(QFont("Microsoft YaHei", 12))
        self.le_runtimesh = QLineEdit()
        self.le_runtimesh.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_runtimesh.setFixedWidth(100)
        self.le_runtimesh.setFont(QFont("Times New Roman", 11))
        
        self.lb_monpoint = QLabel("监控点:")
        self.lb_monpoint.setFixedWidth(160)
        self.lb_monpoint.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        self.lb_monpoint.setFont(QFont("Microsoft YaHei", 12))
        self.le_monpoint = QLineEdit()
        self.le_monpoint.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.le_monpoint.setFixedWidth(100)
        self.le_monpoint.setFont(QFont("Times New Roman", 11))
        
        self.couple_left.addRow(self.lb_writetime,self.le_writetime)
        self.couple_left.addRow(self.lb_runtimeac,self.le_runtimeac)
        
        self.couple_right.addRow(self.lb_monpoint,self.le_monpoint)
        self.couple_right.addRow(self.lb_runtimesh,self.le_runtimesh)
        
        #self.couplelayout.addStretch(1)
        self.couplelayout.addLayout(self.couple_left)
        self.couplelayout.addStretch(1)
        self.couplelayout.addLayout(self.couple_right)
        self.couplelayout.addStretch(1)
        
        self.couplebox.setLayout(self.couplelayout)
        
        #文件创建及保存模块
        self.filewidget = QWidget()
        
        self.bt_open = QPushButton("打开")
        self.bt_open.setFont(QFont("Microsoft YaHei",12))
        self.bt_open.setFixedWidth(100)
        #self.is_saved = False
        #pushbut1.clicked.connect(self.save1)
        
        self.bt_save = QPushButton("保存")
        self.bt_save.setFont(QFont("Microsoft YaHei",12))
        self.bt_save.setFixedWidth(100)
        #self.bt_save.hide()
        #self.is_saved = False
        #pushbut1.clicked.connect(self.save1)  #点击保存按钮
        
        #self.bt_calcu = QPushButton("开始计算")
        #self.bt_calcu.setFont(QFont("Microsoft YaHei",12))
        #self.bt_calcu.setFixedWidth(100)
        
        self.filelayout = QHBoxLayout()
        self.filelayout.addStretch(1)
        self.bt_open.hide()
        self.bt_save.hide()
        # self.filelayout.addWidget(self.bt_open)
        # self.filelayout.addWidget(self.bt_save)
        #self.filelayout.addWidget(self.bt_calcu)
        
        
        self.filelayoutV = QVBoxLayout()
        self.filelayoutV.addLayout(self.filelayout)
        self.filelayoutV.addStretch(1)
        self.filewidget.setLayout(self.filelayoutV)
        
        #全局布局设置模块
        self.glolayout.addWidget(self.fluidbox)
        self.glolayout.addWidget(self.solidbox)
        self.glolayout.addWidget(self.couplebox)
        self.glolayout.addWidget(self.filewidget)
        # self.glolayout.setStretch(0,2)
        # self.glolayout.setStretch(1,1)
        # self.glolayout.setStretch(2,1)
        # self.glolayout.setStretch(3,1)
        window.setLayout(self.glolayout)  


if __name__ == "__main__":

    app = QApplication(sys.argv)
    font = QFont("Microsoft YaHei",14)
    app.setFont(font)
    window = Ui_Form()
    #window.resize(1000, 800)
    window.show()
    sys.exit(app.exec_())