

#

#
# Author : Renaud Nédélec (OpenCascade S.A.S)

from salome.geom.t_shape import t_shape_builder
from qtsalome import *

class t_shape_progress():
    _totSteps = 0
    _nmaxSteps = 27
    
    def __init__(self, parent=None):
      # QProgressDialog.__init__(self, "t_shape fluid build", "stop", 0, self._nmaxSteps, parent, Qt.Tool)
      # self.show()
      pass
        
    def run(self, r1, r2, h1, h2, thickness):
      shape = t_shape_builder.build_shape(r1, r2, h1, h2, thickness, self)
      self.setValue(self._nmaxSteps)
      return shape
      
    def addSteps(self, nbSteps):
      self._totSteps += nbSteps
      self.setValue(self._totSteps)
