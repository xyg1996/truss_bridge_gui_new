

# Form implementation generated from reading ui file 'E:/S-9.3.0/MODULES/SRC/GEOM_SRC/src/Tools/t_shape/t_shape_dialog.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(349, 283)
        self.setMaximumWidth(380)
        self.gridLayout_3 = QtWidgets.QGridLayout(Dialog)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.dsb_smallRadius = QtWidgets.QDoubleSpinBox(Dialog)
        self.dsb_smallRadius.setDecimals(5)
        self.dsb_smallRadius.setMaximum(100000.0)
        self.dsb_smallRadius.setProperty("value", 40.0)
        self.dsb_smallRadius.setObjectName("dsb_smallRadius")
        self.gridLayout.addWidget(self.dsb_smallRadius, 2, 1, 1, 1)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.dsb_bigHeight = QtWidgets.QDoubleSpinBox(Dialog)
        self.dsb_bigHeight.setDecimals(5)
        self.dsb_bigHeight.setMaximum(1000000.0)
        self.dsb_bigHeight.setProperty("value", 80.0)
        self.dsb_bigHeight.setObjectName("dsb_bigHeight")
        self.gridLayout.addWidget(self.dsb_bigHeight, 3, 1, 1, 1)
        self.dsb_smallHeight = QtWidgets.QDoubleSpinBox(Dialog)
        self.dsb_smallHeight.setDecimals(5)
        self.dsb_smallHeight.setMaximum(1000000.0)
        self.dsb_smallHeight.setProperty("value", 80.0)
        self.dsb_smallHeight.setObjectName("dsb_smallHeight")
        self.gridLayout.addWidget(self.dsb_smallHeight, 4, 1, 1, 1)
        self.dsb_bigRadius = QtWidgets.QDoubleSpinBox(Dialog)
        self.dsb_bigRadius.setDecimals(5)
        self.dsb_bigRadius.setMaximum(100000.0)
        self.dsb_bigRadius.setProperty("value", 50.0)
        self.dsb_bigRadius.setObjectName("dsb_bigRadius")
        self.gridLayout.addWidget(self.dsb_bigRadius, 0, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 4, 0, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout, 0, 0, 1, 1)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.cb_buildSolid = QtWidgets.QCheckBox(Dialog)
        self.cb_buildSolid.setObjectName("cb_buildSolid")
        self.gridLayout_2.addWidget(self.cb_buildSolid, 0, 0, 1, 1)
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setObjectName("label_5")
        self.gridLayout_2.addWidget(self.label_5, 1, 0, 1, 1)
        self.dsb_solidThickness = QtWidgets.QDoubleSpinBox(Dialog)
        self.dsb_solidThickness.setDecimals(5)
        self.dsb_solidThickness.setMaximum(1000000.0)
        self.dsb_solidThickness.setProperty("value", 5.0)
        self.dsb_solidThickness.setObjectName("dsb_solidThickness")
        self.gridLayout_2.addWidget(self.dsb_solidThickness, 1, 1, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout_2, 1, 0, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout_3.addWidget(self.buttonBox, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        self.buttonBox.accepted.connect(Dialog.accept)
        self.buttonBox.rejected.connect(Dialog.reject)
        self.cb_buildSolid.clicked['bool'].connect(self.label_5.setEnabled)
        self.cb_buildSolid.clicked['bool'].connect(self.dsb_solidThickness.setEnabled)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle("Dialog")
        self.label.setText("主管道半径")
        self.label_3.setText("主管道高度")
        self.label_2.setText("次管道半径")
        self.label_4.setText("次管道高度")
        self.cb_buildSolid.setText("设置厚度")
        self.label_5.setText("厚度")

