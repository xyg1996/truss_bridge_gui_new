#!/usr/bin/python

#import pylab
import numpy
import glob
import matplotlib.pyplot as plt
# from pyplotz.pyplotz import PyplotZ

#de = numpy.genfromtxt("total internal energy_EDRAHT.txt")
#dm = numpy.genfromtxt("total force fx,fy,fz_NSURFACE.txt")
#pylab.plot(de[:,0],de[:,1],'b',dm[:,0],dm[:,3],'r')
def PlotTXT():
    #收集所有分组的TXT
    # plt = PyplotZ()
    allfilelist=glob.glob('total force fx,fy,fz_*.txt')

    for eachgroup in allfilelist:
        #读取该分组的TXT
        dm = numpy.genfromtxt(eachgroup)

        #pylab方法(已废弃)
        #pylab.plot(dm[:,0],dm[:,3],'r')
        #pylab.grid(True)
        #pylab.xlim([0,1])
        #pylab.xlabel("t")
        #pylab.ylabel("y")
        #pylab.legend(["Energy","Moment"],loc=0)
        #pylab.savefig("ForcesXYZ")

        #绘制FX
        plt.figure(11)
        plt.plot(dm[:,0],dm[:,1],label=eachgroup[21:-4])
        #plt.plot(dm[:,0],dm[:,1],label='防波板')
        plt.xlabel('Time(s)')
        plt.ylabel('X Direction Forces(N)')

        #绘制FY
        plt.figure(12)
        plt.plot(dm[:,0],dm[:,2],label=eachgroup[21:-4])
        #plt.plot(dm[:,0],dm[:,2],label='容器壁')
        plt.xlabel('Time(s)')
        plt.ylabel('Y Direction Forces(N)')

        #绘制FZ
        plt.figure(13)
        plt.plot(dm[:,0],dm[:,3],label=eachgroup[21:-4])
        plt.xlabel('Time(s)')
        plt.ylabel('Z Direction Forces(N)')

    plt.figure(11)
    plt.legend()
    plt.savefig("fenzuXForces(N).png")

    plt.figure(12)
    plt.legend()
    plt.savefig("fenzuYForces(N).png")

    plt.figure(13)
    plt.legend()
    plt.savefig("fenzuZForces(N).png")