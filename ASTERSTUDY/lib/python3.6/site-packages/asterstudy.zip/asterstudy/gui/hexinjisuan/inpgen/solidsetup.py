import os
import glob

#获取各组单元厚度，边界条件，材料参数 然后生成.inp文件

#所有分组 列表
#    preprocess.py 收集需要统计合力的分组 返回值TotalForce字符串列表
#    def TotalFGroup(self):
def solidinp(thickness,stldic,TotalFGroup,BOUNDARY,path,posson,Youngs,DENSITY,DeltaT,MaxT):
    #ELSETlist = ['S3',]

    #NSETlist = ['Nsurface','boundryfix',]

    #需要统计的分组

    #thickness={'EALL':0.01,}
    # for structures:
    # – 1: translation in the local x-direction
    # – 2: translation in the local y-direction
    # – 3: translation in the local z-direction
    # – 4: rotation about the local x-axis (only for nodes belonging to beams
    # or shells)
    # – 5: rotation about the local y-axis (only for nodes belonging to beams
    # or shells)
    # – 6: rotation about the local z-axis (only for nodes belonging to beams
    # or shells)
    # – 11: temperature
    #BOUNDARY={'boundryfix':[1,2,3,4,5,6],}

    #Youngs=2.1E13
    #posson=0.3
    #DENSITY=7.8500E+03
    #DeltaT=0.001
    #MaxT=10

    #
    fullpath = os.path.join(path,'tankpre.inp')
    with open(fullpath,'w') as f:
        #inp=f.readlines()
        #txt.insert(4,txt[1])#第二行插入第五行的位置
        #del(txt[1])#删除原来的第二行
        #print(txt)
        #inp.insert('*INCLUDE, INPUT=Solid/mesh.inp')
        #inp.insert('*INCLUDE, INPUT=Solid/mesh.inp')
        filepath = os.path.join(path,'mesh.inp')
        #meshpath = glob.glob(filepath)[0]
        f.writelines('*INCLUDE, INPUT='+filepath+'\n')

        for key in stldic:
            #stldic[key]
            f.writelines('*NSET,NSET='+key+'\n')
            mergesets = ''
            for nset in stldic[key]:
                mergesets = mergesets+nset+','
            f.writelines(mergesets[:-1]+'\n')
            #ELSET 同样方法
            f.writelines('*ELSET,ELSET='+key+'\n')
            mergesets = ''
            for nset in stldic[key]:
                mergesets = mergesets+nset+','
            f.writelines(mergesets[:-1]+'\n')

        f.writelines('*MATERIAL,NAME=steel\n')
        f.writelines('*ELASTIC\n')
        f.writelines(str(Youngs)+','+str(posson)+'\n')
        f.writelines('*DENSITY\n')
        f.writelines(str(DENSITY)+'\n')

        #*SHELL SECTION,MATERIAL=steel,ELSET=S3,OFFSET=0.0000E+00
        #所有壳体单元
        for eachkey in thickness:
            print(eachkey)
            f.writelines('*SHELL SECTION,MATERIAL=steel,ELSET='+eachkey+',OFFSET=0.0000E+00'+'\n')
            f.writelines(str(thickness[eachkey])+'\n')

        f.writelines('*STEP, INC=1000000'+'\n')
        #f.writelines('*RESTART,WRITE,FREQUENCY=1,OVERLAY'+'\n')
        f.writelines('*RESTART,WRITE,FREQUENCY=1'+'\n')
        f.writelines('*DYNAMIC,DIRECT,'+'\n')
        #f.writelines('*DYNAMIC,'+'\n')
        #DeltaT=0.001
        #MaxT=10
        f.writelines(str(DeltaT)+','+str(MaxT)+'\n')

        #所有边界条件
        f.writelines('*BOUNDARY'+'\n')
        for eachkey in BOUNDARY:
            print(eachkey)
            print(BOUNDARY[eachkey])
            for i in BOUNDARY[eachkey]:
                f.writelines(str(eachkey)+','+str(i)+'\n')

        #所有载荷
        f.writelines('*CLOAD'+'\n')
        f.writelines('Nsurface, 1, 0.0'+'\n')
        f.writelines('Nsurface, 2, 0.0'+'\n')
        f.writelines('Nsurface, 3, 0.0'+'\n')

        #
        f.writelines('*NODE FILE,OUTPUT=2D '+'\n')
        f.writelines('U,'+'\n')
        f.writelines('*EL FILE'+'\n')
        f.writelines('S,E,'+'\n')
        
        # for each in TotalFGroup:
        #     f.writelines('*NODE PRINT,NSET='+each+',TOTALS=ONLY '+'\n')
        #     f.writelines('RF '+'\n')

        for each in stldic:
            f.writelines('*NODE PRINT,NSET='+each+',TOTALS=ONLY '+'\n')
            f.writelines('RF '+'\n')

        f.writelines('*END STEP'+'\n')

#if __name__ == "__main__":
#    solidinp()

def restartinp(thickness,stldic,TotalFGroup,BOUNDARY,path,posson,Youngs,DENSITY,DeltaT,MaxT):
    #
    fullpath = os.path.join(path,'tank.inp')
    with open(fullpath,'w') as f:
        f.writelines('*RESTART,read'+'\n')
        
        f.writelines('*STEP, INC=1000000'+'\n')
        f.writelines('*DYNAMIC,DIRECT,'+'\n')
        #f.writelines('*DYNAMIC,'+'\n')
        #DeltaT=0.001
        #MaxT=10
        f.writelines(str(DeltaT)+','+str(MaxT)+'\n')

        #所有边界条件
        f.writelines('*BOUNDARY'+'\n')
        for eachkey in BOUNDARY:
            print(eachkey)
            print(BOUNDARY[eachkey])
            for i in BOUNDARY[eachkey]:
                f.writelines(str(eachkey)+','+str(i)+'\n')

        #所有载荷
        f.writelines('*CLOAD'+'\n')
        f.writelines('Nsurface, 1, 0.0'+'\n')
        f.writelines('Nsurface, 2, 0.0'+'\n')
        f.writelines('Nsurface, 3, 0.0'+'\n')

        #
        f.writelines('*NODE FILE,OUTPUT=2D '+'\n')
        f.writelines('U,'+'\n')
        f.writelines('*EL FILE'+'\n')
        f.writelines('S,E,'+'\n')
        
        # for each in TotalFGroup:
        #     f.writelines('*NODE PRINT,NSET='+each+',TOTALS=ONLY '+'\n')
        #     f.writelines('RF '+'\n')

        for each in stldic:
            f.writelines('*NODE PRINT,NSET='+each+',TOTALS=ONLY '+'\n')
            f.writelines('RF '+'\n')

        f.writelines('*END STEP'+'\n')
