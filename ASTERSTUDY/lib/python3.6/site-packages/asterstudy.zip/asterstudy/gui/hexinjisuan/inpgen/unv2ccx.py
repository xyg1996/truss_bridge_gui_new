


"""
    © Ihor Mirzov, August 2019
    Distributed under GNU General Public License v3.0

    Converts UNV file from Salome to CalculiX INP mesh: reads UNV_file,
    creates an internal FEM object, then writes the INP_file.

    Usage:
        python3 unv2ccx.py ./tests-elements/116.unv
"""


import os, logging, shutil
#, 
#from .INPWriter import *
from .UNVParser import *
from . import INPWriter
#from . import UNVParser


def Unv2ccx(filename,destinypath):
    # Clean cached files
    if os.path.isdir('__pycache__'):
        shutil.rmtree('__pycache__') # works in Linux as in Windows

    # Command line parameters
    #parser = argparse.ArgumentParser()
    #parser.add_argument('filename', type=str,
    #                    help='.unv file name (with extension)',
    #                    default='')
    #args = parser.parse_args()

    # Configure logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    # Parse UNV file
    FEM = UNVParser(filename).parse()

    # Write INP file
    INPWriter.write(FEM, filename,destinypath)

    logging.info(os.path.basename(filename) + ' converted!\n')

if __name__ == '__main__':
    Unv2ccx('finaltankmesh.unv')

