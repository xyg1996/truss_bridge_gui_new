# state file generated using paraview version 4.4.0

# ----------------------------------------------------------------
# setup views used in the visualization
# ----------------------------------------------------------------

#### import the simple module from the paraview
from paraview.simple import *
#import glob
try:
    import xml.etree.cElementTree as et
except ImportError:
    import xml.etree.ElementTree as et
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# Create a new 'Render View'
renderView1 = CreateView('RenderView')
renderView1.ViewSize = [1154, 797]
renderView1.AxesGrid = 'GridAxes3DActor'
renderView1.CenterOfRotation = [0.0, 0.0, -1e-20]
renderView1.StereoType = 0
renderView1.CameraPosition = [0.0, 0.0, 0.9931671704403314]
renderView1.CameraFocalPoint = [0.0, 0.0, -1e-20]
renderView1.CameraParallelScale = 0.25705057868053904
renderView1.Background = [0.32, 0.34, 0.43]

# ----------------------------------------------------------------
# setup the data processing pipelines
# ----------------------------------------------------------------

# create a new 'PVD Reader'
#TODOCHECK PATH
#Abandon Method
#tankfilelist=glob.glob('Solid/tank.*.vtu')

parser = et.parse("Solid/tank.pvd")
root=parser.getroot()
#print(root)

print(len(root[0]))
print(root[0][-1].attrib['file'])

#listlength=len(tankfilelist)
if len(root[0])<4:
#tankvtu = XMLUnstructuredGridReader(FileName=tankfilelist[-1])
    tanklistpick=[root[0][-1].attrib['file']]
    timeseries=[root[0][-1].attrib['timestep']]
    
elif len(root[0])<14:
    tanklistpick=[root[0][2].attrib['file'],root[0][-2].attrib['file']]
    timeseries=[root[0][2].attrib['timestep'],root[0][-2].attrib['timestep']]
else:
    tanklistpick=[root[0][2].attrib['file'],root[0][len(root[0])/2].attrib['file'],root[0][-2].attrib['file']]
    timeseries=[root[0][2].attrib['timestep'],root[0][len(root[0])/2].attrib['timestep'],root[0][-2].attrib['timestep']]

for i in range(len(tanklistpick)):
    vtuname=tanklistpick[i]    
    # ----------------------------------------------------------------
    # setup color maps and opacity mapes used in the visualization
    # note: the Get..() functions create a new object, if needed
    # ----------------------------------------------------------------
    tankpvd = XMLUnstructuredGridReader(FileName='Solid/'+vtuname)
    
    # get color transfer function/color map for 'U'
    uLUT = GetColorTransferFunction('U')
    #uLUT.RGBPoints = [0.0, 1.0, 0.0, 0.0, 1.8302072134101006e-06, 0.0, 0.0, 1.0]
    uLUT.RGBPoints = [0.0, 0.0, 0.0, 1.0, 1.8302072134101006e-06, 1.0, 0.0, 0.0]
    uLUT.ColorSpace = 'HSV'
    uLUT.NanColor = [0.498039215686, 0.498039215686, 0.498039215686]
    uLUT.ScalarRangeInitialized = 1.0

    # get opacity transfer function/opacity map for 'U'
    uPWF = GetOpacityTransferFunction('U')
    #uPWF.Points = [0.0, 0.0, 0.5, 0.0, 1.8302072134101006e-06, 1.0, 0.5, 0.0]
    uPWF.Points = [0.0, 1.0, 0.5, 0.0, 1.8302072134101006e-06, 0.0, 0.5, 0.0]
    uPWF.ScalarRangeInitialized = 1

    # ----------------------------------------------------------------
    # setup the visualization in view 'renderView1'
    # ----------------------------------------------------------------

    # show data from tankpvd
    tankpvdDisplay = Show(tankpvd, renderView1)
    # trace defaults for the display properties.
    tankpvdDisplay.ColorArrayName = ['POINTS', 'U']
    tankpvdDisplay.LookupTable = uLUT
    tankpvdDisplay.ScalarOpacityUnitDistance = 0.024229836131213642

    # show color legend
    tankpvdDisplay.SetScalarBarVisibility(renderView1, True)

    # setup the color legend parameters for each legend in this view

    # get color legend/bar for uLUT in view renderView1
    uLUTColorBar = GetScalarBar(uLUT, renderView1)
    uLUTColorBar.Title = 'U'
    uLUTColorBar.ComponentTitle = 'Magnitude'
    uLUTColorBar.TitleFontFamily = 'Times'

    thistime=timeseries[i]
    renderView1.CameraPosition = [1.0, 0.0, 0.0]
    SaveScreenshot('maxdeformationX+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [-1.0, 0.0, 0.0]
    SaveScreenshot('maxdeformationX-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 1.0, 0.0]
    SaveScreenshot('maxdeformationY+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, -1.0, 0.0]
    SaveScreenshot('maxdeformationY-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 0.0, 1.0]
    SaveScreenshot('maxdeformationZ+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 0.0, -1.0]
    SaveScreenshot('maxdeformationZ-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    # destroy last .vtu
    Delete(tankpvd)
    del tankpvd
