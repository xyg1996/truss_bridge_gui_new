def autopost():
    import pvsimple
    pvsimple.ShowParaviewView()
    print('autopost called')
    # trace generated using paraview version 5.6.0
    #
    # To ensure correct image size when batch processing, please search 
    # for and uncomment the line `# renderView*.ViewSize = [*,*]`

    #### import the simple module from the paraview
    from pvsimple import *
    #### disable automatic camera reset on 'Show'
    pvsimple._DisableFirstRenderCameraReset()

    # get active view
    renderView1 = GetActiveViewOrCreate('RenderView')
    # uncomment following to set a specific view size
    # renderView1.ViewSize = [1508, 776]

    # get layout
    layout1 = GetLayout()

    # split cell
    layout1.SplitHorizontal(0, 0.5)

    # set active view
    SetActiveView(None)

    # get the material library
    #materialLibrary1 = GetMaterialLibrary()

    # Create a new 'Render View'
    renderView2 = CreateView('RenderView')
    renderView2.ViewSize = [749, 776]
    #renderView2.AxesGrid = 'GridAxes3DActor'
    #renderView2.StereoType = 0
    #renderView2.Background = [0.0, 0.0, 0.0]
    #renderView2.OSPRayMaterialLibrary = materialLibrary1

    # place view in the layout
    layout1.AssignView(2, renderView2)

    # create a new 'PVD Reader'
    tankpvd = PVDReader(FileName='/home/export/online1/systest/swrh/Tanksimulator/Project-2/case-15:24:59/Solid/tank.pvd')

    # get animation scene
    animationScene1 = GetAnimationScene()

    # update animation scene based on data timesteps
    animationScene1.UpdateAnimationUsingDataTimeSteps()

    # show data in view
    tankpvdDisplay = Show(tankpvd, renderView2)

    # trace defaults for the display properties.
    tankpvdDisplay.Representation = 'Surface'

    # reset view to fit data
    renderView2.ResetCamera()

    # update the view to ensure updated data information
    renderView2.Update()

    # set scalar coloring
    ColorBy(tankpvdDisplay, ('POINTS', 'S', 'Magnitude'))

    # rescale color and/or opacity maps used to include current data range
    tankpvdDisplay.RescaleTransferFunctionToDataRange(True, False)

    # show color bar/color legend
    tankpvdDisplay.SetScalarBarVisibility(renderView2, True)

    # get color transfer function/color map for 'S'
    sLUT = GetColorTransferFunction('S')

    # get opacity transfer function/opacity map for 'S'
    sPWF = GetOpacityTransferFunction('S')

    # set scalar coloring
    ColorBy(tankpvdDisplay, ('POINTS', 'S', 'Mises'))

    # rescale color and/or opacity maps used to exactly fit the current data range
    tankpvdDisplay.RescaleTransferFunctionToDataRange(False, False)

    # Update a scalar bar component title.
    UpdateScalarBarsComponentTitle(sLUT, tankpvdDisplay)

    # Apply a preset using its name. Note this may not work as expected when presets have duplicate names.
    sLUT.ApplyPreset('Rainbow Uniform', True)

    # set active view
    SetActiveView(renderView1)

    # create a new 'OpenFOAMReader'
    fluidfoam = OpenFOAMReader(FileName='/home/export/online1/systest/swrh/Tanksimulator/Project-2/case-15:24:59/Fluid/Fluid.foam')

    # Properties modified on fluidfoam
    fluidfoam.CaseType = 'Decomposed Case'

    # show data in view
    fluidfoamDisplay = Show(fluidfoam, renderView1)

    # trace defaults for the display properties.
    fluidfoamDisplay.Representation = 'Surface'

    # reset view to fit data
    renderView1.ResetCamera()

    # show color bar/color legend
    fluidfoamDisplay.SetScalarBarVisibility(renderView1, True)

    # update the view to ensure updated data information
    renderView1.Update()

    # get color transfer function/color map for 'p'
    pLUT = GetColorTransferFunction('p')

    # get opacity transfer function/opacity map for 'p'
    pPWF = GetOpacityTransferFunction('p')

    # set scalar coloring
    ColorBy(fluidfoamDisplay, ('POINTS', 'alpha.water'))

    # Hide the scalar bar for this color map if no visible data is colored by it.
    HideScalarBarIfNotNeeded(pLUT, renderView1)

    # rescale color and/or opacity maps used to include current data range
    fluidfoamDisplay.RescaleTransferFunctionToDataRange(True, False)

    # show color bar/color legend
    fluidfoamDisplay.SetScalarBarVisibility(renderView1, True)

    # get color transfer function/color map for 'alphawater'
    alphawaterLUT = GetColorTransferFunction('alphawater')

    # get opacity transfer function/opacity map for 'alphawater'
    alphawaterPWF = GetOpacityTransferFunction('alphawater')

    # Apply a preset using its name. Note this may not work as expected when presets have duplicate names.
    alphawaterLUT.ApplyPreset('Rainbow Uniform', True)

    #### saving camera placements for all active views

    # current camera placement for renderView1
    renderView1.CameraPosition = [6.690106509607932, 5.131251328337343, 11.421562504419706]
    renderView1.CameraFocalPoint = [-7.498264312744143e-05, -0.002254962921142578, -2.4049846280390002e-20]
    renderView1.CameraViewUp = [-0.24343881096797815, 0.9299960961453951, -0.27539935814889266]
    renderView1.CameraParallelScale = 3.682669226684897

    # current camera placement for renderView2
    renderView2.CameraPosition = [8.232454631950164, 0.9372404688068118, 11.537156927816262]
    renderView2.CameraViewUp = [0.08356058672920985, 0.9866508043880639, -0.13977774696229966]
    renderView2.CameraParallelScale = 3.684751585820693


    if salome.sg.hasDesktop():
    salome.sg.updateObjBrowser()
