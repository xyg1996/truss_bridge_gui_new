import os

def xmlgen(DeltaT,MaxT,MaxT2,Watchpointsdic,path):

    newxml = []
    #xmlfile = 
    # origin = os.path.join(path,'precice-config_parallel.xml')
    origin = os.path.join(os.path.dirname(__file__),'../../template/precice-config_parallel.xml')
    with open(origin) as file:
        alllines = file.readlines()

    for line in alllines:
        #print(line)
        if line.strip()=='DeltaT':
            newxml += '        <timestep-length value="'+DeltaT+'"/>\n'
        elif line.strip()=='MaxT':
            newxml += '        <max-time value="'+MaxT+'"/>\n'
        elif line.strip()=='Watchpoints':
            #TODO 修改成 多个观察点
            # for i,key in enumerate(allpointsdic):
            for key in Watchpointsdic:
                Watchpoints = Watchpointsdic[key]
                newxml += '        <watch-point mesh="Solid" name="'+key+'" coordinate="'+Watchpoints[0]+';'+Watchpoints[1]+';'+Watchpoints[2]+'" />\n'
        else:
            newxml += line

    target = os.path.join(path,'precice-config_parallel.xml')        
    with open(target,'w') as file:
        file.writelines(newxml)

    newxml = []
    #xmlfile = 
    # origin = os.path.join(path,'precice-config_parallel2.xml')
    origin = os.path.join(os.path.dirname(__file__),'../../template/precice-config_parallel2.xml')
    with open(origin) as file:
        alllines = file.readlines()

    for line in alllines:
        #print(line)
        if line.strip()=='DeltaT':
            newxml += '        <timestep-length value="'+DeltaT+'"/>\n'
        elif line.strip()=='MaxT':
            newxml += '        <max-time value="'+MaxT2+'"/>\n'
        elif line.strip()=='Watchpoints':
            #TODO 修改成 多个观察点
            # newxml += '        <watch-point mesh="Solid" name="Solidwatchpoint1" coordinate="'+Watchpoints[0]+';'+Watchpoints[1]+';'+Watchpoints[2]+'" />\n'
            for key in Watchpointsdic:
                Watchpoints = Watchpointsdic[key]
                newxml += '        <watch-point mesh="Solid" name="'+key+'" coordinate="'+Watchpoints[0]+';'+Watchpoints[1]+';'+Watchpoints[2]+'" />\n'
        else:
            newxml += line

    target = os.path.join(path,'precice-config_parallel.xml')        
    with open(target,'w') as file:
        file.writelines(newxml)

if __name__ == "__main__":
    xmlgen('0.01','18','88',['8','8','8'],'')


