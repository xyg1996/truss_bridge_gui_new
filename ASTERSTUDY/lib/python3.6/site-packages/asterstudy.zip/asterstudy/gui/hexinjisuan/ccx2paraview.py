

"""
    © Ihor Mirzov, August 2019
    Distributed under GNU General Public License v3.0

    Converts CalculiX .frd resutls file to ASCII .vtk or XML .vtu format.

    Run with command:
        python3 ccx2paraview.py ./tests/examples/beamf.frd vtk
        python3 ccx2paraview.py ./tests/examples/beamf.frd vtu

    改写: dzj
    新功能:
    支持对两个阶段结果的自动合并
    在.pvd文件中 保存上一次转换的文件指针self.currentposition
    之后直接从上一次指针出开始,提升文件转换效率
"""

# TODO https://github.com/pearu/pyvtk/blob/master/examples/example1.py

import argparse, os, logging
# import FRDParser, VTKWriter, VTUWriter, clean
#import VTKWriter, VTUWriter, clean
#from .writePVD import writePVD
from .VTUWriter import *
from .VTKWriter import *
from .FRDParser import Parse01
from pathlib import Path
import xml.etree.ElementTree as ET

def getpvdinfo(filename):
    parser = ET.parse(filename)
    root = parser.getroot()
    alltimesteps = []
    allfiles = []
    for child in root[0]:
        alltimesteps.append(child.attrib['timestep'])
        #allfiles.append(child.attrib['file'][:-4])
        allfiles.append(child.attrib['file'])
    return allfiles,alltimesteps,root[1].text,root[2].text

def writePVD(file_name,times,names,currentposition,fname):

    with open(file_name, 'w') as f:
        f.write('<?xml version="1.0"?>\n')
        f.write('<VTKFile type="Collection" version="0.1" byte_order="LittleEndian">\n')
        f.write('\t<Collection>\n')
        for i in range(len(times)):
            f.write('\t\t<DataSet timestep="{}" file="{}"/>\n'\
                .format(times[i], names[i]))
        f.write('\t</Collection>\n')

        f.write('\t<fname>\n')
        f.write('\t'+str(fname)+'\n')
        f.write('\t</fname>\n')

        f.write('\t<currentposition>\n')
        f.write('\t'+str(currentposition)+'\n')
        f.write('\t</currentposition>\n')

        f.write('</VTKFile>')

def writesim(file_name,times,names):
    with open(file_name, 'w') as f:
        f.write('<?xml version="1.0"?>\n')
        f.write('<VTKFile type="Collection" version="0.1" byte_order="LittleEndian">\n')
        f.write('\t<Collection>\n')
        for i in range(len(times)):
            f.write('\t\t<DataSet timestep="{}" file="{}"/>\n'\
                .format(times[i], names[i]))
        f.write('\t</Collection>\n')

        f.write('</VTKFile>')

class Frd2pvd:
    def __init__(self,path):
        #path: self.currentpath
        #path = path
        #self.filename = str(Path(path)/'Solid'/'tank.frd')
        
        self.format = "vtu"
        logging.basicConfig(level=logging.INFO,
                            # filename=test_file, filemode='a',
                            format='%(levelname)s: %(message)s')
        # self.names = []
        # self.times = []
        # self.steps = []
        #self.currentposition = 0
        p = None
        #p = Parse01(self.filename,self.currentposition)

    def startconvert(self,path):
    # Parse FRD-file
        fname = Path(path)/'Solid'/'tank.pvd'
        fname2 = Path(path)/'Solid'/'tank.frd'
        if not fname.is_file():
            print('if not fname.is_file:')
            self.filename = Path(path)/'Solid'/'tankpre.frd'
            self.currentposition = 0
            self.names = []
            self.times = []
            self.steps = []
            self.startcore()
            if fname2.is_file():  
                print("if (Path(path)/'Solid'/'tank.frd').is_file(): ")
                self.filename = fname2
                self.currentposition = 0
                self.names = getpvdinfo(fname)[0]
                self.times = getpvdinfo(fname)[1]
                self.steps = list(range(1,len(self.times)+1))
                self.startcore()

        elif getpvdinfo(fname)[2].strip()=='tank.frd':
            print("elif getpvdinfo(fname)[2]=='tank.frd':")
            self.filename = Path(path)/'Solid'/'tank.frd'
            self.currentposition = int(getpvdinfo(fname)[-1])
            self.names = getpvdinfo(fname)[0]
            self.times = getpvdinfo(fname)[1]
            self.steps = list(range(1,len(self.times)+1))
            self.startcore()

        elif getpvdinfo(fname)[2].strip()=='tankpre.frd':
            print("elif getpvdinfo(fname)[2]=='tankpre.frd':")
            self.filename = Path(path)/'Solid'/'tankpre.frd'
            self.currentposition = int(getpvdinfo(fname)[-1])
            self.names = getpvdinfo(fname)[0]
            self.times = getpvdinfo(fname)[1]
            self.steps = list(range(1,len(self.times)+1))
            self.startcore()        
            if (Path(path)/'Solid'/'tank.frd').is_file():
                print("if Path(path)/'Solid'/'tank.frd'.is_file:")
                self.filename = Path(path)/'Solid'/'tank.frd'
                self.currentposition = 0
                self.names = getpvdinfo(fname)[0]
                self.times = getpvdinfo(fname)[1]
                self.steps = list(range(1,len(self.times)+1))
                self.startcore()
        else:
            print(getpvdinfo(fname)[2])
        
    def startcore(self):
        logging.basicConfig(level=logging.INFO,
                            # filename=test_file, filemode='a',
                            format='%(levelname)s: %(message)s')
        
        p = Parse01(str(self.filename),self.currentposition)  
        p.exeparse(self.currentposition)
        self.currentposition = p.crpos 

        # If file isn't empty
        if p.node_block and p.elem_block:

            # Create list of time steps
            newsteps = sorted(set([b.numstep for b in p.result_blocks])) # list of step numbers
            print('新增steps:',newsteps)
            #width = len(str(len(steps))) # max length of string designating step number
            #steps = ['{:0{width}}'.format(s, width=width) for s in steps] # pad with zero
            #fullsteps = [str(s) for s in self.steps] # remove pad with zero
            if not len(self.steps): 
                self.steps = ['1'] # to run converter at least once

            newtimes = sorted(set([b.value for b in p.result_blocks])) # list of step times
            print('新增times:',newtimes)

            self.steps += newsteps
            self.times += newtimes

            print('总体steps:',self.steps)
            print('总体times:',self.times)

            # For each time step generate separate .vt* file
            #logging.info('Writing {}.{}'.format(str(self.filename)[:-4], self.format))
            for s in newsteps:
                # Output file name will be the same as input
                #if len(steps) > 1: # include step number in file_name
                if len(newsteps)> 0:
                    file_name = p.file_name.replace('.frd', '.{}.{}'.format(s, self.format))
                    self.names.append(os.path.basename(file_name))
                # Call converters
                if self.format == 'vtk':
                    writeVTK(p, file_name, s)
                if self.format == 'vtu':
                    writeVTU(p, file_name, s)

            # Write ParaView Data (PVD) for series of VTU files.
            if len(newtimes) >= 1 and self.format == 'vtu':
                writePVD(os.path.dirname(self.filename)+'/tank.pvd', self.times, self.names,self.currentposition,os.path.basename(self.filename))
                writesim(os.path.dirname(self.filename)+'/tanksim.pvd', self.times, self.names)
        else:
            logging.warning('File is empty!')

if __name__ == "__main__":
    p = Frd2pvd(*args[0])
    p.startconvert()

