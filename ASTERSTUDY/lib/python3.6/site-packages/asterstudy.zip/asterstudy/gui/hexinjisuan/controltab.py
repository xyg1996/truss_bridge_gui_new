from PyQt5 import Qt as Q

import sys
import os
import subprocess 
from ..salomegui_utils import get_salome_gui, get_salome_pyqt

from ..guodu import BackgroundLoading

from pvsimple import *
from .ccx2paraview import Frd2pvd
from .inpgen.unv2ccx import Unv2ccx
from .inpgen.solidsetup import solidinp,restartinp
# from .paraviewpreload import Preload
from ...common import load_icon
from pathlib import Path
import time
import glob
import json
import shutil
from decimal import Decimal
import pvsimple

#from functools import partial

class KeyboardWidget(Q.QWidget):
    keyPressed = Q.pyqtSignal(str)

    def keyPressEvent(self, keyEvent):
        self.keyPressed.emit(keyEvent.text())

class Maincontrol(Q.QWidget):

    def __init__(self,Solidgroup,para,posttab):
        super().__init__()
        self.home = str(Path.home())
        self.para = para
        self.posttab = posttab
        self.currentpath = None
        self.initUI()
        self.keyList = []
        #self.paravisflag = 0
        # self.paravis = None
        self.Solidgroup = Solidgroup
        #TODO 用户每次计算都位于不同路径
        cp = str(self.projects.itemData(self.projects.currentIndex()))
        cc = str(self.cases.itemData(self.cases.currentIndex()))
        #self.currentpath = os.path.join(self.home,'Tanksimulator',cp,cc)
        
        self.connectAll()
        #切换路径
        #os.chdir(self.currentpath)
        #self.pvd=Frd2pvd("Solid/tank.frd")
        self.pvd = None
        self.solidid = None
        self.fluidid = None

        #self.allCursorVisible()
        #self.keyboardWidget = KeyboardWidget()
        #self.keyboardWidget.keyPressed.connect(self.keyCounter)
        #self.keyboardWidget.show()
        # renderView1 = None
        # renderView2 = None 
        # openFOAMReader1 = None
        # pVDReader1 = None
        
    # def keyCounter(self, key):
    #     #self.keyList.append(key)
    #     #print(key)
    #     if key == Q.Key_Enter: 
    #         #self.solidtextview.setTextCursor(SolidOutput)
    #         self.temptextview.ensureCursorVisible(False)
    #         self.solidtextview.ensureCursorVisible(False)
    #         self.fluidtextview.ensureCursorVisible(False)
    #     elif key == Q.Key_Space: 
    #         self.solidtextview.setTextCursor(FluidOutput)

    # def keyPressEvent(self,e):
    #     if e.key() == Q.Qt.Key_Enter or e.key == Q.Qt.Key_Space:
    #         #self.CursorVisible = not self.CursorVisible
    #         self.allCursorVisible()
            
    def connectAll(self):
        self.bt_open.clicked.connect(self.loadjson)
        self.btaddcase.clicked.connect(self.addcase)

    def loadjson(self):
        self.para.choosefrompath(self.currentpath)
        self.Solidgroup.reload(self.currentpath+'/savedata.json')
        with open(self.currentpath+'/savedata.json') as jf:
            dic = json.load(jf)
        self.solidid = dic['solidid']
        self.fluidid = dic['fluidid']
        
    def initUI(self):
        self.resize(1920,1080)
        self.alllayout = Q.QHBoxLayout(self)

        self.leftlayout = Q.QVBoxLayout()
        self.midlayout = Q.QVBoxLayout()
        self.rightlayout = Q.QVBoxLayout()

        self.topleftlay = Q.QGridLayout()
        self.downleftlay = Q.QVBoxLayout()
        self.leftabovelay = Q.QHBoxLayout()

        self.leftlayout.addLayout(self.leftabovelay)
        self.leftlayout.addLayout(self.topleftlay)
        self.leftlayout.addLayout(self.downleftlay)
        self.alllayout.addLayout(self.leftlayout)
        self.alllayout.addLayout(self.midlayout)
        self.alllayout.addLayout(self.rightlayout)

        self.midlayout01 = Q.QVBoxLayout()
        self.rightlayout01 = Q.QVBoxLayout()
        self.downleftlay01 = Q.QVBoxLayout()
        self.topleftlay01 = Q.QGridLayout()

        self.gBoxtopleft = Q.QGroupBox()
        self.gBoxtopleft.setTitle("控制区")
        self.gBoxtopleft.setLayout(self.topleftlay01)
        self.topleftlay.addWidget(self.gBoxtopleft)

        self.gBoxmid = Q.QGroupBox()
        self.gBoxmid.setTitle("固体计算过程")
        self.gBoxmid.setLayout(self.midlayout01)
        self.midlayout.addWidget(self.gBoxmid)

        self.gBoxright = Q.QGroupBox()
        self.gBoxright.setTitle("流体计算过程")
        self.gBoxright.setLayout(self.rightlayout01)
        self.rightlayout.addWidget(self.gBoxright)

        self.gBoxdownleft = Q.QGroupBox()
        self.gBoxdownleft.setTitle("其他输出")
        self.gBoxdownleft.setLayout(self.downleftlay01)
        self.downleftlay.addWidget(self.gBoxdownleft)

        self.alllayout.setSpacing(20)
        self.leftlayout.setSpacing(20)

        self.solidtextview = Q.QTextBrowser()
        self.solidtextview.setMinimumSize(Q.QSize(380,180))
        self.solidtextview.setReadOnly(True)

        self.fluidtextview = Q.QTextBrowser()
        self.fluidtextview.setMinimumSize(Q.QSize(380,180))
        self.fluidtextview.setReadOnly(True)

        self.temptextview = Q.QTextBrowser()
        self.temptextview.setMinimumSize(Q.QSize(300,100))
        self.temptextview.setReadOnly(True)

        # font1 = Q.QFont()
        # font1.setPointSize(12)
        # self.setFont(font1)

        self.downleftlay01.addWidget(self.temptextview)
        self.midlayout01.addWidget(self.solidtextview)
        self.rightlayout01.addWidget(self.fluidtextview)

        # QProcess emits `readyRead` when there is data to be read
        #self.process.readyRead.connect(self)

        #self.btFluidpre = Q.QPushButton('流体准备(setField+decomposePar)',self.groupbox)
        self.projects = Q.QComboBox(self)
        self.btaddproject = Q.QPushButton('创建新工程')
        self.cases = Q.QComboBox(self)
        self.bt_open = Q.QPushButton("打开算例")
        self.btaddcase = Q.QPushButton('保存当前算例')
        
        self.initprojects()
        self.initcases()
        self.cases.activated.connect(self.pathupdate)
        self.projects.activated.connect(self.cases.clear)
        self.projects.activated.connect(self.initcases)
        
        # self.leftabovelay.setEnabled()
        self.projects.hide()
        self.btaddproject.hide()
        self.cases.hide()
        self.bt_open.hide()
        self.btaddcase.hide()

        # self.leftabovelay.addWidget(self.projects)
        # self.leftabovelay.addWidget(self.btaddproject)
        # self.leftabovelay.addWidget(self.cases)
        # self.leftabovelay.addWidget(self.bt_open)
        # self.leftabovelay.addWidget(self.btaddcase)

        self._msg = Q.QLabel(self)
        if self.currentpath:
            #路径宽度过长会将页面撑的过长
            if len(self.currentpath)>50:
                self._msg.setText('当前工程文件目录是:'+self.currentpath[-50:])
            else:
                self._msg.setText('当前工程文件目录是:'+self.currentpath)
        else:
            self._msg.setText('保存.hdf文件后生成工程文件目录!')
        self.leftabovelay.addWidget(self._msg)

        self.btFluidpre = Q.QPushButton('计算准备')
        self.btFluidpre.setIcon(load_icon('prepare.png'))
        
        #self.bt1 = Q.QPushButton('开始计算',self.groupbox)
        self.bt1 = Q.QPushButton('开始计算')
        self.bt1.setIcon(load_icon('startdefault.png'))
        #self.bt1.move(40,80)

        #self.btbothkill = Q.QPushButton('停止计算',self.groupbox)
        self.btbothkill = Q.QPushButton('停止计算')
        self.btbothkill.setIcon(load_icon('halt.png'))

        #self.btboth = Q.QPushButton('切换到计算监测页面',self.groupbox)
        self.btboth = Q.QPushButton('生成后处理结果')
        self.btboth.setIcon(load_icon('paraview.png'))

        #self.btrefresh = Q.QPushButton('更新新监测页面固体结果',self.groupbox)
        self.btrefresh = Q.QPushButton('更新结果')
        self.btrefresh.setIcon(load_icon('refresh.png'))

        #self.bt4 = Q.QPushButton('生成.docx报告',self.groupbox)
        self.bt4 = Q.QPushButton('生成.docx报告')
        self.bt4.setIcon(load_icon('WORD.png'))
        #self.bt4.move(40,320)
        self.queue = Q.QComboBox(self)
        self.queue.addItem('q_x86_share')
        self.queue.addItem('q_x86_expr')
        
        self.mpicores = Q.QComboBox(self)
        self.mpicores.addItem('1')
        self.mpicores.addItem('4')
        self.mpicores.addItem('8')
        self.mpicores.addItem('12')
        self.mpicores.addItem('24')

        self.topleftlay01.addWidget(self.queue,0,0)
        self.topleftlay01.addWidget(self.mpicores,0,1)
        self.topleftlay01.addWidget(self.btFluidpre,1,0)
        self.topleftlay01.addWidget(self.bt1,1,1)
        self.topleftlay01.addWidget(self.btbothkill,2,0)
        self.topleftlay01.addWidget(self.btboth,2,1)
        self.topleftlay01.addWidget(self.btrefresh,3,0)
        self.topleftlay01.addWidget(self.bt4,3,1)

        self.btFluidpre.setMaximumWidth(200)
        self.bt1.setMaximumWidth(200)
        self.btbothkill.setMaximumWidth(200)
        self.btboth.setMaximumWidth(200)
        self.btrefresh.setMaximumWidth(200)
        self.bt4.setMaximumWidth(200)

        self.btFluidpre.clicked.connect(self.showreact)
        self.bt1.clicked.connect(self.showreact)
        self.bt4.clicked.connect(self.showreact)
        self.btboth.clicked.connect(self.showreact)
        self.btbothkill.clicked.connect(self.showreact)
        self.btrefresh.clicked.connect(self.refreshresult)

        self.btaddproject.clicked.connect(self.addproject)
        
        # QProcess object for external app
        self.process = Q.QProcess(self)
        self.process.readyRead.connect(self.dataReady)
        self.process.started.connect(lambda: self.bt1.setEnabled(False))
        self.process.finished.connect(lambda: self.bt1.setEnabled(True))
        self.process.setProcessChannelMode(Q.QProcess.MergedChannels)

        # QProcess object for external app
        self.processfluid = Q.QProcess(self)
        self.processfluid.readyRead.connect(self.dataReady)
        self.processfluid.started.connect(lambda: self.bt1.setEnabled(False))
        self.processfluid.started.connect(lambda: self.btFluidpre.setEnabled(False))
        self.processfluid.finished.connect(lambda: self.bt1.setEnabled(True))
        self.processfluid.finished.connect(lambda: self.btFluidpre.setEnabled(True))
        self.processfluid.setProcessChannelMode(Q.QProcess.MergedChannels)

        self.tempprocess = Q.QProcess(self)
        self.tempprocess.readyRead.connect(self.dataReady)
        self.tempprocess.started.connect(lambda: self.bt4.setEnabled(False))
        self.tempprocess.finished.connect(lambda: self.bt4.setEnabled(True))
        #self.tempprocess.finished.connect(lambda: self.opendocx())
        self.tempprocess.setProcessChannelMode(Q.QProcess.MergedChannels)

        # 准备一个 过度时间的 过场效果
        self._loader = BackgroundLoading(self,msg='正在载入App,请稍候...')
        # self._loader.start()

        #self.processWord.started.connect(lambda: self.bt4.setEnabled(False))
        #self.processWord.finished.connect(lambda: self.bt4.setEnabled(True))
        
    #def keyPressEvent(self, event):
    #    if event.key() == QtCore.Qt.Key_Enter: 
    #        self.solidtextview.setTextCursor(SolidOutput)

    #    elif event.key() == QtCore.Qt.Key_Space: 
    #        self.solidtextview.setTextCursor(FluidOutput)
    def pathupdate(self):
        cp = str(self.projects.itemData(self.projects.currentIndex()))
        cc = str(self.cases.itemData(self.cases.currentIndex()))
        self.currentpath = os.path.join(self.home,'Tanksimulator',cp,cc)

    def initprojects(self):
        #print(os.path.join(self.home,'Project-*'))
        for projectpath in glob.glob(os.path.join(self.home,'Tanksimulator','Project-*')):
            project = os.path.basename(projectpath)
            self.projects.addItem(project,project)

    def initcases(self):
        cp = str(self.projects.itemData(self.projects.currentIndex()))
        for casepath in glob.glob(os.path.join(self.home,'Tanksimulator',cp,'case-*')):
            case = os.path.basename(casepath)
            self.cases.addItem(case,case)

    def saveforhdf(self,path):
        self.currentpath = path
        self.savetojson()

    def savetojson(self):
        medfilename = self.Solidgroup._meshcmd(self.Solidgroup._mesh.currentIndex())
        BOUNDARY,BOUNDARYorigin = self.Solidgroup.SolidFixBoundry()
        TotalFGroup = self.Solidgroup.TotalFGroup()
        #保存 .json
        stldic = self.Solidgroup.genstlwall(self.currentpath)
        thickdic = self.Solidgroup.getthick()
        filename = os.path.join(self.currentpath,'savedata.json')
        self.para.savetopath(filename) 
        print('json保存位置：',filename)
        dic = self.para.getdic()
        dic['BOUNDARYorigin']=BOUNDARYorigin
        dic['BOUNDARY']=BOUNDARY
        dic['TotalFGroup']=TotalFGroup
        # 会往工程文件夹内复制.med和.unv文件，故保存文件夹内的文件路径
        newmedfilename = self.currentpath+'/'+Path(medfilename).name
        dic['medfilename'] = newmedfilename
        dic['stldic']=stldic
        dic['thickdic']=thickdic
        with open(filename, 'w') as f_obj:
            json.dump(dic,f_obj,indent=4)

    def getjobid(self,logfile):
        try:
            with open(logfile) as log:
                for i in range(4):
                    firstline = log.readline()
                    print(firstline.split())
                    jobid = firstline.split()[2]
                    try:
                        return str(int(jobid))
                    except:
                        pass
        except:
            print(logfile,':logfile存在异常!')
            #return None

    def loadcase(self):
        self.loadjson()
        self.redisplayalljob()

        

    def redisplayalljob(self):
        #重新载入流体固体console结果
        self.solidid = self.getjobid(self.currentpath+'/log.ccx_preCICE')
        self.fluidid = self.getjobid(self.currentpath+'/log.interFoam')
        shellpath = os.path.dirname(os.path.abspath(__file__))
        self.processfluid.setWorkingDirectory(shellpath)
        self.process.setWorkingDirectory(shellpath)
        
        if self.solidid:
            #未知原因???? gsn17上必须encoding="ISO-8859-1"
            #否则 UnicodeDecodeError: 'utf-8' codec can't decode byte
            with open(self.currentpath+'/log.ccx_preCICE',encoding="ISO-8859-1") as f:
                text = f.read()
            if len(text)>30000:
                text=text[-30000:]
            self.solidtextview.setPlainText(text)
            print('self.solidid:',self.solidid)

            cmdsolid='env -i '+'./reconnectsolid '+self.currentpath+' '+self.solidid
            self.process.start(cmdsolid)

        if self.fluidid:
            #未知原因???? gsn17上必须encoding="ISO-8859-1"
            #否则 UnicodeDecodeError: 'utf-8' codec can't decode byte
            with open(self.currentpath+'/log.interFoam',encoding="ISO-8859-1") as f:
                text = f.read()
            if len(text)>30000:
                text=text[-30000:]                
            self.fluidtextview.setPlainText(text)
            print('self.fluidid:',self.fluidid)
            #self.processfluid.start('env -i /usr/sw-mpp/bin/bonline '+self.fluidid)
            with open (self.currentpath+'/savedata.json') as f:
                casedata = json.load(f)

            coupledata = casedata['couple']
            # DeltaT = coupledata['Timestep']
            # Trange = coupledata['Stepnumac']
            # MaxT1 = Decimal(DeltaT) * (int(Trange)-1)
            # MaxT2 = Decimal(DeltaT) * (int(Trange)+1)

            MaxT1 = coupledata['Runtimeac']
            MaxT2 = coupledata['Runtimesh']

            cmdfluid='env -i '+'./reconnectfluid '+self.currentpath+' '+self.fluidid+' '+str(MaxT1)+' '+str(MaxT2)
            self.processfluid.start(cmdfluid)

    def addcase(self):
        #pass
        timestamp = str(time.strftime('%H:%M:%S'))
        #self.cases.addItem("case-"+timestamp,"case-"+timestamp)
        self.cases.setInsertPolicy(1)
        self.cases.insertItem(0,"case-"+timestamp,"case-"+timestamp)
        self.cases.setCurrentIndex(0)
        #self.cases.InsertAtTop("case-"+timestamp,"case-"+timestamp)

        #print(self.Solidgroup.minmax6)
        medfilename = self.Solidgroup._meshcmd(self.Solidgroup._mesh.currentIndex())
        BOUNDARY,BOUNDARYorigin = self.Solidgroup.SolidFixBoundry()
        TotalFGroup = self.Solidgroup.TotalFGroup()
        #paradic = self.para.getdic()
        
        if not BOUNDARY or not medfilename:
            Q.QMessageBox.information(self, 'Title', '需要先完成前处理标签页！', Q.QMessageBox.Yes)
            return False
        else:        
            # src = "/home/export/online3/amd_share/SALOME-9.4.0-CO7-SRC/template"
            src = "/home/export/online3/amd_share/SALOME-9.4.0-CO7-SRC/INSTALL/ASTERSTUDY/lib/python3.6/site-packages/asterstudy/template"
            #TODO 替换 copy 为通过交互生成
            
            print('destination = shutil.copytree(src, self.currentpath)')
            destination = copytree(src, self.currentpath)

            medfilename = self.Solidgroup._meshcmd(self.Solidgroup._mesh.currentIndex())
            BOUNDARY,BOUNDARYorigin = self.Solidgroup.SolidFixBoundry()
            TotalFGroup = self.Solidgroup.TotalFGroup()
            #保存 .json
            stldic = self.Solidgroup.genstlwall(self.currentpath)
            thickdic = self.Solidgroup.getthick()
            filename = os.path.join(self.currentpath,'savedata.json')
            self.solidid = self.getjobid(self.currentpath+'/log.ccx_preCICE')
            self.fluidid = self.getjobid(self.currentpath+'/log.interFoam')

            self.para.savetopath(filename) 
            print('json保存位置：',filename)
            dic = self.para.getdic()
            print(dic)
            dic['BOUNDARYorigin']=BOUNDARYorigin
            dic['BOUNDARY']=BOUNDARY
            dic['TotalFGroup']=TotalFGroup
            # 会往工程文件夹内复制.med和.unv文件，故保存文件夹内的文件路径
            newmedfilename = self.currentpath+'/'+Path(medfilename).name
            dic['medfilename'] = newmedfilename
            dic['stldic']=stldic
            dic['thickdic']=thickdic
            dic['solidid']=self.solidid
            dic['fluidid']=self.fluidid
            Watchpoints = self.Solidgroup.getallmonpoints()
            dic['Watchpoints'] = Watchpoints

            with open(filename, 'w') as f_obj:
                json.dump(dic,f_obj,indent=4)

            youngs = self.para.ui.le_poisson.text()
            posson = self.para.ui.le_cpa.text()
            DeltaT = self.para.ui.le_writetime.text()
            Trange = self.para.ui.le_runtimeac.text()
            Trange2 = self.para.ui.le_runtimesh.text()
            DENSITY = self.para.ui.le_solidrho.text()
            print('Trange',Trange)
            print('Trange2',Trange2)
            print('DeltaT',DeltaT)
            print('DENSITY',DENSITY)
            # MaxT = Decimal(DeltaT) * int(Trange)
            # #TODO 正确读取MaxT2数值
            # MaxT2 = Decimal(DeltaT) * int(Trange2)
            MaxT = self.para.ui.le_runtimeac.text()
            MaxT2 = self.para.ui.le_runtimesh.text()

            # Watchpoints = self.para.ui.le_monpoint.text().split()
            
            #生成precicexml
            from .xmlgen import xmlgen
            xmlgen(DeltaT,str(MaxT),str(MaxT2),Watchpoints,self.currentpath)
            #xmlgen(DeltaT,MaxT,Watchpoints,self.currentpath)
            #利用固体前处理标签页中的信息，在计算目录下生成主要.inp和*mesh.inp
            solidinp(thickdic,stldic,TotalFGroup,BOUNDARY,self.currentpath+'/Solid',youngs,posson,DENSITY,DeltaT,MaxT)
            #solidinp(thickdic,stldic,TotalFGroup,BOUNDARY,self.currentpath+'/Solidpre',youngs,posson,DENSITY,DeltaT,MaxT)
            restartinp(thickdic,stldic,TotalFGroup,BOUNDARY,self.currentpath+'/Solid',youngs,posson,DENSITY,DeltaT,MaxT2)
            unvfilename = medfilename[0:-4]+'.unv'
            Unv2ccx(unvfilename,os.path.join(self.currentpath,'Solid'))
            # Unv2ccx(unvfilename,os.path.join(self.currentpath,'Solidpre'))
            #print(unvfilename,medfilename,self.currentpath,self.currentpath/Path(medfilename).name)
            if medfilename!=str(Path(self.currentpath)/Path(medfilename).name):
                shutil.copyfile(medfilename,Path(self.currentpath)/Path(medfilename).name)
            if unvfilename!=str(Path(self.currentpath)/Path(unvfilename).name):
                shutil.copyfile(unvfilename,Path(self.currentpath)/Path(unvfilename).name)
            minmax6 = self.Solidgroup.minmax6
            print('minmax6 = ',minmax6)
            xmin = minmax6[0]
            ymin = minmax6[1]
            zmin = minmax6[2]
            xmax = minmax6[3]
            ymax = minmax6[4]
            zmax = minmax6[5]

            #生成流体配置文件
            from ..parameterset.fluidinitial import Fluidinitial

            bundaryname = list(stldic.keys())
            param_fluid = dict(coordrang = [xmin,xmax,ymin,ymax,zmin,zmax],
                               boundname = bundaryname,
                               acc=self.para.ui.le_Acceleration.text(),
                               liquidratio = self.para.ui.le_Liquidratio.text(),
                               gravity = self.para.ui.le_Gravit.text(),
                               sigma = self.para.ui.le_dyne.text(),
                               mp_rho = self.para.ui.le_mprho.text(),
                               mp_nu = self.para.ui.le_mpnu.text(),
                               sp_rho = self.para.ui.le_sprho.text(),
                               sp_nu = self.para.ui.le_spnu.text(),
                               writetime = self.para.ui.le_writetime.text(),
                               runtimeac = self.para.ui.le_runtimeac.text(),
                               runtimesh = self.para.ui.le_runtimesh.text()
                               )
            casefluid = Fluidinitial(src,self.currentpath,**param_fluid)
            casefluid.meshinitial()
            casefluid.siminitial()

            return True
            # Q.QMessageBox.information(self, 'Title', '计算文件已成功生成！位于：'+self.currentpath, Q.QMessageBox.Yes)
            
    def addproject(self):
        #pass
        i = self.projects.count()
        #self.projects.addItem("Project-"+str(i+1),"Project-"+str(i+1))
        self.projects.insertItem(-1,"Project-"+str(i+1),"Project-"+str(i+1))

    def opendocx(self):
        # gsn17 的 libreoffice 已损坏!?
        os.system("/usr/bin/libreoffice demo.docx")

    #将固体的.frd结果文件转化/刷新为.pvd文件
    def refreshresult(self):
        #if not self.pvd: 
            #self.pvd=Frd2pvd(self.currentpath+"/Solid/tank.frd")
        #    self.pvd=Frd2pvd(self.currentpath)
        # subprocess.call('env -i ')
        # reconstructPar -newTimes
        # self.tempprocess.setWorkingDirectory(os.path.dirname(os.path.abspath(__file__)))
        # self.tempprocess.start("env -i ./fluidrefresh "+self.currentpath)
        if self.currentpath:
            self.loader1 = BackgroundLoading(self,msg='正在更新后处理结果,请稍候...')
            self.loader1.start()
            pvd=Frd2pvd(self.currentpath)
            pvd.startconvert(self.currentpath)
            self.loader1.terminate()
        else:
            Q.QMessageBox.information(self, 'Title', '工程目录未发现计算结果！', Q.QMessageBox.Yes)

    def dataReady(self):

        self.keyboardWidget = KeyboardWidget()
        #self.keyboardWidget.keyPressed.connect(self.keyCounter)

        SolidOutput = self.solidtextview.textCursor()
        processStdout = bytearray(self.process.readAllStandardOutput())
        processStdout = processStdout.decode(encoding='UTF-8',errors='strict')

        newCursor1 = self.solidtextview.textCursor()
        newCursor1.movePosition(Q.QTextCursor.End)
        self.solidtextview.setTextCursor(newCursor1)
        SolidOutput = self.solidtextview.textCursor()

        SolidOutput.insertText(processStdout)
        #self.solidtextview.ensureCursorVisible()

        FluidOutput = self.fluidtextview.textCursor()
        FluidStdout = bytearray(self.processfluid.readAllStandardOutput())
        FluidStdout = FluidStdout.decode(encoding='UTF-8',errors='strict')
        #FluidOutput.movePosition(Q.QTextCursor.End)
        newCursor = self.fluidtextview.textCursor()
        newCursor.movePosition(Q.QTextCursor.End)
        self.fluidtextview.setTextCursor(newCursor)
        FluidOutput = self.fluidtextview.textCursor()

        FluidOutput.insertText(FluidStdout)
        #self.fluidtextview.ensureCursorVisible()

        TempOutput = self.temptextview.textCursor()
        TempStdout = bytearray(self.tempprocess.readAllStandardOutput())
        TempStdout = TempStdout.decode(encoding='UTF-8',errors='strict')
        #TempOutput.movePosition(Q.QTextCursor.End)
        newCursor3 = self.temptextview.textCursor()
        newCursor3.movePosition(Q.QTextCursor.End)
        self.temptextview.setTextCursor(newCursor3)
        TempOutput = self.temptextview.textCursor()
        
        TempOutput.insertText(TempStdout)
        #self.temptextview.ensureCursorVisible()


    def showreact(self):
            sender = self.sender()
            if sender == self.btFluidpre:
                if not self.currentpath or not os.path.exists(self.currentpath):
                    Q.QMessageBox.information(self, 'Title', '需要先保存工程文件！', Q.QMessageBox.Yes)
                    return

                self.addcase()

                shellpath = os.path.dirname(os.path.abspath(__file__))
                self.processfluid.setWorkingDirectory(shellpath)
                self.process.setWorkingDirectory(shellpath)
                
                cmdfluidpre = '/opt/skyformai/bin/csub -I -A Tanksimulator-MeshGenerate -Jd '+os.path.basename(self.currentpath)
                cmdfluidpre += ' -n '+self.mpicores.currentText()
                cmdfluidpre += ' -q '+self.queue.currentText()
                cmdfluidpre += ' ./fluidprepare '+self.currentpath
                #/home/export/online1/systest/swrh/Tanksimulator/final01/Fluid/constant/polyMesh/sets
                if not os.path.exists(self.currentpath+'/Fluid/constant/polyMesh/sets'):
                    self.processfluid.start(cmdfluidpre)
                else: 
                    self.processfluid.start('echo 直接利用之前保存的流体网格!网格生成步骤已跳过!')

            if sender == self.bt1:
                #print('开始计算！')
                if not self.currentpath or not os.path.exists(self.currentpath):
                    Q.QMessageBox.information(self, 'Title', '需要先保存工程文件！', Q.QMessageBox.Yes)
                elif Path(self.currentpath+'/Solid/tankpre.frd').is_file():
                    Q.QMessageBox.information(self, 'Title', 
                        '当前工程目录已存在计算结果,请使用File->save as或Ctrl+Shift+S创建新工程后再计算!', Q.QMessageBox.Yes)
                elif not (Path(self.currentpath+'/Solid').is_dir() and Path(self.currentpath+'/Fluid').is_dir()):
                    Q.QMessageBox.information(self, 'Title', 
                        '未完成计算准备工作，请点击左侧计算准备按钮后再计算!', Q.QMessageBox.Yes)                        
                else:
                    # cmdsolid='env -i '+'./solidrun '+self.currentpath
                    # cmdsolid='/opt/skyformai/bin/csub -I -A Tanksimulator-Calculix -Jd '+os.path.basename(self.currentpath)+' env -i ./solidrun '+self.currentpath
                    cmdsolid='/opt/skyformai/bin/csub -I -A Tanksimulator-Calculix -Jd '+os.path.basename(self.currentpath)
                    cmdsolid += ' -n '+self.mpicores.currentText()
                    cmdsolid += ' -q '+self.queue.currentText()
                    cmdsolid += ' ./solidrun '+self.currentpath

                    with open (self.currentpath+'/savedata.json') as f:
                        casedata = json.load(f)
                    coupledata = casedata['couple']
                    # DeltaT = coupledata['Timestep']
                    # Trange = coupledata['Stepnumac']
                    # MaxT1 = Decimal(DeltaT) * (int(Trange)-1)
                    # MaxT2 = Decimal(DeltaT) * (int(Trange)+1)
                    MaxT1 = coupledata['Runtimeac']
                    MaxT2 = coupledata['Runtimesh']


                    # cmdfluid='env -i '+'./fluidrun '+self.currentpath+' '+'TODO'+' '+str(MaxT1)+' '+str(MaxT2)
                    cmdfluid='/opt/skyformai/bin/csub -I -A Tanksimulator-Openfoam -Jd '+os.path.basename(self.currentpath)
                    cmdfluid += ' -n '+self.mpicores.currentText()
                    cmdfluid += ' -q '+self.queue.currentText()
                    cmdfluid += ' ./fluidrun '+self.currentpath+' '+'TODO'+' '+str(MaxT1)+' '+str(MaxT2)

                    shellpath = os.path.dirname(os.path.abspath(__file__))
                    self.processfluid.setWorkingDirectory(shellpath)
                    self.process.setWorkingDirectory(shellpath)

                    self.process.start(cmdsolid)
                    self.processfluid.start(cmdfluid)

            if sender == self.btboth:

                self.refreshresult()
                if not self.posttab.solidpvd:
                    self.posttab.load_ofccx_result_call(self.currentpath)
                else:
                    self.posttab.refresh()
                    
            if sender == self.bt4:
                # refreshresult会影响WordShell的运行
                # self.refreshresult()
                self.posttab.autoscreenshots(self.currentpath)

                # if self.paravis is None:
                #     self.paravis = postprocess()
                #     self.paravis.display(self.currentpath)
                
                # self.paravis.activeparavis()

                # if self._loader._done:
                #     self._loader._done = False
                #     self._loader.message = '正在生成.docx报告...'
                #     self._loader.start()
                # self._loader.terminate()

                
                # self.paravis.activateaster()

                self.tempprocess.setWorkingDirectory(os.path.dirname(os.path.abspath(__file__)))
                #os.system("./WordShell")
                self.tempprocess.start("env -i ./WordShell "+self.currentpath) #&& /usr/bin/libreoffice demo.docx")
                 
                # self._loader.terminate()
                #Q.QMessageBox.information(self, 'Title', '报告文档开始生成，完成后请从当前计算路径下载', Q.QMessageBox.Yes)
                #os.system('/usr/bin/libreoffice '+self.currentpath+'/demo.docx')
                #self.bt4.setEnabled(True)

            if sender == self.btbothkill:
                self.process.kill()
                self.processfluid.kill()
                self.tempprocess.kill()

                fenge = '*'*22
                SolidOutput = self.solidtextview.textCursor()
                FluidOutput = self.fluidtextview.textCursor()
                TempOutput = self.temptextview.textCursor()

                if self.currentpath:
                    self.solidid = self.getjobid(self.currentpath+'/log.ccx_preCICE')
                    self.fluidid = self.getjobid(self.currentpath+'/log.interFoam')

                if self.solidid:
                    self.process.start('env -i /usr/sw-mpp/bin/bkill '+self.solidid)

                if self.fluidid:
                    self.processfluid.start('env -i /usr/sw-mpp/bin/bkill '+self.fluidid)

                SolidOutput.insertText(fenge+'即将停止固体计算！'+fenge)
                FluidOutput.insertText(fenge+'即将停止流体计算！'+fenge)

def copytree(src, dst, symlinks=False, ignore=None):
    if not os.path.exists(dst):
        os.makedirs(dst)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            copytree(s, d, symlinks, ignore)
        else:
            if not os.path.exists(d) or os.stat(s).st_mtime - os.stat(d).st_mtime > 1:
                shutil.copy2(s, d)
            # elif os.path.exists(d):
            #     shutil.rmtree

if __name__ == '__main__':
    app = Q.QApplication(sys.argv)
    ex = Maincontrol()
    sys.exit(app.exec_())
