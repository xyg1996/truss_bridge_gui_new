# state file generated using paraview version 4.4.0

# ----------------------------------------------------------------
# setup views used in the visualization
# ----------------------------------------------------------------

#### import the simple module from the paraview
from paraview.simple import *
from paraview import *
import paraview
#import glob
try:
    import xml.etree.cElementTree as et
except ImportError:
    import xml.etree.ElementTree as et
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# Create a new 'Render View'
renderView1 = CreateView('RenderView')
renderView1.ViewSize = [1154, 797]
renderView1.AxesGrid = 'GridAxes3DActor'
renderView1.CenterOfRotation = [0.0, 0.0, -1e-20]
renderView1.StereoType = 0
renderView1.CameraPosition = [0.0, 0.0, 0.9931671704403314]
renderView1.CameraFocalPoint = [0.0, 0.0, -1e-20]
renderView1.CameraParallelScale = 0.25705057868053904
renderView1.Background = [0.32, 0.34, 0.43]

# ----------------------------------------------------------------
# setup the data processing pipelines
# ----------------------------------------------------------------

# create a new 'PVD Reader'
#TODOCHECK PATH
#Abandon Method
#tankfilelist=glob.glob('Solid/tank.*.vtu')

parser = et.parse("Solid/tank.pvd")
root=parser.getroot()
#print(root)

print(len(root[0]))
print(root[0][-1].attrib['file'])

#listlength=len(tankfilelist)
if len(root[0])<4:
#tankvtu = XMLUnstructuredGridReader(FileName=tankfilelist[-1])
    tanklistpick=[root[0][-1].attrib['file']]
    timeseries=[root[0][-1].attrib['timestep']]
    
elif len(root[0])<14:
    tanklistpick=[root[0][2].attrib['file'],root[0][-2].attrib['file']]
    timeseries=[root[0][2].attrib['timestep'],root[0][-2].attrib['timestep']]
else:
    tanklistpick=[root[0][2].attrib['file'],root[0][len(root[0])/2].attrib['file'],root[0][-2].attrib['file']]
    timeseries=[root[0][2].attrib['timestep'],root[0][len(root[0])/2].attrib['timestep'],root[0][-2].attrib['timestep']]

for i in range(len(tanklistpick)):
    vtuname=tanklistpick[i]    
    # ----------------------------------------------------------------
    # setup color maps and opacity mapes used in the visualization
    # note: the Get..() functions create a new object, if needed
    # ----------------------------------------------------------------
    tankvtu = XMLUnstructuredGridReader(FileName='Solid/'+vtuname)
    #filter1 = IntegrateAttributes(Input=tankvtu)
    #filter1Output = Fetch(filter1)
    #val = filter1Output.GetPointData().GetArray("scalars").GetValue(0)
    # get color transfer function/color map for 'S'
    sLUT = GetColorTransferFunction('S')
    sLUT.ApplyPreset('Cool to Warm', True)
    sLUT.ApplyPreset('Cool to Warm')
    print('Cool to Warm')
    #sLUT.RGBPoints = [4997.68505859375, 1.0, 0.0, 0.0, 2489797.25, 0.0, 0.0, 1.0]
    sLUT.RGBPoints = [4997.68505859375, 0.0, 0.0, 1.0, 2489797.25, 1.0, 0.0, 0.0]
    sLUT.ColorSpace = 'HSV'
    sLUT.NanColor = [0.498039215686, 0.498039215686, 0.498039215686]
    sLUT.ScalarRangeInitialized = 1.0
    sLUT.VectorComponent = 6
    sLUT.VectorMode = 'Component'

    # get opacity transfer function/opacity map for 'S'
    sPWF = GetOpacityTransferFunction('S')
    #sPWF.Points = [4997.68505859375, 0.0, 0.5, 0.0, 2489797.25, 1.0, 0.5, 0.0]
    sPWF.Points = [4997.68505859375, 1.0, 0.5, 0.0, 2489797.25, 0.0, 0.5, 0.0]
    sPWF.ScalarRangeInitialized = 1

    # ----------------------------------------------------------------
    # setup the visualization in view 'renderView1'
    # ----------------------------------------------------------------

    # show data from tankvtu
    tankvtuDisplay = Show(tankvtu, renderView1)
    # trace defaults for the display properties.
    tankvtuDisplay.ColorArrayName = ['POINTS', 'S']
    tankvtuDisplay.LookupTable = sLUT
    tankvtuDisplay.ScalarOpacityUnitDistance = 0.024229836131213642

    # show color legend
    tankvtuDisplay.SetScalarBarVisibility(renderView1, True)

    # setup the color legend parameters for each legend in this view

    # get color legend/bar for sLUT in view renderView1
    sLUTColorBar = GetScalarBar(sLUT, renderView1)
    sLUTColorBar.Title = 'S'
    sLUTColorBar.ComponentTitle = 'Mises'
    sLUTColorBar.TitleFontFamily = 'Times'

    thistime=timeseries[i]
    renderView1.CameraPosition = [1.0, 0.0, 0.0]
    SaveScreenshot('maxvonmisesX+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [-1.0, 0.0, 0.0]
    SaveScreenshot('maxvonmisesX-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 1.0, 0.0]
    SaveScreenshot('maxvonmisesY+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, -1.0, 0.0]
    SaveScreenshot('maxvonmisesY-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 0.0, 1.0]
    SaveScreenshot('maxvonmisesZ+'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    renderView1.CameraPosition = [0.0, 0.0, -1.0]
    SaveScreenshot('maxvonmisesZ-'+thistime+'s.png', renderView1, ImageResolution=[1920, 1080])

    # destroy last .vtu
    Delete(tankvtu)
    del tankvtu
