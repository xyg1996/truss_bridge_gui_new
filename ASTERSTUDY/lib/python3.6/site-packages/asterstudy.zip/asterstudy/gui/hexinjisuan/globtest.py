#coding=utf-8
import glob
import matplotlib.pyplot as plt
import os
import csv

#plt.figure(1)
#plt.figure(2)
#plt.figure(3)
#plt.figure(4)
#plt.figure(5)
#plt.figure(6)

#print(glob.glob('precice-Fluid-watchpoint-Solidwatchpoint*.log'))
watchpointfilelist=glob.glob('precice-Fluid-watchpoint-Solidwatchpoint*.log')
for watchpointfile in watchpointfilelist:

    varlist=[]


    with open(watchpointfile,'r') as rfcsv:
        csv_reader = csv.reader(rfcsv)
        #print(next(csv_reader))
        for eachvar in next(csv_reader)[0].split():
            #print(eachvar)
            exec(eachvar + " = []")
            varlist.append(eachvar)
            #print(varlist)
        for line in csv_reader:
            #print(line)
            linesplit=line[0].split()
            #print(linesplit)
            for i in range(len(linesplit)):
                exec(varlist[i] + ".append(float(linesplit[i]))")
                #exec("print("+varlist[i]+")")

    cordinate=[Coordinate0[0],Coordinate1[0],Coordinate2[0]]

    plt.figure(1)
    plt.plot(Time,Forces00,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('X Direction Forces(N)')

    plt.figure(2)
    plt.plot(Time,Forces01,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('Y Direction Forces(N)')

    plt.figure(3)
    plt.plot(Time,Forces02,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('Z Direction Forces(N)')

    plt.figure(4)
    plt.plot(Time,Displacements00,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('X Direction Deformations(m)')

    plt.figure(5)
    plt.plot(Time,Displacements01,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('Y Direction Deformations(m)')

    plt.figure(6)
    plt.plot(Time,Displacements02,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
    plt.xlabel('Time(s)')
    plt.ylabel('Z Direction Deformations(m)')

#plt.legend(loc='lower right')
plt.figure(1)
plt.legend()
plt.savefig("DirectionXForces(N).png")

plt.figure(2)
plt.legend()
plt.savefig("DirectionYForces(N).png")

plt.figure(3)
plt.legend()
plt.savefig("DirectionZForces(N).png")

plt.figure(4)
plt.legend()
plt.savefig("DirectionXDeformations(m).png")

plt.figure(5)
plt.legend()
plt.savefig("DirectionYDeformations(m).png")

plt.figure(6)
plt.legend()
plt.savefig("DirectionZDeformations(m).png")









