#coding:utf-8

import sys
import datetime

from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn

import glob
import matplotlib.pyplot as plt
import os
import csv

from lxml import etree
from xml.etree import ElementTree
import numpy
import scipy
from scipy import spatial
from dat2txt import Dat2txt
from plotTXT import PlotTXT
import json
from pathlib import Path

def WordProcess():

    #获取precice的观察点记录文件的列表
    watchpointfilelist=glob.glob('precice-Fluid-watchpoint-Solidwatchpoint*.log')
    print(watchpointfilelist)
    if watchpointfilelist:
        for watchpointfile in watchpointfilelist:

            varlist=[]
            watchpointfiledic = {}

            with open(watchpointfile,'r') as rfcsv:
                csv_reader = csv.reader(rfcsv)
                for eachvar in next(csv_reader)[0].split():
                    #print(eachvar)
                    watchpointfiledic[eachvar] = []
                    varlist.append(eachvar)
                    
                for line in csv_reader:
                    linesplit=line[0].split()
                    for i in range(len(linesplit)):
                        watchpointfiledic[varlist[i]].append(float(linesplit[i]))

            print(watchpointfiledic)
            print(varlist)

            Coordinate0 = watchpointfiledic['Coordinate0']
            Coordinate1 = watchpointfiledic['Coordinate1']
            Coordinate2 = watchpointfiledic['Coordinate2']
            Time = watchpointfiledic['Time']
            Forces00 = watchpointfiledic['Forces00']
            Forces01 = watchpointfiledic['Forces01']
            Forces02 = watchpointfiledic['Forces02']
            Displacements00 = watchpointfiledic['Displacements00']
            Displacements01 = watchpointfiledic['Displacements01']
            Displacements02 = watchpointfiledic['Displacements02']

            cordinate=[Coordinate0[0],Coordinate1[0],Coordinate2[0]]

            plt.figure(1)
            plt.plot(Time,Forces00,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('X Direction Forces(N)')

            plt.figure(2)
            plt.plot(Time,Forces01,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('Y Direction Forces(N)')

            plt.figure(3)
            plt.plot(Time,Forces02,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('Z Direction Forces(N)')

            plt.figure(4)
            plt.plot(Time,Displacements00,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('X Direction Deformations(m)')

            plt.figure(5)
            plt.plot(Time,Displacements01,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('Y Direction Deformations(m)')

            plt.figure(6)
            plt.plot(Time,Displacements02,label='X='+str(cordinate[0])+' Y='+str(cordinate[1])+' Z='+str(cordinate[2]))
            plt.xlabel('Time(s)')
            plt.ylabel('Z Direction Deformations(m)')

        #plt.legend(loc='lower right')
        plt.figure(1)
        plt.legend()
        plt.savefig("DirectionXForces(N).png")

        plt.figure(2)
        plt.legend()
        plt.savefig("DirectionYForces(N).png")

        plt.figure(3)
        plt.legend()
        plt.savefig("DirectionZForces(N).png")

        plt.figure(4)
        plt.legend()
        plt.savefig("DirectionXDeformations(m).png")

        plt.figure(5)
        plt.legend()
        plt.savefig("DirectionYDeformations(m).png")

        plt.figure(6)
        plt.legend()
        plt.savefig("DirectionZDeformations(m).png")

    if glob.glob('Solid/*.dat'):
        #将Calculix生成的.dat转换为.txt    
        Dat2txt()    
        #将.txt绘制成图
        PlotTXT()

    parser = ElementTree.parse("Solid/tank.pvd")
    root=parser.getroot()
    tanklistpick=[]
    timeseries=[]

    print(len(root[0]))
    for i in range(len(root[0])):
        tanklistpick.append('Solid/'+root[0][i].attrib['file'])
        timeseries.append(float(root[0][i].attrib['timestep']))

    #自动截取固体三视图 自动确定结果数量 从中选取5步 利用求余？？
    #TODO录制脚本

    document = Document()
    document.styles['Normal'].font.name = u'宋体'
    document.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), u'宋体')

    document.add_heading(u'Tank Simulator罐腔液体晃动仿真报告', 0)

    section = document.sections[0]
    header = section.header

    paragraph = header.paragraphs[0]
    d = datetime.datetime.today()
    datestr=str(d.year)+u'年'+str(d.month)+u'月'+str(d.day)+u'日'
    paragraph.text = u'国家超级计算无锡中心\t'+datestr+u'\t先进制造部'

    document.add_heading(u'一、概述', level=1)
    p = document.add_paragraph(u'本报告生成于'+str(d.year)+"年"+str(d.month)+"月"+str(d.day)+"日"+str(d.hour)+":"+str(d.minute)+":"+str(d.second))
    p = document.add_paragraph(u'本次仿真使用CFD求解器OpenFoam，耦合库PreCice以及有限元求解器Calculix。')
    p = document.add_paragraph(u'其中全局基本信息如下表所示:')
    table = document.add_table(rows=1, cols=2,style='Light Shading Accent 1')
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = u'要素'
    hdr_cells[1].text = u'值'
    #hdr_cells[2].text = 'Desc'

    row_cells = table.add_row().cells
    row_cells[0].text = u'时间步长'
    row_cells[1].text = str((float(timeseries[-1])-float(timeseries[0]))/(len(timeseries)-1))+'s'

    row_cells = table.add_row().cells
    row_cells[0].text = u'总时间步数'
    row_cells[1].text = str(len(timeseries))+'步'

    p = document.add_paragraph(u' ')
    p = document.add_paragraph(u'其中固体部分基本信息如下表所示:')
    #records = (
    #    (3, '101'),
    #    (7, '422'),
    #    (4, '631')
    #)

    #TODO 从.json中获取zidiantest
    zidiantest={'solidmeshnum':100,'fluidmeshnum':100,'chongyebi':0.4,'young':2e11,'posson':0.35}

    table = document.add_table(rows=1, cols=2,style='Light Shading Accent 1')
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = u'要素'
    hdr_cells[1].text = u'值'
    #hdr_cells[2].text = 'Desc'


    row_cells = table.add_row().cells
    row_cells[0].text = u'固体体网格数'
    row_cells[1].text = str(zidiantest['solidmeshnum'])

    row_cells = table.add_row().cells
    row_cells[0].text = u'杨氏模量'
    row_cells[1].text = str(zidiantest['young'])

    row_cells = table.add_row().cells
    row_cells[0].text = u'泊松比'
    row_cells[1].text = str(zidiantest['posson'])

    p = document.add_paragraph('')
    p = document.add_paragraph(u'流体部分基本信息如下表所示:')

    table = document.add_table(rows=1, cols=2,style='Light Shading Accent 1')
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = u'要素'
    hdr_cells[1].text = u'值'
    #hdr_cells[2].text = 'Desc'

    row_cells = table.add_row().cells
    row_cells[0].text = u'流体网格数'
    row_cells[1].text = str(zidiantest['fluidmeshnum'])

    row_cells = table.add_row().cells
    row_cells[0].text = u'充液比'
    row_cells[1].text = str(zidiantest['chongyebi'])

    document.add_heading(u'二、罐腔固体晃动仿真结果', level=1)
    #document.add_paragraph(
    #    u'概述', style='List Number'
    #)

    #document.add_picture('Von-Mises Stress.png', width=Inches(5.0))

    #添加失稳结果图
    #document.add_picture('shiwen-1.png', width=Inches(5.0))

    #开始Von-Mise数据统计与画图 ！！！！！！
    parser = ElementTree.parse("Solid/tank.pvd")
    root=parser.getroot()
    tanklistpick=[]
    timeseries=[]

    print(len(root[0]))
    for i in range(len(root[0])):
        tanklistpick.append('Solid/'+root[0][i].attrib['file'])
        timeseries.append(float(root[0][i].attrib['timestep']))

    print('tanklistpick',tanklistpick)
    # with open(tanklistpick[0]) as xml:
    #     roottemp = etree.XML(xml.read())

    # print(tanklistpick)
    xml_file = tanklistpick[0]
    dom= ElementTree.parse(xml_file)

    #只需一次 生成所有坐标的cKD Tree
    strcordinates=dom.findall('UnstructuredGrid/Piece/Points/DataArray')[-1].text
    strcordsplit=strcordinates.split()
    strcordsplit=[float(i) for i in strcordsplit]
    cord = numpy.array(strcordsplit)
    cord = numpy.reshape(cord,(len(cord)//3,3))
    
    print(cord)
    cordtree=scipy.spatial.cKDTree(cord)
    #TODO：与用户的交互 读取用户输入的观察点 坐标值
    #这里先把Allwatchpoints写死 之后更改
    #Allwatchpoints=[numpy.array([-0.05,0,1]),numpy.array([0.05,0,-1]),numpy.array([-1.05,0.6,1]),numpy.array([2.05,-0.5,-1]),]
    with open('savedata.json') as file_obj: 
        temp = json.load(file_obj)
    # watchpoint = temp["couple"]["Monpoint"].split()
    # watchpoint = numpy.array(list(map(float, watchpoint)))
    # Allwatchpoints = [watchpoint]
    Allwatchpoints = []
    for key in temp["Watchpoints"]:
        watchpoint = numpy.array(list(map(float, temp["Watchpoints"][key])))
        Allwatchpoints.append(watchpoint)

    Realwatchpoints=[]
    Allindex=[]
    # Allmises=[]
    # Maxmises=[]
    # Maxpoints=[]
    
    # 采用多层嵌套的字典数据结构改写
    # AllS = {}
    # AllS[Maxpoints] = []
    # AllS[Maxmises] = []
    SolidData = {}
    SolidDataType = ['U','S','E']
    for datatype in SolidDataType:
        SolidData[datatype] = {}

    UDataType = ['XX','YY','ZZ',]
    for datatype in UDataType:
        SolidData['U'][datatype] = {}

    SDataType = ['XX','YY','ZZ','XY','YZ','ZX',"Mises","Min Principal","Mid Principal","Max Principal"]
    for datatype in SDataType:
        SolidData['S'][datatype] = {}

    EDataType = ['XX','YY','ZZ','XY','YZ','ZX',"Mises","Min Principal","Mid Principal","Max Principal"]
    for datatype in SDataType:
        SolidData['E'][datatype] = {}

    Allwatchpointex = ['Max of all points','Cord of max point']
    for eachpoint in Allwatchpoints:
        #查询到的节点序号是 result[1] 
        result=cordtree.query(eachpoint)
        Allwatchpointex.append(result[1])
        #查询到的节点序号是 result[1] 

        #Allindex.append(result[1])
        # Allmises.append([])
        #Realwatchpoints.append(cord[result[1]])

    for eachpoint in Allwatchpointex:
        for key0 in SolidData:
            for key1 in SolidData[key0]:
                SolidData[key0][key1][eachpoint] = []

    #生成字典SolidData中的数据
    for eachvtu in tanklistpick:
        eachdom = ElementTree.parse(eachvtu)
        for i,key0 in enumerate(SolidData):
            datastr = eachdom.findall('UnstructuredGrid/Piece/PointData/DataArray')[i].text
            data = numpy.array([float(i) for i in datastr.split()])
            #TODO kk单独计算
            # SDataType EDataType 均有10个分量 但UDataType只有三个
            # kk = len(data)//10
            kk = len(data)//len(SolidData[key0])
            data = numpy.reshape(data,(kk,len(SolidData[key0])))

            for j,key1 in enumerate(SolidData[key0]):
                for k,key2 in enumerate(SolidData[key0][key1]):
                    # if key2=='Max of all points':
                    if k == 0:
                        SolidData[key0][key1][key2].append(max(data[:,j]))
                    # elif key2=='Cord of max point':
                    elif k == 1:
                        # SolidData[key0][key1][key2] += cord[numpy.argmax(data[:,j])]
                        SolidData[key0][key1][key2].append(cord[numpy.argmax(data[:,j])])
                        
                    else:
                        # print(data[:,j])
                        SolidData[key0][key1][key2].append(data[:,j][key2])
                        
                        

        # Udatastr = eachdom.findall('UnstructuredGrid/Piece/PointData/DataArray')[0].text
        # Sdatastr = eachdom.findall('UnstructuredGrid/Piece/PointData/DataArray')[1].text
        # Edatastr = eachdom.findall('UnstructuredGrid/Piece/PointData/DataArray')[2].text
        # [0]对应位移U
        # <DataArray type="Float32" Name="U" NumberOfComponents="3" ComponentName0="D1" ComponentName1="D2" ComponentName2="D3" format="ascii">
        # [1]对应 应力S
        # <DataArray type="Float32" Name="S" NumberOfComponents="10" ComponentName0="xx" ComponentName1="yy" ComponentName2="zz" 
        # ComponentName3="xy" ComponentName4="yz" ComponentName5="zx" ComponentName6="Mises" ComponentName7="Min Principal" 
        # ComponentName8="Mid Principal" ComponentName9="Max Principal" format="ascii">
        # [2]对应 应变E
        # <DataArray type="Float32" Name="E" NumberOfComponents="10" ComponentName0="xx" ComponentName1="yy" ComponentName2="zz" ComponentName3

        #another = Sdatastr.split()
        #another = [float(i) for i in Sdatastr.split()]
        #print(another)

        # Sdata = numpy.array([float(i) for i in Sdatastr.split()])
        # kk = len(Sdata)//10
        # Sdata = numpy.reshape(Sdata,(kk,10))

        # Udata = numpy.array([float(i) for i in Udatastr.split()])
        # Udata = numpy.reshape(Udata,(kk,10))

        # Edata = numpy.array([float(i) for i in Edatastr.split()])
        # Edata = numpy.reshape(Edata,(kk,10))

        # misesstress = Sdata[:,6]
        # minprinstress = Sdata[:,7]
        # midprinstress = Sdata[:,8]
        # maxprinstress = Sdata[:,9]

        # Maxmises.append(max(misesstress))
        # Maxpoints.append(cord[numpy.argmax(misesstress)])

        # Ux = Udata[:,0]
        # Uy = Udata[:,1]
        # Uz = Udata[:,2]

        # #TODO
        # # Ex = Edata[:]

        # for index in range(len(Allindex)):
        #     Allmises[index].append(misesstress[index])
        

    #打印 所有观察点的Von-Mises应力
    # print(Allmises[0])
    # print(Allmises[-1])
    # #print(Allmises)
    # #打印时间步
    # print(timeseries)
    # print(Allwatchpoints)
    # print(Realwatchpoints)

    #(1)画Von-Mises应力的图
    # plt.figure(666)
    # for ii in range(len(Allindex)):
    #     plt.plot(timeseries,Allmises[ii],label='X='+str(Realwatchpoints[ii][0])+' Y='+str(Realwatchpoints[ii][1])+' Z='+str(Realwatchpoints[ii][2]))
    #     plt.xlabel('Time(s)')
    #     plt.ylabel('Von-Mises Stress(Pa)')
    #     plt.legend()
    
    # plt.plot(timeseries,Maxmises,label='Max in All points')
    # plt.xlabel('Time(s)')
    # plt.ylabel('Von-Mises Stress(Pa)')
    # plt.legend()
    # plt.savefig("Von-Mises Stress.png")

    # 遍历多层字典SolidData 画出所有数据的统计图 TODO酌情删减不必要的数据
    # for i,key in enumerate(SolidData):
    for key0 in SolidData:
        for key1 in SolidData[key0]:
            plt.figure(key0+'-'+key1)
            for k,key2 in enumerate(SolidData[key0][key1]):
                # if key2 == 'Max of all points'
                if k != 1:
                    if k == 0:
                        lb=key2
                        plt.plot(timeseries,SolidData[key0][key1][key2],label=lb)
                        plt.xlabel('Time(s)')
                        plt.ylabel(key0+'-'+key1)
                        plt.legend()
                        plt.savefig(key0+'-'+key1+'.png')
                        tindex = numpy.argmax(SolidData[key0][key1][key2])
                        maxtime = timeseries[tindex]
                        maxcord = SolidData[key0][key1]['Cord of max point'][tindex]  

                    elif k>1:
                        # lb=str(cord[key2]) 
                        lb = 'X='+str(cord[key2][0])+' Y='+str(cord[key2][1])+' Z='+str(cord[key2][2])
                        plt.plot(timeseries,SolidData[key0][key1][key2],label=lb)
                        plt.xlabel('Time(s)')
                        plt.ylabel(key0+'-'+key1)
                        plt.legend()
                        plt.savefig(key0+'-'+key1+'.png')
            if key0=='S':
                word = u'应力'
            elif key0=='E':
                word = u'应变'
            elif key0=='U':
                word = u'位移'
            
            document.add_paragraph(word+key1+u'方向的结果如下图所示,所有节点中的最大值出现在'+str(maxtime)+u'秒,位置是'+str(maxcord))
            document.add_picture(key0+'-'+key1+'.png', width=Inches(5.0))


    document.add_paragraph(
        u'观察点结果统计', style='List Number'
    )

    #p = document.add_paragraph(u'根据设置的%个观察点统计出的力与变形结果如下图所示(TODO：用户交互)')
    p = document.add_paragraph(u'本次仿真共设置了'+str(len(Allwatchpoints))+u'个观察点，Tanksimulator通过最邻近搜索自动匹配最近节点\
    观察点与匹配最近节点坐标如下表所示，一般情况下，观察点与匹配最近节点坐标的差距应该为网格大小的量级\
    如果差距过大建议重新设置观察点。')

    #zidiantest={'solidmeshnum':100,'fluidmeshnum':100,'chongyebi':0.4,'young':2e11,'posson':0.35}

    tablewatchpoint = document.add_table(rows=1, cols=3,style='Light Shading Accent 1')
    watchpointcells = tablewatchpoint.rows[0].cells
    watchpointcells[0].text = u'观察点序号'
    watchpointcells[1].text = u'设置的观察点坐标'
    watchpointcells[2].text = u'匹配的最近节点坐标'

    # for ii in range(len(Allindex)):
    #     watchpointcells = tablewatchpoint.add_row().cells
    #     watchpointcells[0].text = str(ii+1)
    #     watchpointcells[1].text = str(Allwatchpoints[ii])
    #     watchpointcells[2].text = str(Realwatchpoints[ii])

    print(Allwatchpointex)
    print(Allwatchpoints)

    for ii in range(2,len(Allwatchpointex)):
        watchpointcells = tablewatchpoint.add_row().cells
        watchpointcells[0].text = str(ii-1)
        watchpointcells[1].text = str(Allwatchpoints[ii-2])
        watchpointcells[2].text = str(cord[Allwatchpointex[ii]])
    p = document.add_paragraph(u' ')
    # p = document.add_paragraph(u'所有节点中的最大Von-Mises应力值随时间变化如下图所示：')
    # document.add_picture('Max Von-Mises Stress.png', width=Inches(5.0))

    #如下统计出的力与变形结果如下图所示(TODO：用户交互)')
    # p = document.add_paragraph(u'各匹配节点三个方向的节点力随时间变化如下图所示：')

    # document.add_picture('DirectionXForces(N).png', width=Inches(5.0))

    # document.add_picture('DirectionYForces(N).png', width=Inches(5.0))

    # document.add_picture('DirectionZForces(N).png', width=Inches(5.0))

    # p = document.add_paragraph(u'各匹配节点三个方向的位移随时间变化如下图所示：')

    # document.add_picture('DirectionXDeformations(m).png', width=Inches(5.0))

    # document.add_picture('DirectionYDeformations(m).png', width=Inches(5.0))

    # document.add_picture('DirectionZDeformations(m).png', width=Inches(5.0))

    document.add_paragraph(
        u'分组结果统计', style='List Number'
    )

    # with open('solid.json') as file_obj:
    with open('savedata.json') as file_obj: 
        temp = json.load(file_obj)
        print(temp)
        BOUNDARY = temp['BOUNDARY']
        TotalFGroup = temp['TotalFGroup']

    p = document.add_paragraph(u'本次仿真对于固体的节点共设置了'+str(len(BOUNDARY))+u'组边界条件,各分组的信息如下表所示：')

    tablefenzu = document.add_table(rows=1, cols=2,style='Light Shading Accent 1')
    fenzucells = tablefenzu.rows[0].cells
    fenzucells[0].text = u'分组名称'
    fenzucells[1].text = u'设置的边界条件种类'
    #fenzucells[2].text = u'是否统计合力'

    for key in BOUNDARY:
        fenzucells = tablefenzu.add_row().cells
        fenzucells[0].text = key
        #fenzucells[0].text = BOUNDARY[key]
        bianjie = '固定自由度：'
        for i in BOUNDARY[key]:
            if i==1:
                bianjie += 'DX,'
            if i==2:
                bianjie += 'DY,'
            if i==3:
                bianjie += 'DZ,'
            if i==4:
                bianjie += 'RX,'
            if i==5:
                bianjie += 'RY,'
            if i==6:
                bianjie += 'RZ,'
        fenzucells[1].text = bianjie

    # for ii in range(len(Allindex)):
    #     fenzucells = tablefenzu.add_row().cells
    #     fenzucells[0].text = str(ii+1)
    #     fenzucells[1].text = str(Allfenzu[ii])
        #fenzucells[2].text = str(Realfenzu[ii])

    p = document.add_paragraph(' ')
    p = document.add_paragraph(u'对于需要统计合力的分组，其所受合力随时间变化如下图所示')
    document.add_picture('fenzuXForces(N).png', width=Inches(5.0))

    document.add_picture('fenzuYForces(N).png', width=Inches(5.0))

    document.add_picture('fenzuZForces(N).png', width=Inches(5.0))

    #p = document.add_paragraph(u'calculix收敛情况随时间步的变化如下图所示：')
    #document.add_picture('Solid/tank.png', width=Inches(5.0))

    document.add_paragraph(
        u'固体结果三视图', style='List Number'
    )

    parser = ElementTree.parse("Solid/tank.pvd")
    root=parser.getroot()

    if len(root[0])<4:
        Foamtimes=[root[0][-1].attrib['timestep']]
        screenshotindex = [-1]
    elif len(root[0])<14:
        Foamtimes=[root[0][2].attrib['timestep'],root[0][-2].attrib['timestep']]
        screenshotindex = [2,-2]
    else:
        Foamtimes=[root[0][2].attrib['timestep'],root[0][len(root[0])//2].attrib['timestep'],root[0][-2].attrib['timestep']]
        screenshotindex = [2,len(root[0])//2,-2]

    p = document.add_paragraph(u'自动截取的固体结果三视图如下图所示(自动截取的时间步为'+str(Foamtimes)+u'),为了取得更好的效果，\
    请点击Tanksimulator中查看固体结果按钮，在弹出的paraview窗口中手动截图或录制视频，paraview的操作方法请参照www.xxx.com')

    #maxdeformation
    #maxvonmises

    p = document.add_paragraph(u'固体结果Von-Mises的应力三视图如所示：')
    vmisespnglist=glob.glob('maxvonmises*.png')
    #                        alphawater
    for each in vmisespnglist:
        pngtimes=each[13:-4]
        pngdirection=each[11:13]
        p = document.add_paragraph(pngtimes+u'时'+pngdirection+u'方向'+u'Von-Mises应力的结果如下：')
        document.add_picture(each, width=Inches(5.0))


    p = document.add_paragraph(u'固体结果应变的三视图如下所示：')
    deformpnglist=glob.glob('maxdeformation*.png')
    for each in deformpnglist:
        pngtimes=each[16:-4]
        pngdirection=each[14:16]
        p = document.add_paragraph(pngtimes+u'时'+pngdirection+u'方向'+u'变形的结果如下：')
        document.add_picture(each, width=Inches(5.0))

    #document.add_page_break()

    document.add_paragraph(
        u'流体结果三视图', style='List Number'
    )

    #创建自动截图的文件夹
    # os.system('rm -rf TempFoam')
    # os.system('mkdir -p TempFoam/constant')
    # os.system('mkdir -p TempFoam/Fluid.foam')
    # os.system('cp -r Fluid/constant TempFoam')
    # os.system('cp -r Fluid/Fluid.foam TempFoam')
    # for foam in Foamtimes:
    #     os.system('mkdir -p TempFoam/'+foam)
    #     os.system('cp -r Fluid/'+foam+' TempFoam')
    #     os.system('pvpython alphawatershot.py')
    #     os.system('rm -rf TempFoam/'+foam)

    p = document.add_paragraph(u'流体结果的两相流分布三视图如下所示，自动截取的固体结果三视图如下图所示(自动截取的时间步为'+str(Foamtimes)+u'),为了取得更好的效果，\
    请点击Tanksimulator中查看流体结果按钮，在弹出的paraview窗口中手动截图或录制视频，paraview的操作方法请参照www.xxx.com')
    deformpnglist=glob.glob('alphawater*s.png')
    for each in deformpnglist:
        pngtimes=each[12:-4]
        pngdirection=each[10:12]
        p = document.add_paragraph(pngtimes+u'时'+pngdirection+u'方向'+u'两相流分布的结果如下：')
        document.add_picture(each, width=Inches(5.0))

    document.add_heading(u'三、联系我们', level=1)
    document.add_paragraph(u'由于本仿真报告完全是自动生成,如果您在使用过程中发现该说明没有提及的错误，请联系我们的工作人员。\
    我们一直在对 Tanksimulator 进行持续的优化，力争为用户提供一个高效稳定的版本。')

    tablecontact = document.add_table(rows=1, cols=2,style='Light Shading Accent 1')
    contactcells = tablecontact.rows[0].cells
    contactcells[0].text = u'联系人'
    contactcells[1].text = u'邮箱'

    contactcells = tablecontact.add_row().cells
    contactcells[0].text = u' '
    contactcells[1].text = '  @mail.nsccwx.cn'

    contactcells = tablecontact.add_row().cells
    contactcells[0].text = u' '
    contactcells[1].text = '  @mail.nsccwx.cn'

    document.save('demo.docx')

if __name__ == '__main__':
    WordProcess()

