import PyQt5.Qt as Q
from .behavior import behavior
# from .remotefs import MountWorker
from .widgets import PopupFrame

class LoadingMessage(Q.QObject):
    """Object that manages loading messages."""

    def __init__(self, parent, msg="Loading", closable=True):
        """Initialization.

        Arguments:
            parent (QWidget): Parent widget.
        """
        super().__init__()

        self._done = False
        self.widget = None
        self.timer = None
        self.parent = parent
        self.message = msg
        self.closable = closable

    def start(self, interval=1000):
        """Shows a loading page that is maintained until it is done."""
        self.widget = PopupFrame(self.parent,size=(400,100),
                                 msg=self.message,
                                 closable=self.closable)
        self.widget.move(0, 0)
        self.widget.resize(self.parent.width(), self.parent.height())
        self.widget.show()
        self.widget.closed.connect(self.close)

        self.timer = Q.QTimer(self.widget)
        self.timer.setInterval(interval)
        self.timer.timeout.connect(self.check_end)
        self.timer.start()
        self.init_tasks()

    # pragma pylint: disable=no-self-use
    def init_tasks(self):
        """Execute initialization tasks"""
        return

    # pragma pylint: disable=no-self-use
    def closure_tasks(self):
        """Execute closure tasks"""
        return

    def close(self):
        """Closes the popup manually (without interrupting tasks that are
        eventually running in background).
        """
        self.terminate()
        self.check_end()

    def check_end(self):
        """Check if the loading popup can be closed."""
        if self._done:
            self.timer.stop()
            self.widget.close()

    def terminate(self):
        """Note that the loading is terminated."""
        self._done = True

class BackgroundLoading(LoadingMessage):
    """Object that manage the loading of the module."""

    def __init__(self, parent, msg=''):
        """Initialization.

        Arguments:
            parent (QWidget): Parent widget.
        """
        # msg = translate("AsterStudy",
        #                 "Please wait while AsterStudy "
        #                 "finishes loading...")
        if not msg:
            msg = '未指定过度文字信息'
        LoadingMessage.__init__(self, parent, msg)
        # self.mountWorker = MountWorker()

    def init_tasks(self):
        """Execute initialization tasks"""
        if behavior().connect_servers_init:
            self.mount()

    def closure_tasks(self):
        """Execute closure tasks"""
        self.unmount()

    def mount(self):
        """Start thread to mount remote filesystems."""
        # self.mountThread.start()
        # self.mountStarted.emit()
        # self.mountWorker.mount()
        pass

    def unmount(self):
        """Unmount remote filesystems."""
        # self.mountWorker.unmount()
        pass
