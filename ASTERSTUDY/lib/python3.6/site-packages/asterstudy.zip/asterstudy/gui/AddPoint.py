# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'AddPoint.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_AddPoint(object):
    def setupUi(self, AddPoint):
        AddPoint.setObjectName("AddPoint")
        AddPoint.resize(574, 130)
        self.gridLayout_2 = QtWidgets.QGridLayout(AddPoint)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(AddPoint)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.lineEdit = QtWidgets.QLineEdit(AddPoint)
        self.lineEdit.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit.setObjectName("lineEdit")
        self.gridLayout.addWidget(self.lineEdit, 0, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(AddPoint)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 2, 1, 1)
        self.lineEdit_2 = QtWidgets.QLineEdit(AddPoint)
        self.lineEdit_2.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.gridLayout.addWidget(self.lineEdit_2, 0, 3, 1, 1)
        self.label_3 = QtWidgets.QLabel(AddPoint)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 0, 4, 1, 1)
        self.lineEdit_3 = QtWidgets.QLineEdit(AddPoint)
        self.lineEdit_3.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.gridLayout.addWidget(self.lineEdit_3, 0, 5, 1, 1)
        self.lineEdit_4 = QtWidgets.QLineEdit(AddPoint)
        self.lineEdit_4.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.gridLayout.addWidget(self.lineEdit_4, 1, 1, 1, 1)
        self.pushButton = QtWidgets.QPushButton(AddPoint)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 1, 3, 1, 1)
        self.pushButton_2 = QtWidgets.QPushButton(AddPoint)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout.addWidget(self.pushButton_2, 1, 5, 1, 1)
        self.label_4 = QtWidgets.QLabel(AddPoint)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 1, 0, 1, 1)
        self.gridLayout_2.addLayout(self.gridLayout, 0, 0, 1, 1)

        self.retranslateUi(AddPoint)
        QtCore.QMetaObject.connectSlotsByName(AddPoint)

    def retranslateUi(self, AddPoint):
        _translate = QtCore.QCoreApplication.translate
        AddPoint.setWindowTitle(_translate("AddPoint", "Form"))
        self.label.setText(_translate("AddPoint", "X"))
        self.label_2.setText(_translate("AddPoint", "Y"))
        self.label_3.setText(_translate("AddPoint", "Z"))
        self.pushButton.setText(_translate("AddPoint", "添加"))
        self.pushButton_2.setText(_translate("AddPoint", "删除"))
        self.label_4.setText(_translate("AddPoint", "观察点名"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    AddPoint = QtWidgets.QWidget()
    ui = Ui_AddPoint()
    ui.setupUi(AddPoint)
    AddPoint.show()
    sys.exit(app.exec_())

