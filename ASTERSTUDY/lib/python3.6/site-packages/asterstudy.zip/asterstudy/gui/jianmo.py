from PyQt5 import Qt as Q

class Jianmo(Q.QWidget):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setMaximumHeight(40)
        self.setMaximumWidth(90)
        self.alllayout = Q.QVBoxLayout(self)
        self.edit = Q.QLineEdit('输入长宽高(m)',self)
        self.bt = Q.QPushButton('创建模型',self)
        self.alllayout.addWidget(self.edit)
        self.alllayout.addWidget(self.bt)