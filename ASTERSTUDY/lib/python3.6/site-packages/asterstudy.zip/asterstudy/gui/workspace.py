"""
Workspace
---------
"""
from itertools import chain

from PyQt5 import Qt as Q

from ..common import connect, font, is_child, load_icon, translate, wrap_html
from . import Entity, Context, Panel, WorkingMode
from . behavior import behavior
# 各个标签页内容对应的class
from . results import Results
from .hexinjisuan.controltab import Maincontrol
from .preprocess import ParameterMeshGroupView
from .parameterset.TankSimulator import MainWindow
from .geom import GEOM

__workspace__version__ = '2.0'

class Workspace(Q.QWidget):
    """
    `Workspace` is a class that manages main GUI elements of the
    AsterStudy application.

    To access main GUI elements like *Data Settings* or *Edition*
    views, use `view()` method.
    """

    modeChanged = Q.pyqtSignal(int)
    """
    Signal: emitted when workspace is switched between `History` and
    `Case` working modes.

    Arguments:
        mode (int): Working mode (see `WorkingMode`).
    """

    selectionChanged = Q.pyqtSignal(int)
    """
    Signal: emitted when selection is changed.

    Arguments:
        context (int): Selection context (see `Context`).
    """

    popupMenuRequest = Q.pyqtSignal(int, "QPoint")
    """
    Signal: emitted when context popup menu is requested.

    Arguments:
        context (int): Event context (see `Context`).
        point (QPoint): Mouse cursor position.
    """

    itemChanged = Q.pyqtSignal(Entity, str, int)
    """
    Signal: emitted when data item is changed.

    Arguments:
        entity (Entity): Selection entity.
        value (str): New item's value.
        context (int): Selection context (see `Context`).
    """

    itemActivated = Q.pyqtSignal(Entity, int)
    """
    Signal: emitted when data item is activated.

    Arguments:
        entity (Entity): Selection entity.
        context (int): Selection context (see `Context`).
    """

    editModeActivated = Q.pyqtSignal()
    """
    Signal: emitted when application switches from View to Edit mode.
    """

    #def __init__(self, astergui, parent=None, tab_position=Q.QTabWidget.West):
    #将标签页移动至上方
    def __init__(self, astergui, parent=None, tab_position=Q.QTabWidget.North):
        """
        Create workspace.

        Arguments:
            parent (Optional[QWidget]): Parent widget. Defaults to
                *None*.
            tab_position (Optional[QTabWidget.TabPosition]): Position
                of tab pages. Defaults to QTabWidget.West (left,
                vertical).
        """
        Q.QWidget.__init__(self, parent)

        # font1 = Q.QFont()
        # font1.setPointSize(11)
        # self.setFont(font1)

        self.astergui = astergui
        self.pages = {}
        self.panels = {}
        self.views = {}

        # ##
        # A. Set-up main workspace area as tab widget with two pages
        # ##

        self.main = Q.QTabWidget(self)
        self.main.setSizePolicy(Q.QSizePolicy.Expanding, Q.QSizePolicy.Expanding)
        self.main.setTabPosition(tab_position)
        self.main.setTabsClosable(True)
        v_layout = Q.QVBoxLayout(self)
        v_layout.setContentsMargins(0, 0, 0, 0)
        v_layout.addWidget(self.main)

        # self.pages[WorkingMode.StartMode] = Q.QWidget(self.main)
        # self.main.addTab(self.pages[WorkingMode.StartMode],
        #                  load_icon("jianmo.png"),
        #                  '欢迎页')

        self.pages[WorkingMode.JianmoMode] = Q.QWidget(self.main)
        self.pages[WorkingMode.JianmoMode].hide()
        # self.main.addTab(self.pages[WorkingMode.JianmoMode],
        #                  load_icon("jianmo.png"),
        #                  '参数化几何建模')

        #  Add 固体前处理 page
        self.pages[WorkingMode.QianchuliMode] = Q.QWidget(self.main)
        self.main.addTab(self.pages[WorkingMode.QianchuliMode],
                         load_icon("mechanical.png"),
                         "前处理及边界设置")

        #  Add 流体/固体/仿真设置(TODO) page
        self.pages[WorkingMode.SettingMode] = Q.QWidget(self.main)
        self.main.addTab(self.pages[WorkingMode.SettingMode],
                         load_icon("tabseticon.png"),
                         "流体/固体/仿真设置")
       
        #  Add 流体前处理 page
        #self.pages[WorkingMode.LiuQianchuliMode] = Q.QWidget(self.main)
        #self.main.addTab(self.pages[WorkingMode.LiuQianchuliMode],
        #                 load_icon("fluidwave.png"),
        #                 "流体前处理")

        #  Add 计算监控(旧版本) page
        self.pages[WorkingMode.KongzhiMode] = Q.QWidget(self.main)
        self.main.addTab(self.pages[WorkingMode.KongzhiMode],
                         load_icon("terminal-fill.png"),
                         "计算监控面板")
        #self.main.setTabEnabled(WorkingMode.KongzhiMode, False)

        # A.3. Add "Results View" page
        self.pages[WorkingMode.ResultsMode] = Q.QWidget(self.main)
        self.main.addTab(self.pages[WorkingMode.ResultsMode],
                         load_icon("paraview.png"),
                         'Paraview 后处理')

        # 开始设置 "Results" page

        self.results_hboxlayoutnew = Q.QHBoxLayout(self.pages[WorkingMode.ResultsMode])
        self.result01 = Results(astergui,self.pages[WorkingMode.ResultsMode])
        self.result01.init_paraview()
        self.results_hboxlayoutnew.addWidget(self.result01)

        # 参数化建模部分
        self.geom_hboxlayout = Q.QHBoxLayout(self.pages[WorkingMode.JianmoMode])
        # self.geom_split = Q.QSplitter(Q.Qt.Horizontal, self.pages[WorkingMode.JianmoMode])       
        # self.geom_hboxlayout = Q.QHBoxLayout(self.geom_split)
        geom01 = GEOM(self.pages[WorkingMode.JianmoMode])
        self.geom_hboxlayout.addWidget(geom01)
        # geom01.init_geom()

        #欢迎页
        # self.welcomelayout = Q.QHBoxLayout(self.pages[WorkingMode.StartMode])
        # webview = Q.QWebEngineView(self)
        # url = Q.QUrl(QFileInfo("/home/export/online1/SHARE/SALOME-9.4.0-CO7-SRC/webpages/testweb.html").absoluteFilePath())
        # webview.load(url)
        # self.welcomelayout.addWidget(webview)
        # webview.show()

        # ##
        #设置前处理选项卡
        # ##

        v_layout = Q.QVBoxLayout(self.pages[WorkingMode.QianchuliMode])
        v_layout.setContentsMargins(2, 3, 2, 3)
        v_layout.setSpacing(3)

        # 仿照Case分割方式

        # self.banner = Q.QLabel(self.pages[WorkingMode.QianchuliMode])
        # self.banner.setObjectName("read_only_banner")
        # self.banner.setFrameStyle(Q.QLabel.Box | Q.QLabel.Sunken)
        # self.banner.setBackgroundRole(Q.QPalette.ToolTipBase)
        # self.banner.setAutoFillBackground(True)
        # self.banner.setAlignment(Q.Qt.AlignCenter)
        # self.banner.linkActivated.connect(self.editModeActivated)
        # v_layout.addWidget(self.banner)

        # 仿照Case分割方式

        self.Qianchuli_splitter = Q.QSplitter(Q.Qt.Horizontal, self.pages[WorkingMode.QianchuliMode])
        self.Qianchuli_splitter.setChildrenCollapsible(False)
        self.Qianchuli_splitter.setContentsMargins(0, 0, 0, 0)
        v_layout.addWidget(self.Qianchuli_splitter, 10)

        self.Qianchuli_lsplitter = Q.QSplitter(Q.Qt.Vertical, self.Qianchuli_splitter)
        self.Qianchuli_lsplitter.setContentsMargins(0, 0, 0, 0)
        self.Qianchuli_lsplitter.setChildrenCollapsible(False)
        self.Qianchuli_lsplitter.setHandleWidth(5)
        self.Qianchuli_splitter.addWidget(self.Qianchuli_lsplitter)

        #在右侧加入网格显示窗口
        self.panels[Panel.View] = astergui.createMeshView(self.Qianchuli_splitter)
        self.panels[Panel.View].is_on = True

        self.Qianchuli_splitter.addWidget(self.panels[Panel.View])
        self.Qianchuli_splitter.setStretchFactor(self.Qianchuli_splitter.count()-1, 5)

        #设置前处理标签页
        self.Qianchuli = ParameterMeshGroupView(self.panels[Panel.View])
        self.Qianchuli_splitter.addWidget(self.Qianchuli)

        #设置参数标签页
        self.first_hboxlayout = Q.QHBoxLayout(self.pages[WorkingMode.SettingMode])
        self.paratab = MainWindow()
        self.first_hboxlayout.addWidget(self.paratab)

        #设置计算控制选项卡
        self.results_hboxlayout = Q.QHBoxLayout(self.pages[WorkingMode.KongzhiMode])
        # Maincontrol 就是GUi的最外层的一个Class 加入前几个标签的instance 因此其级别实际上是所有标签页中最高
        self.maincontrol = Maincontrol(self.Qianchuli,self.paratab,self.result01)
        self.results_hboxlayout.addWidget(self.maincontrol)

        #设置后处理选项卡
        # self.results_hboxlayout = Q.QHBoxLayout(self.pages[WorkingMode.HouchuliMode])
        # Houchuli01 = Results(astergui,self.pages[WorkingMode.HouchuliMode])
        # self.results_hboxlayout.addWidget(Houchuli01)

        connect(self.main.currentChanged, self.modeChanged)
        # connect(self.main.currentChanged, self._updateBanner)
        connect(self.main.currentChanged, self._selectActiveCase)
        # connect(self.panels[Panel.Edit].editorClosed, self.views[Context.Information].update)

        for view in self.views.values():
            view.setContextMenuPolicy(Q.Qt.CustomContextMenu)
            connect(view.customContextMenuRequested, self._popupMenuRequest)
            if hasattr(view, "itemSelectionChanged"):
                connect(view.itemSelectionChanged, self._selectionChanged)
            if hasattr(view, "itemDoubleClicked"):
                connect(view.itemDoubleClicked, self._itemActivated)
            if hasattr(view, "itemChanged"):
                connect(view.itemChanged, self._itemChanged)
            if hasattr(view, "entityChanged"):
                connect(view.entityChanged, self.itemChanged)

        for win in self._windows():
            win.installEventFilter(self)

        self.setFocusPolicy(Q.Qt.StrongFocus)
        self.activate(False)


    def activate(self, enable):
        """
        Activate/deactivate workspace.

        Arguments:
            enable (bool): *True* to activate, *False* to deactivate.
        """
        self.main.setVisible(enable)

    def workingMode(self):
        """
        Get current working mode.

        Returns:
            int: Working mode (see `WorkingMode`).
        """
        return self.main.currentIndex()

    def setWorkingMode(self, mode):
        """
        Set current working mode.

        Arguments:
            mode (int): Working mode (see `WorkingMode`).
        """
        self.main.setCurrentIndex(mode)

    def setTabPosition(self, tab_position):
        """
        Set tab pages position.

        Arguments:
            tab_position (QTabWidget.TabPosition): Tab pages position.
        """
        self.main.setTabPosition(tab_position)

    def view(self, context):
        """
        Get view window.

        Arguments:
            context (int): View type (see `Context`).

        Returns:
            QWidget: View window.
        """
        return self.views.get(context)

    def isViewAvailable(self, context):
        """
        Check if given view is available in current working mode.

        Arguments:
            context (int): View type (see `Context`).

        Returns:
            bool: *True* if view is available in current working mode;
            *False* otherwise.
        """
        return

    def panel(self, panel):
        """
        Get panel.

        Arguments:
            panel (int): Panel type (see `Panel`).

        Returns:
            QWidget: Panel.
        """
        return self.panels.get(panel)

    def saveState(self):
        """
        Save state of workspace's layout.

        Returns:
            str: String representation of layout state, suitable for storage in
            preference file.
        """
        history_hdata = self.history_splitter.saveState().toBase64()
        history_ldata = self.history_lsplitter.saveState().toBase64()
        case_hdata = self.case_splitter.saveState().toBase64()
        case_ldata = self.case_lsplitter.saveState().toBase64()
        case_cdata = self.panels[Panel.View].saveState().toBase64()
        data = []
        fmt_string = '{}={}'
        data.append(fmt_string.format('version', __workspace__version__))
        data.append(fmt_string.format('history_hdata', history_hdata))
        data.append(fmt_string.format('history_ldata', history_ldata))
        data.append(fmt_string.format('case_hdata', case_hdata))
        data.append(fmt_string.format("case_ldata", case_ldata))
        data.append(fmt_string.format("case_cdata", case_cdata))
        return Q.QByteArray(';'.join(data).encode())

    def restoreState(self, state):
        """
        Restore state of workspace's layout.

        Arguments:
            state (str): String representation of layout state.
        """
        if not state:
            return
        state = state.split(';')
        data = {}
        for item in state:
            value = item.split('=')
            if len(value) > 1:
                data[str(value[0])] = value[1]
        if 'history_hdata' in data:
            self.history_splitter.restoreState(Q.QByteArray.fromBase64(data['history_hdata']))
        if 'history_ldata' in data:
            self.history_lsplitter.restoreState(Q.QByteArray.fromBase64(data['history_ldata']))
        if 'case_hdata' in data:
            self.case_splitter.restoreState(Q.QByteArray.fromBase64(data['case_hdata']))
        if 'case_vdata' in data:
            self.case_lsplitter.restoreState(Q.QByteArray.fromBase64(data['case_vdata']))
        if 'case_ldata' in data:
            self.case_lsplitter.restoreState(Q.QByteArray.fromBase64(data['case_ldata']))
        if 'case_cdata' in data:
            self.panels[Panel.View].restoreState(Q.QByteArray.fromBase64(data['case_cdata']))

    def ensureVisible(self, context, entity, select=False):
        """
        Make the entity visible in the given widget.

        Arguments:
            context (int): Selection context (see `Context`).
            entity (Entity): Selection entity.
            select (Optional[bool]): Flag pointing that item should be
                also selected. Defaults to *False*.
        """
        view = self.view(context)
        if view is None:
            return
        # if context in (Context.Cases, Context.Dashboard):
        #     self.setWorkingMode(WorkingMode.HistoryMode)
        else:
            #self.setWorkingMode(WorkingMode.CaseMode)
            #进入时的默认页面改为QianchuliMode
            self.setWorkingMode(WorkingMode.QianchuliMode)
        view.setFocus()
        # if context == Context.DataSettings:
        #     view.ensureVisible(entity, select)
        # elif context == Context.Cases:
        #     view.ensureVisible(entity, select)
        # elif context == Context.Dashboard:
        #     view.ensureVisible(entity, select)

    def updateViews(self):
        """Update views."""
        if self.astergui.study() is not None:
            # Update Read-only banner
            self._updateBanner()

    def meshViewEnabled(self):
        """
        Check if mesh view is enabled.

        Returns:
            bool: *True* if mesh view is enabled; *False* otherwise.
        """
        return self.panels[Panel.View].is_on

    def setMeshViewEnabled(self, is_on):
        """
        Enable / disable mesh view.

        Arguments:
            is_on (bool): *True* to enable mesh view; *False* to disable it.
        """
        self.panels[Panel.View].setVisible(is_on)
        self.panels[Panel.View].is_on = is_on
        self.astergui.update(actions_only=True)

    # pragma pylint: disable=unused-argument
    def eventFilter(self, obj, event):
        """
        Detect the view and panels hiding event.
        """
        if event.type() in (Q.QEvent.Hide, Q.QEvent.HideToParent,
                            Q.QEvent.Show, Q.QEvent.ShowToParent):
            self._transferFocus()
        return False

    @Q.pyqtSlot("QPoint")
    def _popupMenuRequest(self, pos):
        """
        Called when child widget requests context popup menu.

        Emit `popupMenuRequest(Entity, QPoint)` signal.

        Arguments:
            pos (QPoint): Mouse cursor position.
        """
        sender = self.sender()
        sender.setFocus()
        self.popupMenuRequest.emit(self._context(sender), pos)

    @Q.pyqtSlot(Entity, str)
    def _itemChanged(self, entity, text):
        """
        Called when data item is changed.

        Emit `itemChanged(Entity, str)` signal.

        Arguments:
            item (QTreeWidgetItem): Widget item.
            column (int): Item's column.
        """
        sender = self.sender()
        self.itemChanged.emit(entity, text, self._context(sender))

    @Q.pyqtSlot(Entity)
    def _itemActivated(self, entity):
        """
        Called when data item is activated.

        Emit `itemActivated(Entity)` signal.

        Arguments:
            entity (Entity): Data item being activated.
        """
        sender = self.sender()
        self.itemActivated.emit(entity, self._context(sender))

    @Q.pyqtSlot()
    def _selectionChanged(self):
        """
        Called when selection is changed in a child widget.

        Emits `selectionChanged(int)` signal.
        """
        sender = self.sender()
        self.selectionChanged.emit(self._context(sender))

    @Q.pyqtSlot(int)
    def _selectActiveCase(self, mode):
        """
        Is called when Working mode is changed.
        Selects current case item if nothing was selected before.
        """
        # context = None
        # if mode == WorkingMode.CaseMode:
        #     context = Context.DataSettings
        # elif mode == WorkingMode.HistoryMode:
        #     context = Context.Cases

        # if context is not None and not self.selected(context):
        #     self.ensureVisible(context, self.astergui.study().activeCase,
        #                        True)
        pass

    def _windows(self):
        """Returns all views and panels."""
        return chain(self.views.values(), self.panels.values())

    def _transferFocus(self):
        """Move the focus to one of the visible windows."""
        focuswin = None
        curfocus = self.focusWidget()
        win_list = self._windows()
        if curfocus is not None:
            for win in win_list:
                if is_child(curfocus, win):
                    focuswin = win
                    break
            if focuswin is not None and not focuswin.isVisible():
                focuswin = None

        if focuswin is None:
            for win in win_list:
                if win.isVisible():
                    focuswin = win
                    break

            if focuswin is not None:
                focuswin.setFocus()

    def _context(self, widget):
        """
        Get context from widget.

        Arguments:
            widget (QWidget): Workspace's child widget.

        Returns:
            int: Widget's context (see `Context`).
        """
        for context, view in self.views.items():
            if view is widget:
                return context
        return Context.Unknown

    @Q.pyqtSlot(int)
    def _updateBanner(self):
        return
        """
        Update Read-only banner
        """
        txt = translate("AsterStudy",
                        "Read-only (click here to switch back to edit {})")
        case_name = self.astergui.study().history.current_case.name \
            if self.astergui.study() is not None else "<none>"
        txt = txt.format(case_name)
        txt = font(txt, color="red")
        txt = wrap_html(txt, "b")
        txt = wrap_html(txt, "a", href="to_edit_mode")
        txt = wrap_html(txt, "pre")
        self.banner.setText(txt)

