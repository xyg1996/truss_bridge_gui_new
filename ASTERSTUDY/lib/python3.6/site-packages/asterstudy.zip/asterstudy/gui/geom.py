import os
from PyQt5 import Qt as Q
from .t_shape.t_shape_dialog import TShapeDialog

class GEOM(Q.QWidget):
    """Class that controls the behavior of the GEOM tab of the
     application."""
    def __init__(self,parent=None):
        Q.QWidget.__init__(self)
        # self.parent = parent

        """
        Initializes, if necessary, geom and creates a dedicated 
        view in the tab.
        """
        from .salomegui import (get_salome_pyqt, get_salome_gui)

        self._occ_viewer = get_salome_pyqt().createView('OCCViewer', True, 0, 0, True)
        view = get_salome_pyqt().getViewWidget(self._occ_viewer)

        hlayout = Q.QHBoxLayout(self)
        self.geom_splitter = Q.QSplitter(Q.Qt.Horizontal, self)
        self.geom_splitter.setSizePolicy(Q.QSizePolicy.Expanding,
                                        Q.QSizePolicy.Expanding)
        hlayout.addWidget(self.geom_splitter)

        side_container = Q.QSplitter(Q.Qt.Vertical, self)
        side_container.setMaximumWidth(220)
        side_container.setSizePolicy(Q.QSizePolicy.MinimumExpanding,
                                     Q.QSizePolicy.Expanding)

        self.filename_label = Q.QLabel('参数化建模示例1')
        # self.loadbutton = Q.QPushButton('载入后处理结果')
        self.TShape = TShapeDialog(self._occ_viewer)

        side_container.addWidget(self.filename_label)
        # side_container.addWidget(self.loadbutton)
        side_container.addWidget(self.TShape)
        self.geom_splitter.addWidget(side_container)

        self.geom_splitter.addWidget(view)
        view.setVisible(True)

        


