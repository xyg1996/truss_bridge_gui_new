# 前处理控制窗口包含下列部分：
# 模型/网格准备
# 按照1/2/3维自动分组的树状图
# 固体+流体边界条件设置

import json
from collections import OrderedDict

import numpy
from PyQt5 import Qt as Q

from . import ActionType, clipboard_text
from ..common import (MeshElemType, MeshGroupType, common_filters, connect,
#                       debug_mode, get_cmd_groups, get_cmd_mesh, get_file_name,
#                       重新定义 get_cmd_groups, get_cmd_mesh
                       debug_mode, get_file_name,get_medfile_meshes,get_medfile_groups,get_medfile_groups_by_type,
                       is_child, is_medfile, is_reference, is_subclass,
                       is_valid_group_name, load_icon, translate)

from .guodu import BackgroundLoading
from .AddPoint import Ui_AddPoint
from .behavior import behavior
from ..assistant.widgets import GroupsButton,GroupSelectionDialog

import os.path
import time
from pathlib import Path

class ParameterMeshGroupView(Q.QWidget):
    """Top-level table editor item."""
    #生成前处理选项窗口

    meshFileChanged = Q.pyqtSignal(str, str, float, bool)
    meshGroupCheck = Q.pyqtSignal(str, str, str, int)
    meshGroupUnCheck = Q.pyqtSignal(str, str, str, int)
    meshChanged = Q.pyqtSignal()
    meshGroupCheckColor = Q.pyqtSignal(str, str, str, int,list)
    """Signal: emitted when mesh is changed in the combo box."""

    ShowNormals = 0
    FitSelection = 1
    SelectGroups = 2

    def __init__(self,input):
        super().__init__()
        # self.popout01 = None
        # self.ops = {}
        self.meshview = input
        self.lastpath = ''
        self.minmax6 = None
        self.thick = False
        # self.allgroups = []

        self.alllayout = Q.QVBoxLayout(self)
        self.toplayout = Q.QGridLayout()
        self.midlayout = Q.QVBoxLayout()
        self.downlayout = Q.QVBoxLayout()

        self.alllayout.addLayout(self.toplayout)
        self.alllayout.addLayout(self.midlayout)
        self.alllayout.addLayout(self.downlayout)

        self._mesh = Q.QComboBox(self)
        self._mesh.setObjectName("MESH")
        self._mesh.setMinimumWidth(280)

        self._toolbar = Q.QToolBar(self)
        self._toolbar.setToolButtonStyle(Q.Qt.ToolButtonIconOnly)
        self._toolbar.setObjectName("MeshGroupToolbar")

        # self._toolbar.addAction(self.ops[ParameterMeshGroupView.ShowNormals])
        # self._toolbar.addAction(self.ops[ParameterMeshGroupView.FitSelection])
        # self._toolbar.addAction(self.ops[ParameterMeshGroupView.SelectGroups])

        self._msg = Q.QLabel(self)

        self._invalid_groups = []

        #增加上传网格按钮
        self.btuploadsolidmesh = Q.QPushButton('上传模型(后台自动分组，生成网格)',self)
        self.btuploadsolidmesh.setIcon(load_icon('cloudupload.png'))
        #定义新的[] 替换旧的meshlist
        self.meshlistdai=[]

        self.columns = OrderedDict()

        button_add = Q.QPushButton('增加一组固体边界条件')
        button_add.setIcon(load_icon('add_row.png'))
        #button_add.setObjectName('button_add')
        #button_add.setMaximumWidth(30)

        button_remove = Q.QPushButton('删除选定的行')
        button_remove.setIcon(load_icon('delete_row.png'))
        #button_remove.setObjectName('button_remove')
        #button_remove.setMaximumWidth(30)

        #self.label = Q.QLabel(self)
        #self.label.setObjectName('label')

        # 观察点表格
        self.Monitortable = Q.QTableWidget(self)

        self.Monitortable.setColumnCount(4)   ##设置列数
        header = ['观察点名','X','Y','Z',]
        self.Monitortable.setHorizontalHeaderLabels(header)
        self.Monitortable.horizontalHeader().setSectionResizeMode(Q.QHeaderView.Stretch)
        self.Monitortable.horizontalHeader().setStretchLastSection(True)
        self.Monitortable.setMinimumWidth(280)
        self.Monitortable.setMinimumHeight(50)
    

        # 固体边界条件表格
        self.table = Q.QTableWidget(self)
        self.table.setObjectName('control')
        #self.table.verticalHeader().hide()
        #self.table.setSelectionMode(Q.QAbstractItemView.SingleSelection)

        self.table.setColumnCount(4)   ##设置列数
        self.headers = ['分组选择','DX','DY','DZ',]
        self.table.setHorizontalHeaderLabels(self.headers)
        self.table.horizontalHeader().setSectionResizeMode(Q.QHeaderView.Stretch)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setMinimumWidth(280)
        #self.table.setSectionResizeMode(Q.QHeaderView.ResizeToContents)
        #self.table.setStretchLastSection(True)
        self.table.setMinimumHeight(50)
        # self.table.setMaximumHeight(200)

        # 流体边界条件表格
        self.fluidtable = Q.QTableWidget(self)
        self.fluidtable.setColumnCount(4)   ##设置列数
        fluid4 = ['封头frontwall','封头backwall','容器壁wall','防波板bafflewall',]
        self.fluidtable.setHorizontalHeaderLabels(fluid4)
        self.fluidtable.horizontalHeader().hide()
        # self.fluidtable.setMaximumHeight(160)
        self.fluidtable.horizontalHeader().setSectionResizeMode(Q.QHeaderView.Stretch)
        self.fluidtable.horizontalHeader().setStretchLastSection(True)
        self.fluidtable.verticalHeader().setSectionResizeMode(Q.QHeaderView.Stretch)
        self.fluidtable.verticalHeader().setStretchLastSection(True)
                
        self.fluidtable.setRowCount(1)
        # a = Q.QCheckBox('封头1(红色)')
        # b = Q.QCheckBox('封头2(蓝色)')
        # c = Q.QCheckBox('容器壁(绿色)')
        # d = Q.QCheckBox('防波板(黄色)')
        a = Q.QRadioButton('封头1(红色)')
        b = Q.QRadioButton('封头2(蓝色)')
        c = Q.QRadioButton('容器壁(绿色)')
        d = Q.QRadioButton('防波板(黄色)')

        self.fluidtable.setCellWidget(0,0,a)
        self.fluidtable.setCellWidget(0,1,b)
        self.fluidtable.setCellWidget(0,2,c)
        self.fluidtable.setCellWidget(0,3,d)

        # a.stateChanged.connect(lambda: self.changecolor([1,0,0.498039],0))
        # b.stateChanged.connect(lambda: self.changecolor([0,0.333333,1],1))
        # c.stateChanged.connect(lambda: self.changecolor([0,1,0.333333],2))
        # d.stateChanged.connect(lambda: self.changecolor([1,1,0],3))
        a.clicked.connect(lambda: self.changecolor([1,0,0.498039],0))
        b.clicked.connect(lambda: self.changecolor([0,0.333333,1],1))
        c.clicked.connect(lambda: self.changecolor([0,1,0.333333],2))
        d.clicked.connect(lambda: self.changecolor([1,1,0],3))

        fluidbuttons = {}
        for i in range(len(fluid4)):
            fluidbuttons[fluid4[i]] = GroupsButton(self)
            fluidbuttons[fluid4[i]].value = ''
            self.fluidtable.setRowCount(2)
            self.fluidtable.setCellWidget(1,i,fluidbuttons[fluid4[i]])
            connect(fluidbuttons[fluid4[i]].clicked, self._selectGroupsEdit)

        if not self.thick:    
            for i in range(len(fluid4)):
                self.fluidtable.setRowCount(3)
                self.fluidtable.setItem(2,i,Q.QTableWidgetItem('').setTextAlignment(Q.Qt.AlignHCenter))
                #self.fluidtable.setItem(1,i,Q.QTableWidgetItem(''))

        self.fluidtable.setVerticalHeaderLabels(['高亮显示','选择分组','厚度(m)'])
        #self.fluidtable.setVertical

        #self.setLayout(Q.QGridLayout())
        #self.layout().setContentsMargins(0, 0, 0, 0)
        #self.layout().setSpacing(5)
        #self.layout().addWidget(button_add, 0, 0)
        #self.layout().addWidget(button_remove, 0, 1)
        #self.layout().addWidget(self.label, 0, 2)
        #self.layout().addWidget(self.table, 1, 0, 1, 3)
        #self.layout().setColumnStretch(2, 1)

        connect(button_add.clicked, self._addRow)
        connect(button_remove.clicked, self._removeSelectedRow)

        self.btqiehuan = Q.QPushButton('切换节点/单元分组',self)
        self.qiehuan = 0

        self.btceshi =  Q.QPushButton('测试信息',self)
        self.btceshi.clicked.connect(self.SolidFixBoundry)
        # self.btceshi.clicked.connect(self.TotalFGroup)
        self.btceshi.hide()

        self.gBoxtop = Q.QGroupBox()
        self.gBoxtop.setTitle("模型/网格准备")
        self.toplayout01 = Q.QGridLayout()
        self.gBoxtop.setLayout(self.toplayout01)
        self.toplayout.addWidget(self.gBoxtop)

        self.actioninter = Q.QPushButton("从视窗中选择", self)
        self.actioninter.setToolTip(translate("AsterStudy",
                                    "Select groups from central view"))
        self.actioninter.setStatusTip(translate("AsterStudy",
                                      "Select groups from central view"))
        self.actioninter.setIcon(load_icon("as_pic_select_groups.png"))
        self.actioninter.setCheckable(True)
        self.actioninter.toggled.connect(self._selectGroups)

        self.actionnormal = Q.QPushButton("显示法向量", self)
        self.actionnormal.setToolTip(translate("AsterStudy",
                                    "Show faces orientation vectors"))
        self.actionnormal.setStatusTip(translate("AsterStudy",
                                      "Show faces orientation vectors"))
        self.actionnormal.setIcon(load_icon("as_pic_show_normals.png"))
        self.actionnormal.setCheckable(True)
        connect(self.actionnormal.toggled, self._showNormals)

        self.actionfit = Q.QPushButton("调整大小", self)
        self.actionfit.setToolTip(translate("AsterStudy", "Fit selection"))
        self.actionfit.setStatusTip(translate("AsterStudy",
                                      "Fit view contents to selected groups"))
        self.actionfit.setIcon(load_icon("as_pic_fit_selection.png"))
        connect(self.actionfit.clicked, self._fitSelection)

        # self.actioninter.hide()
        self.actionnormal.hide()
        self.actionfit.hide()

        self._bgroup = Q.QButtonGroup(self)
        self._gbox = Q.QGroupBox(self)
        self._rbutton = []
        if self._meshGroupType() is MeshGroupType.GElement:
            tlist = MeshElemType.elem_types(MeshGroupType.GElement, True)
            for i, v in enumerate(tlist):
                self._rbutton.append(Q.QRadioButton(MeshElemType.value2str(v)))
                self._bgroup.addButton(self._rbutton[i], i)
            self._rbutton[0].setChecked(True)
        #self._bgroup.hide()
        self._gbox.hide()

        self._toolbar = Q.QToolBar(self)
        self._toolbar.setToolButtonStyle(Q.Qt.ToolButtonIconOnly)
        self._toolbar.setObjectName("MeshGroupToolbar")

        # self._toolbar.addWidget(self.actionnormal)
        # self._toolbar.addWidget(self.actionfit)
        # self._toolbar.addWidget(self.actioninter)
        self._toolbar.hide()

        self.toplayout01.setSpacing(3)
        #self.toplayout01.addStretch(1)
        self.toplayout01.addWidget(self.btuploadsolidmesh,0,0)
        
        #self.toplayout01.addWidget(self.mesh3d,0,2)
        self.toplayout01.addWidget(self.btqiehuan,0,1)
        self.toplayout01.addWidget(self.actioninter,0,2)
        #self.toplayout01.addWidget(self.btceshi,1,1)
        self.toplayout01.addWidget(self._mesh,2,0,1,2)
        self.toplayout01.addWidget(self._msg,2,2)
        
        #self.toplayout01.addWidget(self.actionnormal,3,0)
        #self.toplayout01.addWidget(self.actionfit,3,1)
        #self.toplayout01.addWidget(self.actioninter,3,2)
        #self.toplayout01.addWidget(self._toolbar,3,0)

        self.midlayout.addWidget(self._toolbar)
        # self.midlayout.addWidget(self)

        self.Boxmonitor = Q.QGroupBox()
        self.Boxmonitor.setTitle("观察点设置")
        self.Monitorlayout = Q.QVBoxLayout()
        self.Boxmonitor.setLayout(self.Monitorlayout)
        self.downlayout.addWidget(self.Boxmonitor)

        self.gBoxdown = Q.QGroupBox()
        self.gBoxdown.setTitle("固体边界条件")
        self.downlayout01 = Q.QGridLayout()
        self.gBoxdown.setLayout(self.downlayout01)
        self.downlayout.addWidget(self.gBoxdown)

        self.gBoxbottom = Q.QGroupBox()
        self.gBoxbottom.setTitle("流体边界条件")
        self.bottomlayout = Q.QVBoxLayout()
        self.gBoxbottom.setLayout(self.bottomlayout)
        self.bottomlayout.addWidget(self.gBoxbottom)
        self.downlayout.addWidget(self.gBoxbottom)

        # 固体边界条件
        self.downlayout01.addWidget(button_add,0,0)
        self.downlayout01.addWidget(button_remove,0,1)
        self.downlayout01.addWidget(self.table,1,0,1,2)

        # 观察点设置
        # self.downlayout01.addWidget(button_add,0,0)
        # self.downlayout01.addWidget(button_remove,0,1)
        # Ui_AddPoint

        AddPointWidget = Q.QWidget(self)
        self.addpoint = Ui_AddPoint()
        self.addpoint.setupUi(AddPointWidget)
        AddPointWidget.show()
        self.addpoint.pushButton.clicked.connect(self.addpointsline)
        self.addpoint.pushButton_2.clicked.connect(self.removepointsline)

        # self.Monitorlayout.addWidget(AddPointWidget,0,0)
        # self.Monitorlayout.addWidget(self.Monitortable,1,0,1,2)
        self.Monitorlayout.addWidget(AddPointWidget)
        self.Monitorlayout.addWidget(self.Monitortable)

        # 流体边界条件
        self.bottomlayout.addWidget(self.fluidtable)

        self.btqiehuan.clicked.connect(self._qiehuan)
        #增加上传网格按钮后台功能 1）获取网格文件路径 2）TODO:检测是否需要自动转换网格，是否需要自动分组   
        # 3）刷新上侧列表
        self.btuploadsolidmesh.clicked.connect(self.startmesh)

        connect(self._mesh.activated[int], self._meshActivated)
        self._updateMeshList()

        connect(self.meshFileChanged, self.meshview.displayMEDFileName)
        connect(self.meshGroupCheck, self.meshview.displayMeshGroup)
        connect(self.meshGroupCheckColor, self.meshview.displayMeshGroupcolor)
        connect(self.meshGroupUnCheck, self.meshview.undisplayMeshGroup)
        # connect(self.meshview.selectionChanged, self.updateSelection)
        # connect(self._manual.textChanged, self._manualChanged)

        # connect(self.customContextMenuRequested, self._popupMenuRequest)
        # connect(self.itemChanged, self.meshGroupToChange)

    def changecolor(self,rgb,col):
        #rgb=[rgb0,rgb1,rgb2,]
        meshcmd = self._meshcmd(self._mesh.currentIndex())
        if meshcmd is None:
            return
        file_name, nom_med = self.get_cmd_mesh(meshcmd)
        if file_name is None or nom_med is None:
            return

        #print(file_name,nom_med,self.fluidtable.cellWidget(1,col).value,self._meshGroupType()[0],rgb)
        grtype = MeshGroupType.GElement #if typ in ('groups_ma',) else MeshGroupType.GNode
        all_groups = get_medfile_groups(file_name, None, grtype)
        for var in all_groups:
            self.meshGroupUnCheck.emit(file_name,
                                    nom_med,
                                    var,
                                    self._meshGroupType(),)

        selected = []
        # if self.fluidtable.cellWidget(0,col).checkState() == Q.Qt.Checked:
        for var in self.fluidtable.cellWidget(1,col).value:
            # print(var)
            self.meshGroupCheckColor.emit(file_name,
                                    nom_med,
                                    var,
                                    self._meshGroupType(),
                                    rgb)
            selected.append((file_name,
                                    nom_med,
                                    var,
                                    self._meshGroupType()))

        self.meshview.setSelected(selected)

    def reload(self,filename):
        #读取json文件内容
        with open(filename) as f_obj:
            dic = json.load(f_obj)
        BOUNDARYorigin = dic['BOUNDARYorigin']
        TotalFGroup = dic['TotalFGroup']
        medfilename = Path(filename).parent / Path(dic['medfilename']).name
        stldic = dic['stldic']
        thickdic = dic['thickdic']
        
        #恢复选定网格文件显示
        self.startmesh([str(medfilename)])
        #恢复固体边界条件显示
        self.restoreSolidBoundry(BOUNDARYorigin)
        #恢复流体边界条件显示
        self.restorestldic(stldic)
        #恢复厚度条件显示
        self.restorethickdic(thickdic)
        #恢复观察点表格信息
        allpointsdic = dic['Watchpoints']
        print(allpointsdic)
        self.restoremonpoints(allpointsdic)

    def _qiehuan(self):
        self.qiehuan = 1 - self.qiehuan

    def value(self):
        """Reimplemented from *Control*."""
        values = []
        for row in range(self.table.rowCount()):
            columns = self.columns.keys()
            for index, column in enumerate(columns):
                attributes = self.columns[column]
                value = str2value(self._itemValue(row, index), attributes)
                if value is not None:
                    values.append(value)
        return tuple(values)

    def isEmpty(self):
        """Reimplemented from *Control*."""
        return not self.table.rowCount()

    def validate(self):
        """Reimplemented from *Control*."""
        rule = self.attribute('rule')
        for row in range(self.table.rowCount()):
            values = {}
            columns = self.columns.keys()
            for index, column in enumerate(columns):
                value = self._itemValue(row, index)
                values[column] = value or None
            if rule:
                exec('valid = {}'.format(rule.format(**values)), globals(), locals()) # pragma pylint: disable=exec-used
                if not locals().get('valid'):
                    return False
            else:
                if [i for i in values.values() if not i]:
                    return False
        return True

    def addpointsline(self):
        row = self.Monitortable.rowCount()
        self.Monitortable.setRowCount(row + 1)
        # self.Monitortable.setCellWidget(row,0,button)
        xcord = self.addpoint.lineEdit.text()
        ycord = self.addpoint.lineEdit_2.text()
        zcord = self.addpoint.lineEdit_3.text()
        pointname = self.addpoint.lineEdit_4.text()
        self.Monitortable.setItem(row,0,Q.QTableWidgetItem(pointname))
        self.Monitortable.setItem(row,1,Q.QTableWidgetItem(xcord))
        self.Monitortable.setItem(row,2,Q.QTableWidgetItem(ycord))
        self.Monitortable.setItem(row,3,Q.QTableWidgetItem(zcord))
        # import SMESH, SALOMEDS
        # from salome.smesh import smeshBuilder
        
    def removepointsline(self):
        """Remove selected row(s)."""
        selected = self.Monitortable.selectedItems()
        rows = sorted(set([i.row() for i in selected] + [self.Monitortable.currentRow()]), reverse=True)
        for row in rows:
            self.Monitortable.removeRow(row)

    def getallmonpoints(self):
        allmonpointsdic = {}
        for i in range(self.Monitortable.rowCount()):
            # allmonpointsdic[stlnames[i]] = self.fluidtable.item(2,i).text()
            pointname = self.Monitortable.item(i,0).text()
            cord = [self.Monitortable.item(i,1).text(),self.Monitortable.item(i,2).text(),self.Monitortable.item(i,3).text()]
            allmonpointsdic[pointname] = cord
        
        return allmonpointsdic

    def restoremonpoints(self,allpointsdic):
        # self.Monitortable.clear()
        # 避免清除header改用clearContents
        self.Monitortable.clearContents()
        for i,key in enumerate(allpointsdic):
            self.Monitortable.setRowCount(i + 1)
            self.Monitortable.setItem(i,0,Q.QTableWidgetItem(key))
            for j,cord in enumerate(allpointsdic[key]):
                # print(j,cord)
                self.Monitortable.setItem(i,j+1,Q.QTableWidgetItem(cord))

    @Q.pyqtSlot()
    def _addRow(self):
        """Insert new row to table."""
        row = self.table.rowCount()
        #row = row + 1
        #self.table.insertRow(row)
        #self.table.insertRow(row+1)
        button = GroupsButton(self)
        button.mesh = self.mesh()
        button.typ = "groups_no"#attributes.get('typ')
        #button.value = default_value(attributes)
        button.value = ""
        connect(button.clicked, self._selectGroupsEdit)
        self.table.setRowCount(row + 1)
        self.table.setCellWidget(row,0,button)
        ckbox1=Q.QCheckBox()
        ckbox2=Q.QCheckBox()
        ckbox3=Q.QCheckBox()
        #self.table.setItem(row,1,setCellWidget(ckbox))
        #self.table.setItem(row,2,setCellWidget(ckbox))
        #self.table.setItem(row,3,setCellWidget(ckbox))
        self.table.setCellWidget(row,1,ckbox1)
        self.table.setCellWidget(row,2,ckbox2)
        self.table.setCellWidget(row,3,ckbox3)

        # columns = self.columns.keys()
        # for index, column in enumerate(columns):
        #     attributes = self.columns[column]
        #     if attributes.get('typ') in ('groups_ma', 'groups_no'):
        #         button = GroupsButton(self)
        #         button.mesh = attributes.get('mesh')
        #         button.typ = attributes.get('typ')
        #         button.value = default_value(attributes)
        #         connect(button.clicked, self._selectGroups)
        #         self.table.setCellWidget(row, index, button)
        #         self.table.setItem(0,0,QTableWidgetItem("input"))

        #     else:
        #         item = Q.QTableWidgetItem()
        #         item.setText(default_value(attributes))
        #         self.table.setItem(row, index, item)

    @Q.pyqtSlot()
    def _removeSelectedRow(self):
        """Remove selected row(s)."""
        selected = self.table.selectedItems()
        rows = sorted(set([i.row() for i in selected] + [self.table.currentRow()]), reverse=True)
        for row in rows:
            self.table.removeRow(row)

    @Q.pyqtSlot()
    def _selectGroupsEdit(self):
        """Open dialog to choose mesh groups."""
        button = self.sender()
        groups = button.value
        
        # print(groups)
        file_name = self._meshcmd(self._mesh.currentIndex())
        grtype = MeshGroupType.GElement #if typ in ('groups_ma',) else MeshGroupType.GNode
        all_groups = get_medfile_groups(file_name, None, grtype)

        #print('all_groups',all_groups)
        if all_groups:
            # 改进分组选择对话框
            mesh=self._meshcmd(self._mesh.currentIndex())
            dlg = Grouptreeview(meshview=self.meshview,meshcmd=mesh,selected=groups)
            dlg.exec_()
            button.value = dlg.selectedMeshGroups()

    def _itemValue(self, row, column):
        """Get item value."""
        if self.table.cellWidget(row, column) is not None:
            return getattr(self.table.cellWidget(row, column), 'value')
        return self.table.item(row, column).text().strip()

    def startmesh(self,fname=None):
        filter = "模型文件(*.igs *.iges *.brep *.step *.stl);;网格文件(*.med);;全部(*.*)"
        if not fname:
            fname = Q.QFileDialog.getOpenFileName(self, '打开模型/网格文件',self.lastpath,filter)
            print(fname)

        if len(fname)>2:
            Q.QMessageBox.information(self, '错误', '目前只能上传单个模型/网格！')
        if fname[0]:
            self.lastpath = os.path.dirname(fname[0])
            #for eachf in fname[0:-1]:
            extension = os.path.splitext(fname[0])[1]
            if extension == ".med":
                #将.append改成放在最前面 2019/12/04
                self.meshlistdai = [fname[0]]+self.meshlistdai
                self._updateMeshList()
            elif extension in [".igs",".iges",".brep",".step",".stl",]:#extension == ".igs" or extension == ".iges": 
                #self.automesh(fname[0])
                #self.meshlistdai.append(self.automesh(fname[0]))
                #将.append改成放在最前面 2019/12/04
                self.meshlistdai = [self.automesh(fname[0])]+self.meshlistdai
                self._updateMeshList()
            else:
                Q.QMessageBox.information(self, '错误', '目前不支持'+fname[0]+"格式！")

    def automesh(self,file):
        import GEOM
        from salome.geom import geomBuilder
        import math
        import SALOMEDS    
        originpath = os.path.splitext(file)[0]
        extension = os.path.splitext(file)[1]
        geompy = geomBuilder.New()
        if extension == ".igs" or extension == ".iges": 
            geosource = geompy.ImportIGES(originpath+extension)
        elif extension == ".brep": 
            geosource = geompy.ImportBREP(originpath+extension)
        elif extension == ".step": 
            geosource = geompy.ImportSTEP(originpath+extension)
        elif extension == ".stl": 
            geosource = geompy.ImportSTL(originpath+extension)

        facesgroups = geompy.ExtractShapes(geosource, geompy.ShapeType["FACE"], True)
        
        #改为使用Q.QDialog来从用户交互获取 
        dlg = askSetSizeFactor()
        # if dlg.exec_():
        #     SizeFactor = dlg.SizeFactor
        dlg.exec_()

        if dlg.SizeFactor:
            self.loader1 = BackgroundLoading(self,msg='正在生成网格,请稍候...')
            self.loader1.start()

            if dlg.mesh2d.isChecked():
                getshapetype = "FACE"
            elif dlg.mesh3d.isChecked():
                getshapetype = "SOLID"

            Partition_1 = geompy.MakePartition([geosource], facesgroups, [], [], geompy.ShapeType[getshapetype], 0, [], 0)
            facesgroups = geompy.ExtractShapes(Partition_1, geompy.ShapeType["FACE"], True)

            import  SMESH, SALOMEDS
            from salome.smesh import smeshBuilder
            smesh = smeshBuilder.New()
            Mesh_1 = smesh.Mesh(Partition_1)
            #GMSH_2D = Mesh_1.Triangle(algo=smeshBuilder.GMSH_2D)
            if dlg.mesh2d.isChecked():
                GMSH_2D = Mesh_1.Triangle(algo=smeshBuilder.GMSH_2D)
                Gmsh_Parameters = GMSH_2D.Parameters()
                #Gmsh_Parameters.SetIs2d( 1 )
                #Gmsh_Parameters.SetIs2d( 0 )
        
            elif dlg.mesh3d.isChecked():
                GMSH = Mesh_1.Tetrahedron(algo=smeshBuilder.GMSH)
                Gmsh_Parameters = GMSH.Parameters()

            Gmsh_Parameters.Set2DAlgo( 0 )
            Gmsh_Parameters.SetMinSize( 0 )
            Gmsh_Parameters.SetMaxSize( 1000 )
            Gmsh_Parameters.SetSizeFactor(dlg.SizeFactor)
            if dlg.check2nd.isChecked():
                Gmsh_Parameters.SetSecondOrder( 1 )
            Gmsh_Parameters.SetIs2d( 0 )
            isDone = Mesh_1.Compute()

            mednodegroups={}
            medfacegroups={}
            indexmed=0
            for face in facesgroups:
                mednodegroups["face"+str(indexmed)] = Mesh_1.GroupOnGeom(face,"face"+str(indexmed),SMESH.NODE)
                medfacegroups["face"+str(indexmed)] = Mesh_1.GroupOnGeom(face,"face"+str(indexmed),SMESH.FACE)
                indexmed=indexmed+1
            print(mednodegroups)
            print(medfacegroups)

            try:
                timestamp = str(time.strftime('-%H-%M-%S'))
                Mesh_1.ExportMED(originpath+timestamp+".med",auto_groups=1,autoDimension=1)
                Mesh_1.ExportUNV(originpath+timestamp+".unv")
                # Mesh_1.ExportMED(originpath+timestamp+".med",auto_groups=1,autoDimension=1)
                #self.minmax6 = Mesh_1.BoundingBox()
                #print('self.minmax6',self.minmax6)
                print("time.strftime('%H-%M-%S'):",time.strftime('%H-%M-%S'))
            except:
                print('ExportMED() failed. Invalid file name?')
            
            ## Set names of Mesh objects
            #smesh.SetName(GMSH_2D.GetAlgorithm(), 'GMSH_2D')
            if dlg.mesh2d.isChecked():
                smesh.SetName(GMSH_2D.GetAlgorithm(), 'GMSH_2D')
                smesh.SetName(Gmsh_Parameters, 'Gmsh Parameters')
                smesh.SetName(Mesh_1.GetMesh(), 'Mesh_1')
            elif dlg.mesh3d.isChecked():
                smesh.SetName(GMSH.GetAlgorithm(), 'GMSH')
                smesh.SetName(Gmsh_Parameters, 'Gmsh Parameters')
                smesh.SetName(Mesh_1.GetMesh(), 'Mesh_1')
            
            self.loader1.terminate()

            return originpath+timestamp+".med"

            

    # def meshview(self):
    #     """
    #     Returns central view where mesh and groups should be displayed
    #     """
    #     #return self.meshview
    #     return self.input

    def meshList(self):
        """
        Gets the mesh commands list

        Returns:
            list (Command): List of commands with meshes.
        """
        mlist = []
        for i in range(self._mesh.count()):
            mlist.append(self._mesh.itemData(i).name)
        return mlist

    def setMeshList(self, meshlist):
        """
        Sets the mesh commands list

        Arguments:
            meshlist: List of commands with meshes.
        """
        self._mesh.clear()
        show_title = behavior().show_catalogue_name_in_selectors
        title_mask = '{n} ({t})' if show_title else '{n}'
        for meshcmd in meshlist:
            #title = title_mask.format(n=meshcmd.name, t=meshcmd.title)
            #self._mesh.addItem(title, meshcmd)
            self._mesh.addItem(meshcmd, meshcmd)

    def mesh(self):
        """
        Gets the currently selected mesh command object or None in error case.

        Returns:
            Command: Current mesh command object.
        """
        idx = self._mesh.currentIndex()
        return self._mesh.itemData(idx) if idx >= 0 else None

    def setMesh(self, mesh):
        """
        Sets the current mesh command object if it exists in the list.

        Arguments:
            mesh: Current mesh command object.
        """
        self._mesh.setCurrentIndex(self._mesh.findData(mesh))

    def message(self):
        """
        Gets the info message text.

        Returns:
            str: info message text.
        """
        return self._msg.text()

    def setMessage(self, msg):
        """
        Sets the info message text.

        Arguments:
            msg (str): info message text.
        """
        self._msg.setText(msg)
        #self._msg.setVisible(len(msg) > 0)

    def restoreTotalF(self,TotalForce):
        pass

    def restoreSolidBoundry(self,BOUNDARYorigin):
        #self.table.clear()
        self.table.setRowCount(0)
        for i,key in enumerate(BOUNDARYorigin):
            self._addRow()
            self.table.cellWidget(i,0).value = key[2:-2].split("', '")
            for j in BOUNDARYorigin[key]:
                self.table.cellWidget(i,j).setCheckState(Q.Qt.Checked)


    def restorestldic(self,stldic):
        for i,key in enumerate(stldic):
            self.fluidtable.cellWidget(1,i).value = stldic[key]

    def restorethickdic(self,thickdic):
        for i,key in enumerate(thickdic):
            #self.fluidtable.item(2,i).text = thickdic[key]
            #self.fluidtable.item(2,i).setText(thickdic[key])
            self.fluidtable.setRowCount(3)
            item = Q.QTableWidgetItem()
            item.setText(str(thickdic[key]))
            self.fluidtable.setItem(2,i,item)

    #收集需要统计合力的分组 返回值TotalForce字符串列表
    def TotalFGroup(self):
        return []
    
    # def TotalFGroup(self):
    #     TotalForce = []
    #     for i in range(self.topLevelItemCount()):
    #         item = self.topLevelItem(i)
    #         for j in range(item.childCount()):
    #             sub_item = item.child(j)
    #             if sub_item.checkState(0) == Q.Qt.Checked or \
    #                     sub_item.isSelected():
    #                 TotalForce.append(sub_item.text(0))
    #     print("需要统计合力的分组是：",TotalForce)
    #     return TotalForce

    #收集固体边界条件分组的信息
    def SolidFixBoundry(self):
        BOUNDARY = {}
        BOUNDARYorigin = {}
        Compound_Mesh = {}
        for row in range(self.table.rowCount()):
            fixed = []
            for col in range(1,len(self.headers)):
                if self.table.cellWidget(row,col).checkState() == Q.Qt.Checked:
                    fixed.append(col)
            for key in self.table.cellWidget(row,0).value:
                BOUNDARY[key] = fixed
            BOUNDARYorigin[str(tuple(self.table.cellWidget(row,0).value))] = fixed

        print("BOUNDARY = ",BOUNDARY)
        print("BOUNDARYorigin = ",BOUNDARYorigin)
        return BOUNDARY,BOUNDARYorigin

    #在Fluid/triSurface路径下生成4个stl网格gen
    def genstlwall(self,despath):
        stldic = {}
        stlnames = ['front_wall','back_wall','tank_wall','baffle_wall',]
        for i in range(len(stlnames)):
            print(self.fluidtable.cellWidget(1,i).value)
            if self.fluidtable.cellWidget(1,i).value:
                stldic[stlnames[i]] = self.fluidtable.cellWidget(1,i).value
            
                meshcmd=self.meshlistdai[0]
                file_name, nom_med = self.get_cmd_mesh(meshcmd)
                des = os.path.join(despath,'Fluid','constant','triSurface',stlnames[i]+'.stl')
                self.meshview.exportstl(file_name,nom_med,des,stldic[stlnames[i]],stlnames[i])
                print(des+'generated')
        print(str(stldic)+'stldic')
        return stldic

    #返回['front_wall','back_wall','tank_wall','baffle_wall',]对应的厚度
    def getthick(self):
        stlnames = ['front_wall','back_wall','tank_wall','baffle_wall',]
        thickdic = {}
        for i in range(len(stlnames)):
            print(self.fluidtable.cellWidget(1,i).value)
            if self.fluidtable.cellWidget(1,i).value:
                thickdic[stlnames[i]] = self.fluidtable.item(2,i).text()
        print(str(thickdic)+'thickdic')
        return thickdic


    def meshGroupToChange(self, item, column):
        """
        Called when mesh group item is checked ON/OFF.

        Emits `meshGroupCheck()` or `meshGroupUnCheck()` signal
        to display/undisplay given group in a mesh view.
        """
        if behavior().mesh_view_handle_selection:
            self.meshGroupSelected()
            return
        meshcmd = self._meshcmd(self._mesh.currentIndex())
        if meshcmd is not None:
            file_name, nom_med = self.get_cmd_mesh(meshcmd)
            if file_name is not None and nom_med is not None:
                #if not self.ops[self.SelectGroups].isChecked():
                if not self.actioninter.isChecked():
                    if item.checkState(column) == Q.Qt.Checked:
                        self.meshGroupCheck.emit(file_name,
                                                 nom_med,
                                                 item.text(0),
                                                 self._meshGroupType())
                    # Do not hide in 'group selection' mode
                    if item.checkState(column) == Q.Qt.Unchecked:
                        self.meshGroupUnCheck.emit(file_name,
                                                   nom_med,
                                                   item.text(0),
                                                   self._meshGroupType())
                #if self.ops[self.SelectGroups].isChecked():
                if self.actioninter.isChecked():
                    index = self._bgroup.checkedId()
                    #tlist = MeshElemType.elem_types(MeshGroupType.GElement,
                    tlist = MeshElemType.elem_types(self._meshGroupType(),
                                                    True)
                    thetype = tlist[index]
                    self.meshview.setSelection(file_name,
                                                 nom_med,
                                                 self.selectedMeshGroups(),
                                                 self._meshGroupType(),
                                                 thetype)
        # if self.filterPanel() is not None:
        #     self.filterPanel().applyFilter()
            
    def _meshcmd(self, index):
        """
        Returns the *Command* instance associated with the panel
        """
        meshcmd = None
        if 0 <= index < self._mesh.count():
            meshcmd = self._mesh.itemData(index)
        return meshcmd

    # def itemValue(self, **kwargs):
    #     """
    #     Get selected values.

    #     Returns:
    #         tuple: List with all selected mesh groups
    #     """
    #     res = tuple(self.selectedMeshGroups() + self.inputMeshGroups())
    #     return res or None

    # def setItemValue(self, values):
    #     """
    #     Set values of child items.

    #     Arguments:
    #         values: Tuple with item values (see `childValues()`).
    #     """
    #     grplist = []
    #     if values is not None:
    #         if isinstance(values, (tuple, list)):
    #             grplist = list(values)
    #         else:
    #             grplist = [values]
    #     self.setSelectedMeshGroups(grplist)
    #     check = dict.fromkeys(self.selectedMeshGroups())
    #     grplist = [grp for grp in grplist if grp not in check]
    #     self.setInputMeshGroups(grplist)
    #     self._cache = self.itemValue()

    def setUnusedVisibile(self, state):
        """Redefined from *ParameterView* class."""
        super().setUnusedVisibile(state)
        if self.filterPanel() is not None:
            self.filterPanel().applyFilter()

    # def _updateMeshList(self):
    #     """
    #     Updates the mesh list in the combobox
    #     """
    #     mlist_cur = avail_meshes(parameterPanel(self).pendingStorage())
    #     mlist_cmd = avail_meshes(parameterPanel(self).pendingCommandStorage())
    #     mlist_cmd = [m for m in mlist_cmd if m not in mlist_cur]
    #     meshlist = mlist_cur + mlist_cmd
    #     meshlist.reverse()
    #     self.setMeshList(meshlist)
    #     msg = ""
    #     if len(meshlist) > 1:
    #         msg = translate("ParameterPanel", "More than one mesh found")
    #     elif not meshlist:
    #         msg = translate("ParameterPanel", "No mesh found")
    #     self.setMessage(msg)
    #     self._meshActivated(self._mesh.currentIndex())

    def _updateMeshList(self):
        """
        Updates the mesh list in the combobox
        针对Tanksimulator固体(流体TODO)前处理进行了重写 Daizijian 2019/11/26
        """
        #mlist_cur = avail_meshes(parameterPanel(self).pendingStorage())
        #mlist_cmd = avail_meshes(parameterPanel(self).pendingCommandStorage())
        #mlist_cmd = [m for m in mlist_cmd if m not in mlist_cur]
        #meshlist = mlist_cur + mlist_cmd
        #meshlist.reverse()
        # self._loade

        meshlist=self.meshlistdai
        self.setMeshList(meshlist)
        msg = ""
        if len(meshlist) >= 1:
            #msg = translate("ParameterPanel", "More than one mesh found")
            #msg = "当前已存储了"+str(len(meshlist))+"个网格"
            msg = "当前上传数"+str(len(meshlist))
        elif not meshlist:
            #msg = translate("ParameterPanel", "No mesh found")
            msg = "当前没有网格"
        self.setMessage(msg)
        self._meshActivated(self._mesh.currentIndex())

    def get_cmd_groups(self,meshcmd, group_type): #重写，顶掉原来的定义   
        #pass
        #定义是 def get_medfile_groups(mesh_file, mesh_name, group_type):
        #return get_medfile_groups(meshcmd, get_medfile_meshes(meshcmd)[0], group_type)
        #return get_medfile_groups(meshcmd, get_medfile_meshes(meshcmd), group_type)
        groups={}
        elem_types = MeshElemType.elem_types(group_type)
        file_name = meshcmd
        nom_med = get_medfile_meshes(meshcmd)[0]
        for elem_type in elem_types:
            elem_groups = get_medfile_groups_by_type(file_name, nom_med,
                                                        elem_type, True)
            groups[elem_type] = elem_groups
        return groups


    def get_cmd_mesh(self,meshcmd):   #重写，顶掉原来的定义   
        # print("get_medfile_meshes返回内容为：",get_medfile_meshes(meshcmd))
        if len(get_medfile_meshes(meshcmd))>1:
            return meshcmd, get_medfile_meshes(meshcmd)[0]
        elif len(get_medfile_meshes(meshcmd))==1:
            return meshcmd, get_medfile_meshes(meshcmd)[0]

    def _meshActivated(self, index):
        """
        Updates the mesh groups in checkable list.
        Invoked after mesh changing in mesh combobox.
        """
        meshcmd = None
        if 0 <= index < self._mesh.count():
        #    meshcmd = self._mesh.itemData(index)
            meshcmd=self.meshlistdai[index]
        #print("Line2368meshcmd",meshcmd)

        groups = {}
        if meshcmd is not None:
            group_type = self._meshGroupType()
            #group_type = MeshGroupType.GElement
            #group_type = MeshGroupType.GNode
            file_name, nom_med = self.get_cmd_mesh(meshcmd)
            if is_medfile(file_name) or is_reference(file_name):
                self.meshFileChanged.emit(file_name, nom_med, 0.1, False)
                #self.minmax6 = self.meshview.getMeshSObj(file_name,None).GetMesh().BoundingBox()
                #print('bounding',self.meshview.getBounding6(file_name,nom_med))
                self.minmax6 = self.meshview.getBounding6(file_name,nom_med)
                print('self.minmax6',self.minmax6)
            #try:
            #    groups = self.get_cmd_groups(file_name, nom_med, group_type)
            groups = self.get_cmd_groups(file_name,group_type)
            #print("groups Line2376",groups)
            #except TypeError:
            #    pass
        # The value is overriden by "setMeshGroups"
        # It needs to be kept and set again
        
        # self.allgroups = groups
        
        # value = self.itemValue()
        # self.setMeshGroups(groups)
        #暂时关闭setItemValue TODO
        #self.setItemValue(value)
        #清除下方表格 TODO 重新载入保存的数据
        #self.fluidtable.clear()
        #self.table.clear()
        self.meshChanged.emit()
        
    def _meshGroupType(self):
        """
        Get the type of the mesh group

        Returns:
            str: Mesh group type (see `MeshGroupType`).
        """
        #mgtype = -1
        #mgtype = MeshGroupType.GElement
        if self.qiehuan == 1:
            mgtype = MeshGroupType.GNode
        else:
            mgtype = MeshGroupType.GElement
        #kw_def = self.keyword().definition
        #typ = kw_def.get('typ')
        #if isinstance(typ, (tuple, list)):
        #    typ = typ[0] if typ else None
        #if is_subclass(typ, CATA.package('DataStructure').grma):
        #    mgtype = MeshGroupType.GElement
        #elif is_subclass(typ, CATA.package('DataStructure').grno):
        #    mgtype = MeshGroupType.GNode
        return mgtype

    # @Q.pyqtSlot("QPoint")
    # def _popupMenuRequest(self, pos):
    #     """
    #     Process context menu request.
    #     """
    #     manage_normals = self.meshview.isFeatureSupported('normals') and \
    #         not behavior().grp_global_cmd

    #     meshcmd = self._meshcmd(self._mesh.currentIndex())
    #     file_name, nom_med = self.get_cmd_mesh(meshcmd)

    #     actions_list = ['select', 'unselect']
    #     if manage_normals:
    #         actions_list.extend(['show_normals', 'hide_normals'])
    #     actions_dict = OrderedDict.fromkeys(actions_list, False)

    #     selected_items = self.selectedItems()
    #     for item in selected_items:
    #         if item.checkState(0) == Q.Qt.Checked:
    #             actions_dict['unselect'] = True
    #         if item.checkState(0) == Q.Qt.Unchecked:
    #             actions_dict['select'] = True
    #         if manage_normals and file_name is not None and \
    #                 nom_med is not None:
    #             shown = self.meshview.normalsShown(file_name, nom_med,
    #                                                  item.text(0))
    #             if shown is None:
    #                 continue
    #             if shown:
    #                 actions_dict['hide_normals'] = True
    #             if not shown:
    #                 actions_dict['show_normals'] = True
    #         if all(actions_dict.values()):
    #             break

    #     actions_titles = {
    #         'select': translate("ParameterPanel", "Select"),
    #         'unselect': translate("ParameterPanel", "Unselect"),
    #         'show_normals': translate("ParameterPanel", "Show Normals"),
    #         'hide_normals':  translate("ParameterPanel", "Hide Normals"),
    #         }

    #     actions = OrderedDict()
    #     for item, shown in actions_dict.items():
    #         if not shown:
    #             continue
    #         action = Q.QAction(actions_titles[item], None)
    #         action.setToolTip(actions_titles[item])
    #         action.setStatusTip(actions_titles[item])
    #         actions[action] = item
    #     if actions:
    #         action = Q.QMenu.exec_(actions.keys(), self.mapToGlobal(pos))
    #         action_type = actions.get(action)
    #         if action_type == 'select':
    #             for item in selected_items:
    #                 item.setCheckState(0, Q.Qt.Checked)
    #         elif action_type == 'unselect':
    #             for item in selected_items:
    #                 item.setCheckState(0, Q.Qt.Unchecked)
    #         elif action_type == 'show_normals':
    #             for item in selected_items:
    #                 self.meshview.showNormals(file_name, nom_med,
    #                                             item.text(0), True)
    #         elif action_type == 'hide_normals':
    #             for item in selected_items:
    #                 self.meshview.showNormals(file_name, nom_med,
    #                                             item.text(0), False)

    @Q.pyqtSlot()
    def _showNormals(self):
        """Called when global 'Show/Hide normals' button is toggled."""
        #shown = self.ops[ParameterMeshGroupView.ShowNormals].isChecked()
        shown = self.actionnormal.isChecked()
        self.meshview.setAllNormalsShown(shown)

    @Q.pyqtSlot()
    def _fitSelection(self):
        """Called when global 'Fit selection' button is clicked."""
        meshcmd = self._meshcmd(self._mesh.currentIndex())
        file_name, nom_med = self.get_cmd_mesh(meshcmd)
        if file_name is None or nom_med is None:
            return
        group_type = self._meshGroupType()
        groups = self.highlightedMeshGroups() or self.selectedMeshGroups()
        self.meshview.fitObjects(file_name, nom_med, groups, group_type)

    @Q.pyqtSlot(bool)
    def _selectGroups(self, checked):
        """Action when the select groups icon is toggled or untoggled"""
        if checked:
            behavior().mesh_view_handle_selection = False
            #self._gbox.show()
            #self._selectGroupType(self._bgroup.checkedId())
            # self._selectGroupType()
            self.meshview.enable_selection = True
        if not checked:
            self.meshview.enable_selection = False
            #self._gbox.hide()s
            meshcmd = self._meshcmd(self._mesh.currentIndex())
            file_name, nom_med = self.get_cmd_mesh(meshcmd)
            self.meshview.displayAllGroups(file_name, nom_med,
                                             self._meshGroupType(),
                                             MeshElemType.EAll,
                                             #MeshElemType.ENode,
                                             self.selectedMeshGroups())
            self.meshview.setSelection(file_name,
                                         nom_med,
                                         [],
                                         self._meshGroupType())
            behavior().mesh_view_handle_selection = True

    @Q.pyqtSlot(int)
    def _selectGroupType(self):
        """
        Called when group type radio button is changed.

        Arguments:
            index(int): number of the selected radio button.
        """
        meshcmd = self._meshcmd(self._mesh.currentIndex())
        file_name, nom_med = self.get_cmd_mesh(meshcmd)
        groups = self.get_cmd_groups(file_name,MeshElemType.E2D)
        print('All groups=')
        print(groups)
        groups = self.get_cmd_groups(file_name,MeshElemType.EAll)
        print('All groups=')
        print(groups)

        # print('self.allgroups=')
        # print(self.allgroups)

        # self.meshview.displayAllGroups(file_name, nom_med,self._meshGroupType(),
        #                                     MeshElemType.EAll, self.allgroups[2])
        print('file_name, nom_med'+file_name+nom_med)
        self.meshview.displayAllGroups(file_name, nom_med)

        # self.meshview().setSelection(file_name,
        #                                 nom_med,
        #                                 self.selectedMeshGroups(),
        #                                 self._meshGroupType(),
        #                                 thetype)


class askSetSizeFactor(Q.QDialog):
    def __init__(self, parent=None, modal=True):
        super().__init__(parent)
        self.setWindowTitle('网格划分参数')
        self.setMinimumWidth(330)
        self.setModal(modal)
        self.edit = Q.QLineEdit('输入网格质量参数(0.001-10)',self)
        self.edit.selectAll()

        self.SizeFactor = None #float(self.edit.text())
        self.btok = Q.QPushButton("确定",self)

        self.btok.clicked.connect(self.closewindow)
        #self.edit.move(10,10)
        #self.btok.move(20,40)
        
        self.mesh2d = Q.QRadioButton('2D', self)
        self.mesh3d = Q.QRadioButton('3D', self)
        self.mesh2d.setChecked(True) 

        self.check2nd = Q.QCheckBox("使用二阶网格")

        #要彻底废弃move()方法 改用Layout
        self.alllayout = Q.QVBoxLayout(self)
        self.alllayout.addWidget(self.edit)
        self.alllayout.addWidget(self.mesh2d)
        self.alllayout.addWidget(self.mesh3d)
        self.alllayout.addWidget(self.check2nd)
        self.alllayout.addWidget(self.btok)

    def closewindow(self):
        SizeFactor = float(self.edit.text())
        if (not SizeFactor) or SizeFactor<0.001 or SizeFactor>10.0:
            self.edit.setText("请输入合适范围的数字！(0.001-10)")
            self.edit.selectAll()
        else:
            self.SizeFactor = SizeFactor
            self.close()

class Grouptreeview(Q.QDialog):
    meshFileChanged = Q.pyqtSignal(str, str, float, bool)
    meshGroupCheck = Q.pyqtSignal(str, str, str, int)
    meshGroupUnCheck = Q.pyqtSignal(str, str, str, int)
    meshChanged = Q.pyqtSignal()
    meshGroupCheckColor = Q.pyqtSignal(str, str, str, int,list)

    def __init__(self, meshview=None, meshcmd=None, selected=None):
        super().__init__(None)
        self.setWindowTitle('选择边界条件')
        self.meshview = meshview
        self.meshcmd = meshcmd
        self._invalid_groups = selected
        # self.group = []
        
        self._list = Q.QTreeWidget(self)
        self._list.setAllColumnsShowFocus(True)
        self._list.setSelectionMode(Q.QTreeWidget.ExtendedSelection)
        #self._list.setColumnCount(2)
        self._list.setColumnCount(2)
        self._list.setContextMenuPolicy(Q.Qt.CustomContextMenu)
        self._list.setMinimumWidth(280)
        #self._list.setColumnWidth(250,250)
        self._list.setMinimumHeight(50)
        titles = []
        #titles.append(translate("AsterStudy", "Name"))
        #titles.append(translate("AsterStudy", "Size"))
        titles.append("勾选高亮显示")
        titles.append("网格/节点数")
        #titles.append("固定边界条件")        
        self._list.setHeaderLabels(titles)
        #self._list.header().setSectionResizeMode(Q.QHeaderView.ResizeToContents)
        self._list.header().setSectionResizeMode(Q.QHeaderView.Stretch)
        self._list.header().setStretchLastSection(True)

        #TODO
        self.btok = Q.QPushButton("确定",self)
        self.btok.clicked.connect(self.closewindow)
        self.alllayout = Q.QVBoxLayout(self)
        self.alllayout.addWidget(self._list)
        self.alllayout.addWidget(self.btok)

        self._meshActivated()
        self.setGroups(selected)

        # connect(self.customContextMenuRequested, self._popupMenuRequest)
        connect(self._list.itemChanged, self.meshGroupToChange)
        connect(self.meshFileChanged, self.meshview.displayMEDFileName)
        connect(self.meshGroupCheck, self.meshview.displayMeshGroup)
        connect(self.meshGroupCheckColor, self.meshview.displayMeshGroupcolor)
        connect(self.meshGroupUnCheck, self.meshview.undisplayMeshGroup)

    def closewindow(self):
        # self.group = self.selectedMeshGroups()
        self.close()

    def setMeshGroups(self, groups):
        """
        Sets the mesh group list

        Arguments:
            groups (dict[int, list[tuple[str, int]]]): Mesh groups info.
        """
        self._list.clear()
        # self._invalid_groups.clear()
        grp_types = sorted(groups.keys())
        invalid_icon = load_icon("as_pic_exclamation.png")
        invalid_tip = translate("ParameterPanel",
                                "Invalid group name: '{}'. "
                                "Please rename the group.")
        print(grp_types)
        for typ in grp_types:
            names = groups[typ]
            if not names:
                continue
            title = MeshElemType.value2str(typ)
            item = Q.QTreeWidgetItem(self._list, [title])
            item.setFlags(Q.Qt.ItemIsEnabled)
            #print("name",name)
            #print("size",size)
            #print("occurs",occurs)
            # print("names",names)
            if len(names[0])==3:
                for name, size, occurs in names:
                #for name, size in names:
                    # print("name",name)
                    # print("size",size)
                    # print("occurs",occurs)
                    is_valid = is_valid_group_name(name) and occurs == 1
                    if occurs > 1:
                        self._invalid_groups.append(name)
                    sub_item = Q.QTreeWidgetItem(item, [name, str(size)])
                    flags = Q.Qt.ItemIsUserCheckable | Q.Qt.ItemIsSelectable
                    if is_valid:
                        flags |= Q.Qt.ItemIsEnabled
                    sub_item.setFlags(flags)
                    sub_item.setCheckState(0, Q.Qt.Unchecked)
                    sub_item.setTextAlignment(1, Q.Qt.AlignRight)
                    if is_valid:
                        sub_item.setToolTip(0, name)
                    else:
                        sub_item.setToolTip(0, invalid_tip.format(name))
                        sub_item.setIcon(0, invalid_icon)
            if len(names[0])==2:
                for name, size in names:
                #for name, size in names:
                    # print("name",name)
                    # print("size",size)
                    #print("occurs",occurs)
                    occurs = 1
                    is_valid = is_valid_group_name(name) and occurs == 1
                    #if occurs > 1:
                    #    self._invalid_groups.append(name)
                    sub_item = Q.QTreeWidgetItem(item, [name, str(size)])
                    flags = Q.Qt.ItemIsUserCheckable | Q.Qt.ItemIsSelectable
                    if is_valid:
                        flags |= Q.Qt.ItemIsEnabled
                    sub_item.setFlags(flags)
                    sub_item.setCheckState(0, Q.Qt.Unchecked)
                    sub_item.setTextAlignment(1, Q.Qt.AlignRight)
                    if is_valid:
                        sub_item.setToolTip(0, name)
                    else:
                        sub_item.setToolTip(0, invalid_tip.format(name))
                        sub_item.setIcon(0, invalid_icon)
        self._list.expandAll()
        if behavior().mesh_view_handle_selection:
            self.updateSelection() 

    def selectedMeshGroups(self):
        """
        Gets the names of selected (checked) mesh groups.

        Returns:
            list (str): List of selected group names.
        """
        groups = []
        for i in range(self._list.topLevelItemCount()):
            item = self._list.topLevelItem(i)
            for j in range(item.childCount()):
                sub_item = item.child(j)
                if sub_item.checkState(0) == Q.Qt.Checked:
                    if sub_item.text(0) not in groups:
                        groups.append(sub_item.text(0))
        return groups

    def setSelectedMeshGroups(self, groups, clear=True):
        """
        Sets the specified group names are selected (checked)
        and unchecked all other if `clear`.

        Arguments:
            groups: List of selected mesh group names.
            clear: If *True*, unchecks all other
        """
        for i in range(self._list.topLevelItemCount()):
            item = self._list.topLevelItem(i)
            for j in range(item.childCount()):
                sub_item = item.child(j)
                if sub_item.text(0) in groups:
                    state = Q.Qt.Checked
                elif clear:
                    state = Q.Qt.Unchecked
                else:
                    continue
                sub_item.setCheckState(0, state)

    def highlightedMeshGroups(self):
        """
        Gets the names of highlighted (selected items) mesh groups.

        Returns:
            list (str): List of highlighted group names.
        """
        groups = []
        for i in range(self._list.topLevelItemCount()):
            item = self._list.topLevelItem(i)
            for j in range(item.childCount()):
                sub_item = item.child(j)
                if sub_item.isSelected():
                    groups.append(sub_item.text(0))
        return list(set(groups))

    @Q.pyqtSlot()
    def meshGroupSelected(self):
        """
        Called when selection is changed in a view.

        Emits `meshGroupCheck()` and `meshGroupUnCheck()` signal for
        each mesh group to display/undisplay it in a mesh view.
        Sets selection to a mesh view as well.
        """
        #print("meshGroupSelected called!")
        #return
        if not behavior().mesh_view_handle_selection:
            return
        meshcmd = self.meshcmd
        print("meshcmd",meshcmd)
        if meshcmd is None:
            return
        print("meshGroupSelected called!")
        print("meshcmd",meshcmd)
        file_name, nom_med = self.get_cmd_mesh(meshcmd)
        if file_name is None or nom_med is None:
            return
        grtype = MeshGroupType.GElement #if typ in ('groups_ma',) else MeshGroupType.GNode
        all_groups = get_medfile_groups(file_name, None, grtype)
        for var in all_groups:
            self.meshGroupUnCheck.emit(file_name,
                                    nom_med,
                                    var,
                                    self._meshGroupType(),)
        selected = []
        for i in range(self._list.topLevelItemCount()):
            item = self._list.topLevelItem(i)
            for j in range(item.childCount()):
                sub_item = item.child(j)
                if sub_item.checkState(0) == Q.Qt.Checked or \
                        sub_item.isSelected():
                    self.meshGroupCheckColor.emit(file_name,
                                             nom_med,
                                             sub_item.text(0),
                                             self._meshGroupType(),
                                             [0.71,0.91,0.39])
                    print("self.meshGroupCheck.emit:",file_name,nom_med,sub_item.text(0),self._meshGroupType())
                    if sub_item.isSelected():
                        selected.append((file_name,
                                         nom_med,
                                         sub_item.text(0),
                                         self._meshGroupType()))
                else:
                    self.meshGroupUnCheck.emit(file_name,
                                               nom_med,
                                               sub_item.text(0),
                                               self._meshGroupType())
        self.meshview.setSelected(selected)

    def updateSelection(self):
        """Update selection in a view."""
        if not behavior().mesh_view_handle_selection:
            return
        selection = self.meshview.getSelected()
        print("selection = ",selection)
        blocked = self._list.blockSignals(True)
        self._list.clearSelection()
        for i in range(self._list.topLevelItemCount()):
            item = self._list.topLevelItem(i)
            for j in range(item.childCount()):
                if selection and item.child(j).text(0) in selection:
                    item.setSelected(True)
        self._list.blockSignals(blocked)
        if behavior().mesh_view_handle_selection:
            self.meshGroupSelected()

    def meshGroupToChange(self, item, column):
        """
        Called when mesh group item is checked ON/OFF.

        Emits `meshGroupCheck()` or `meshGroupUnCheck()` signal
        to display/undisplay given group in a mesh view.
        """
        if behavior().mesh_view_handle_selection:
            self.meshGroupSelected()
            return
        meshcmd = self._meshcmd(self._mesh.currentIndex())
        if meshcmd is not None:
            file_name, nom_med = self.get_cmd_mesh(meshcmd)

            grtype = MeshGroupType.GElement #if typ in ('groups_ma',) else MeshGroupType.GNode
            all_groups = get_medfile_groups(file_name, None, grtype)
            for var in all_groups:
                self.meshGroupUnCheck.emit(file_name,
                                        nom_med,
                                        var,
                                        self._meshGroupType(),)

            if file_name is not None and nom_med is not None:
                #if not self.ops[self.SelectGroups].isChecked():
                if not self.actioninter.isChecked():
                    if item.checkState(column) == Q.Qt.Checked:
                        self.meshGroupCheckColor.emit(file_name,
                                                 nom_med,
                                                 item.text(0),
                                                 self._meshGroupType(),
                                                 [0.71,0.91,0.39])
                    # Do not hide in 'group selection' mode
                    if item.checkState(column) == Q.Qt.Unchecked:
                        self.meshGroupUnCheck.emit(file_name,
                                                   nom_med,
                                                   item.text(0),
                                                   self._meshGroupType())
                #if self.ops[self.SelectGroups].isChecked():
                if self.actioninter.isChecked():
                    index = self._bgroup.checkedId()
                    #tlist = MeshElemType.elem_types(MeshGroupType.GElement,
                    tlist = MeshElemType.elem_types(self._meshGroupType(),
                                                    True)
                    thetype = tlist[index]
                    self.meshview.setSelection(file_name,
                                                 nom_med,
                                                 self.selectedMeshGroups(),
                                                 self._meshGroupType(),
                                                 thetype)

    def _meshActivated(self):
        """
        Updates the mesh groups in checkable list.
        Invoked after mesh changing in mesh combobox.
        """
        groups = {}
        if self.meshcmd is not None:
            group_type = self._meshGroupType()
            #group_type = MeshGroupType.GElement
            #group_type = MeshGroupType.GNode
            file_name, nom_med = self.get_cmd_mesh(self.meshcmd)
    
            groups = self.get_cmd_groups(file_name,group_type)
        
        print('弹窗的groups')
        print(groups)
        self.setMeshGroups(groups)
        
    def get_cmd_groups(self,meshcmd, group_type): #重写，顶掉原来的定义   
        #pass
        #定义是 def get_medfile_groups(mesh_file, mesh_name, group_type):
        #return get_medfile_groups(meshcmd, get_medfile_meshes(meshcmd)[0], group_type)
        #return get_medfile_groups(meshcmd, get_medfile_meshes(meshcmd), group_type)
        groups={}
        elem_types = MeshElemType.elem_types(group_type)
        file_name = meshcmd
        nom_med = get_medfile_meshes(meshcmd)[0]
        for elem_type in elem_types:
            elem_groups = get_medfile_groups_by_type(file_name, nom_med,
                                                        elem_type, True)
            groups[elem_type] = elem_groups
        return groups


    def get_cmd_mesh(self,meshcmd):   #重写，顶掉原来的定义   
        # print("get_medfile_meshes返回内容为：",get_medfile_meshes(meshcmd))
        if len(get_medfile_meshes(meshcmd))>1:
            return meshcmd, get_medfile_meshes(meshcmd)[0]
        elif len(get_medfile_meshes(meshcmd))==1:
            return meshcmd, get_medfile_meshes(meshcmd)[0]

    def _meshGroupType(self):
        """
        Get the type of the mesh group

        Returns:
            str: Mesh group type (see `MeshGroupType`).
        """
        #mgtype = -1
        #mgtype = MeshGroupType.GElement
        # if self.qiehuan == 1:
        #     mgtype = MeshGroupType.GNode
        # else:
        #     mgtype = MeshGroupType.GElement

        mgtype = MeshGroupType.GElement

        return mgtype

    def setGroups(self, groups):
        """
        Set list of selected groups.

        Arguments:
            groups (list[str]): Groups to be selected.
        """
        for group in groups:
            items = self._list.findItems(group,Q.Qt.MatchRecursive)

            if items:
                items[0].setCheckState(0,Q.Qt.Checked)
