


#


"""
Session
-------

The module gives informations about the current session.

The catalog can know if it is imported from AsterStudy or from a code_aster
execution and so it may behave differently.
"""



class AsterStudySession:
    """Informations about the AsterStudy session."""

    _cata = 0

    @classmethod
    def set_cata(cls):
        """Set the marker for the code_aster catalog."""
        cls._cata = 1

    @classmethod
    def use_cata(cls):
        """Tell if the code_aster catalog is used within asterstudy."""
        # code_aster legacy does not call set_cata, so it imports legacy modules
        return cls._cata == 1
