


#


"""
Exception hook
--------------

The module implements custom exception handling mechanism.

"""


import sys

from .utilities import show_exception


__all__ = ["enable_except_hook"]


def custom_except_hook(exc_type, exc_value, exc_traceback):
    """
    Custom exception handling method.

    Arguments:
        exc_type (type): Exception type (not used).
        exc_value (Exception): Exception value.
        exc_traceback (traceback): Exception traceback.
    """
    # pragma pylint: disable=unused-argument
    show_exception(exc_value, traceback=exc_traceback)


def enable_except_hook(is_enable):
    """
    Enable/disable custom exception handling.

    Arguments:
        is_enable (bool): *True* to enable, or *False* to disable
            custom exception handling.
    """
    if is_enable:
        if not hasattr(enable_except_hook, "old_hook"):
            enable_except_hook.old_hook = sys.excepthook
        sys.excepthook = custom_except_hook
    else:
        if hasattr(enable_except_hook, "old_hook"):
            old_hook = enable_except_hook.old_hook
            delattr(enable_except_hook, "old_hook")
        else:
            old_hook = sys.__excepthook__
        sys.excepthook = old_hook
