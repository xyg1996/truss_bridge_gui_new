
"""
Features
--------

The module defines an object to manage the feature supported by a code_aster
version.
"""

import os
from .base_utils import no_new_attributes


class Features:
    """Object that holds the supported features.

    Arguments:
        vers (tuple[int]): Version number as a tuple (ex: (14, 4, 0)).
            Defaults to the most possible recent version.
    """

    _command_ids = _parametric = _all_types = _formula_deps = None
    __setattr__ = no_new_attributes(object.__setattr__)

    def __init__(self, vers=None):
        """Initialization."""
        vers = vers or (99,)
        _test_ = int(os.getenv('ASTERSTUDY_WITHIN_TESTS', '0'))
        # < 14.1.4 or < 13.5.3: do not export Command ids
        enabled = vers >= (14, 1, 4) or (vers[0] == 13 and vers >= (13, 5, 3))
        self._command_ids = enabled
        # parametric studies supported starting at 14.1.11 and 13.5.8
        enabled = vers >= (14, 1, 11) or (vers[0] == 13 and vers >= (13, 5, 8))
        self._parametric = enabled
        # get_all_types only exist starting at 14.1.14 and 13.5.9
        enabled = vers >= (14, 1, 14) or (vers[0] == 13 and vers >= (13, 5, 8))
        self._all_types = enabled
        # definition of formulas dependencies supported starting at 14.1.13
        enabled = vers >= (14, 1, 13) or _test_
        self._formula_deps = enabled

    @property
    def command_ids(self):
        """bool: Attribute that holds the 'command_ids' property."""
        return self._command_ids

    @property
    def parametric(self):
        """bool: Attribute that holds the 'parametric' property."""
        return self._parametric

    @property
    def all_types(self):
        """bool: Attribute that holds the 'all_type' property."""
        return self._all_types

    @property
    def formula_deps(self):
        """bool: Attribute that holds the 'formula_deps' property."""
        return self._formula_deps
