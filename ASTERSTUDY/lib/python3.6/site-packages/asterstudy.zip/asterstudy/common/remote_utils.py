


#


"""
Some utilities for remote files.

"""
# This module is only covered by remote testcases
# that's why it is excluded from coverage report.


# The pragma below has to be removed after migration to Python 3 and
# suppression of above two lines.
# pragma pylint: disable=wrong-import-position,wrong-import-order

import os
import os.path as osp
import subprocess as SP
import urllib.parse

from PyQt5 import Qt as Q

from .base_utils import is_localhost, no_new_attributes, to_unicode
from .utilities import info_message

FILE_TRANSFER_PROTOCOL = "sftp"
HOST_SEP = "@"
PATH_SEP = ":"


__test__ = int(os.getenv("ASTERSTUDY_WITHIN_TESTS", "0"))


def is_gnome():
    """Tests whether Desktop Environment is Gnome."""
    if getattr(is_gnome, "cache", None) is None:
        try:
            # pragma pylint: disable=import-error
            from gi.repository import Gio as gio, GLib as glib
        except ImportError:
            gio, glib = None, None
        is_gnome.cache = gio, glib
    return is_gnome.cache


class MountedVolumes:
    """Store the volumes mounted during the session, to be able to unmount them
    when the application exits.
    """
    uri = None
    __setattr__ = no_new_attributes(object.__setattr__)

    def __init__(self):
        self.uri = set()

    def exists(self, path):
        """Tests existence of files located on a server.

        Note:
            The file system of the server has to be mounted
            on Gnome virtual filesystem for this function
            to work.

        Arguments:
            path (str): URL of the remote file.

        Returns:
            bool: *True* if the the path exists, *False* otherwise.
        """
        gio = is_gnome()[0]
        if gio is None:
            return False

        previously_mounted = path in self.uri
        self.mount(path)
        fobj = gio.File.new_for_commandline_arg(path)
        exist = bool(fobj.query_exists())
        if previously_mounted:
            self.unmount(path)
        return exist

    def mount(self, path):
        """Mount enclosing filesystem to path with Gio.

        Arguments:
            path (str): URI or path to be mount.
        """
        gio, glib = is_gnome()
        if gio is None:
            return

        # Set up everything to start mount loop
        # new_for_uri or new_for_path? we don't know
        fobj = gio.File.new_for_commandline_arg(path)
        loop = glib.MainLoop()
        mount_operation = gio.MountOperation()
        mount_operation.set_anonymous(True)

        # Define callback
        def _cbck_end(g_file, result):
            """Callback when mount operation is over."""
            try:
                if g_file.mount_enclosing_volume_finish(result):
                    self.uri.add(path)
                    info_message("Filesystem {0} mounted".format(path))
            except glib.GError as err: # pragma pylint: disable=catching-non-exception
                # Pass already mounted case silently
                if err.code == gio.IOErrorEnum.ALREADY_MOUNTED: # pragma pylint: disable=no-member
                    pass
                elif not __test__:
                    info_message("Mounting {0} filesystem: failed".format(path))
                    info_message(err)
            finally:
                # End loop anyway
                loop.quit()

        # Define desired mount
        fobj.mount_enclosing_volume(gio.MountMountFlags.NONE,
                                    mount_operation, None, _cbck_end)
        # Run
        loop.run()

    @staticmethod
    def unmount(path):
        """Unmount an enclosing filesystem.

        Arguments:
            path (str): URI or path to be mount.
        """
        gio, glib = is_gnome()
        if gio is None:
            return

        fobj = gio.File.new_for_commandline_arg(path)
        gobj = fobj.find_enclosing_mount()
        loop = glib.MainLoop()
        mount_operation = gio.MountOperation()
        mount_operation.set_anonymous(True)

        # Define callback
        def _cbck_end(g_mount, result):
            """Callback when mount operation is over."""
            try:
                if g_mount.unmount_with_operation_finish(result):
                    info_message("Filesystem {0} unmounted".format(path))
            except glib.GError as err: # pragma pylint: disable=catching-non-exception
                info_message("Unmounting {0} filesystem: failed".format(path))
                info_message(err)
            finally:
                # End loop anyway
                loop.quit()

        # Define desired mount
        gobj.unmount_with_operation(gio.MountMountFlags.NONE,
                                    mount_operation, None, _cbck_end)

        # Run
        loop.run()

    def unmount_all(self):
        """Unmount all known mount points."""
        for uri in self.uri:
            self.unmount(uri)


# local instance to manage mount points
MOUNT = MountedVolumes()

# static utilities
def exists_remote(path):
    """Tests existence of files located on a server.

    Note:
        The file system of the server has to be mounted
        on Gnome virtual filesystem for this function
        to work.

    Arguments:
        path (str): URL of the remote file.

    Returns:
        bool: *True* if the the path exists, *False* otherwise.
    """
    return MOUNT.exists(path)

def mount_enclosing_fs(path):
    """Mount enclosing filesystem to path with Gio."""
    MOUNT.mount(path)

def unmount_enclosing_fs(path):
    """Unmount enclosing filesystem to path with Gio."""
    MOUNT.unmount(path)

def unmount_all():
    """Unmount all filesystems mounted during this session."""
    MOUNT.unmount_all()


def dlg2url(path):
    """
    Convert path returned by a file dialog into valid url.

    Arguments:
        path (str): file path as returned by a QFileDialog.
    """
    gio = is_gnome()[0]
    if gio is None:
        return osp.realpath(path)

    vfs = gio.Vfs.get_default()
    gio_fobj = vfs.get_file_for_path(Q.QUrl(path).path())
    fileurl = gio_fobj.get_uri()

    # Return full url if remote, else return unchanged path
    is_remote = urllib.parse.urlsplit(fileurl).hostname is not None
    return fileurl if is_remote else osp.realpath(path)

def build_url(user, host, base, relpath=""):
    """Build remote file URL from relative path.

    Arguments:
        user (str): user name.
        host (str): host name as adressed by SSH.
        base (str): "home", "scratch" or "tmp".
        relpath (str): path relative to the host file system.
    """
    prtl = FILE_TRANSFER_PROTOCOL
    netloc = user + HOST_SEP + host
    basepath = osp.join(osp.sep, base, user)

    base_url = urllib.parse.urlunparse((prtl, netloc, basepath, "", "", ""))
    full_url = urllib.parse.urljoin(base_url, relpath)
    return full_url

def url_gio2asrun(filename):
    """Convert URL from Gio to asrun conventions.

    Arguments:
        filename (str): Input URL.

    Note:
        Implementing by deconstructing then reconstructing the URL.
        This is the safest way.
    """
    # Deconstruct Gio URL
    pres = urllib.parse.urlparse(filename)
    user, host, relpath = pres.username, pres.hostname, pres.path

    # Reconstruct asrun URL
    return make_remote_path(user, host, relpath)

def make_remote_path(user, host, path):
    """
    Add `hostname@user:` to path.

    Arguments:
        servcfg(dict): server configuration.
        path(str): path relative to remote machine.

    Returns:
        str: `path` preceded by `hostname@user:`
    """
    user = user + HOST_SEP if user else ""
    host = host + PATH_SEP if host or user else ""
    return user + host + path

def remote_exec(user, host, command, ignore_errors=False, timeout=None,
                message=None):
    """Execute *command* on a remote server and return the output.

    Raise OSError exception in case of failure.

    Arguments:
        user (str): User name on the remote host.
        host (str): Host name to be addressed by SSH.
        command (str): Command line to remotely execute.
        ignore_errors (bool): Do not raise exceptions in case of error.
        timeout (int): Passed to `Popen.communicate()`.
        message (str): Message to be printed on stdout instead of the
            command line (for remote command only).

    Returns:
        *misc*: If ``ignore_errors`` is *False*, it returns the output of the
        command. If ``ignore_errors`` is *True*, a tuple is returned with the
        exit code, the output and the error of the command.
    """
    cmd = [command]
    is_local = is_localhost(host)
    if message:
        info_message(message)
    if not is_local:
        if not message:
            info_message("Command executed on {0}: {1}".format(host, command))
        use_shell = False
        cmd = [str("ssh"), "-n",
               "-o", "StrictHostKeyChecking=no", "-o", "BatchMode=yes",
               str(user + "@" if user else "") + host] + cmd
        if not message:
            info_message("Full command {0}".format(cmd))
    else:
        use_shell = True
    ssh = SP.Popen(cmd, shell=use_shell, stdout=SP.PIPE, stderr=SP.PIPE)
    try:
        out, err = ssh.communicate(timeout=timeout)
        returncode = ssh.returncode
    except SP.TimeoutExpired:
        out = ""
        err = "Command not finished after {0} seconds.".format(timeout)
        returncode = 6
    if not is_local:
        info_message("exit code: %d" % returncode)
    if ignore_errors:
        ret = (returncode, to_unicode(out), to_unicode(err))
    else:
        ret = to_unicode(out)
        if returncode != 0:
            raise OSError(err)
    return ret


def local_exec(command, ignore_errors=False):
    """Execute *command* on localhost and return the output.

    Raise OSError exception in case of failure.

    Arguments:
        command (str): Command line to remotely execute.
        ignore_errors (bool): Do not raise exceptions in case of error.

    Returns:
        *misc*: See `:py:func:remote_exec`.
    """
    return remote_exec("", "", command, ignore_errors)


def remote_delete(user, host, path):
    """Delete a remote file or directory.

    Arguments:
        user (str): User name on the remote host.
        host (str): Host name to be addressed by SSH.
        path (str): Command line to remotely execute.

    Returns:
        tuple: Tuple containing the exit code, the output and the error of
        the command.
    """
    return remote_exec(user, host, "rm -rf '{}'".format(path),
                       ignore_errors=True, timeout=30)
