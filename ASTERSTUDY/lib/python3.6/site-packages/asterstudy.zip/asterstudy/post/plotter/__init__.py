

"""
Implementation of a simple plotter for the asterstudy post processor
"""
from .plot_window import PlotWindow
from .table import CustomTable
