


#


"""
Results Navigator
-----------------

Implementation of Results navigator for AsterStudy application.

"""



# from . view import ResultsNavigatorTree
# from . model import ResultsNavigatorModel
from . overlay_bar import OverlayBar
# from . params import RepresentationParams
